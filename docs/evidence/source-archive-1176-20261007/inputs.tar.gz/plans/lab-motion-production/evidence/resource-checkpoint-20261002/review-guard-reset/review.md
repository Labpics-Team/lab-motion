# MotionValue: живость преемника при сбросе tick guard

Дата: 2026-10-02. Независимая ось: getter/listener вызывает `stop() → setTarget()`, после возврата нового `requestFrame` доставляет его one-shot callback до возврата старого tick. Преемник должен продолжать движение; same-run reentrancy guard, synchronous/deferred scheduling, SpringParams reference/getters, shared scratch, первая ошибка и stale-run rejection сохраняются.

Объект: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-motion-value-reentrant-start-20261002.v7azyt6y/evidence`.

| Привязка | SHA256 |
|---|---|
| manifest.json | `57937fead0ffea7af3bd29245458d24694ff102f8c08bd01de1500753133965f` |
| candidate-motion-value.ts | `f65ee267b86b8041835eae73f42b5d4b64c4199941c4496437b4ea93aabf9adb` |
| baseline-motion-value.ts | `0256d46a682a46774c2a04e930097d1d576fb9947ca941930ecbbd69bef4c8e6` |
| guard-reset.patch | `fa9fa84e69fd9cb361a78bf6f1aa9832fe42fe7914abbb2ddf57b37d122bf589` |
| candidate-regression.test.ts | `2a27f7ced334db7e7f1213b3cb15e000616712aef785185cf840fa9308b87046` |
| source.tar.gz | `fb9dc1c0faa5217ebf96862cab01f684c5e40429a0299eb7a1b8dc4153b51503` |

## Контракт и статическое доказательство

`candidate-motion-value.ts:37–49` допускает инжектированный RequestFrameFn; `src/drive.ts:14–21,56–64` сохраняет callback с/без timestamp и handle=0 fallback. SpringParams в `src/internal/types.ts:9–17` — readonly интерфейс с числовыми свойствами; он не запрещает getters и не требует копии plain object. Проверяемая one-shot история задаёт отдельный callback на каждый request и не подменяет дефект повторной доставкой одного callback.

В baseline guard установлен старым tick. После stop/setTarget новая identity уже активна, но one-shot callback преемника возвращается из `_tick` по общему `_tickActive`; старый tick затем видит иную identity и не планирует кадр. Получается живой `_run` без callback. Повтор той же цели — no-op, поэтому не восстанавливает прогресс. Этот различитель содержится в разрешённом исходнике `../motion-run-identity-correctness-review-20261002/probe.mjs` (SHA256 `09d08dd8b596c557c82387c163668d9058c4ca9e5ca7bdec80b216d70d8222ce`); чужой review/result не использован как oracle.

В candidate `setTarget:306–312` сбрасывает guard только в ветви `!this._run`, перед публикацией новой identity и выдачей кадра. Между сбросом и публикацией нет callback-границы. Поэтому новый one-shot callback проходит guard; старые callbacks по-прежнему отвергаются по identity. Ретаргет активного run в эту ветвь не входит и guard не снимает.

После getter reentry старый `_tick` проверяет identity сразу после `solveSpring` (`:431–433`) и не публикует его результат. После listener reentry старый `_schedule(run)` также отвергается (`:376`). Синхронный вложенный tick полностью возвращается до продолжения внешнего JavaScript-стека: внешний `finally` не может очистить guard ещё исполняющегося вложенного tick. Он оставляет guard свободным для следующего кадра преемника.

Перенос сброса из final-emit ветви (`:468–474`) в fresh-start owner сохраняет её поведение: terminal run уже null, и новый setTarget получает тот же сброс независимо от причины завершения. Без нового run действующего callback, которому потребовался бы сброс до emit, нет.

## Сохранённые соседние свойства

- `_schedule:374–408` неизменён. Callback внутри requestFrame только сохраняет timestamp; после возврата используется один timeout trampoline. Deferred nonzero-handle callback входит в `_tick`. Handle=0 и поздний host callback остаются за прежним fallback/identity guard.
- `_tick:413–414` сохраняет single-flight guard текущего run. Контроль `candidate-regression.test.ts:162–189` намеренно повторяет один и тот же callback из getter и требует ровно один опубликованный tick и один следующий callback. Это защитный сосед; положительные liveness cases используют distinct one-shot callbacks.
- `_spring` остаётся исходным объектом. `solveSpring` (`src/internal/solver.ts:30`) читает mass/stiffness/damping на каждом вызове. При смене run внутри любого getter старый solver может закончить вычисление, но identity guard отбрасывает его результат. Новый run получает текущие getter/reference semantics без snapshot или второго solver.
- Общий `solverSample` не становится долговременным результатом. До listener-границы tick копирует position/velocity в локальные числа (`:434–435`) и публикует оба поля. После getter reentry запись старого solver в scratch не меняет уже опубликованные поля преемника. Положительный regression сравнивает пару с отдельным MotionValue из того же origin/velocity; прежний cross-instance scratch test сохранён.
- `_emit:492–508` и error path `:479–484` неизменены: явный `failed` сохраняет в том числе falsey первую ошибку, secondary scheduling error её не заменяет. Если listener уже сменил run, старый catch не ставит кадр отозванной identity. Набор listener-isolation содержит отдельные controls для undefined/null/false/0/пустой строки и scheduler failure.

## Проверки и их область

Все 47 записей manifest совпали с байтами. Source и regression внутри `source.tar.gz` побайтно совпали с отдельными candidate файлами. Самостоятельно полученный baseline→candidate diff содержит только перенос сброса guard и комментария. Авторские RESULT/triage/review тексты не читались; выполнение кода из архивов отсутствовало.

Прочитаны сохранённые `unit.json`, `unit.stdout.log`, `typecheck.json`, `build.json`, `runtime-probe.json`, code/inputs и machine results runtime-probe. Они относятся к указанным source/test hashes. Unit receipt от 2026-10-02T02:59:56Z — exit 0, шесть файлов/133 tests; в них шесть новых cases: getter/listener after-request, getter/listener synchronous-request, final emit и same-run guard. Typecheck и build также имеют exit 0. Это ранее выполненные проверки, не новые запуски reviewer.

Сохранённый runtime-probe от 2026-10-02T03:01:21Z, Node v24.21.0, CPU 0, exit 0 проверяет ESM и CJS pins. В обеих формах getter/listener after-request оставляют один callback, ноль timers и достигают target=2 без recovery; same-target retry не создаёт запрос. Sync-request оставляет один timer, а поздний старый fallback callback не меняет snapshot или число запросов. Assertions probe сопоставляют regular retarget/sync-control/late-fallback с прежними machine results. Это поддерживает scoped claim, но не заменяет source-проверку и не выдаётся за новое независимое runtime evidence.

Первый regression и текущий отличаются только условием final emit: добавлено `value.velocity !== 0` к отсечению преждевременного входа. Клампованная position может равняться target до успокоения; пара target/zero velocity корректно отличает terminal snapshot от такого соседнего кадра. Это не ослабляет after-request one-shot cases.

## Verdict: PASS

Подтверждённых нарушений в guard-reset liveness и перечисленных сохраняемых свойствах нет. Общий сброс принадлежит новому run и закрывает потерю callback преемника, сохраняя защиту текущего run. Нового механизма, очереди, копии параметров или внешней policy не добавлено.

**Да:** статическое независимое review exact source/diff/контракта/tests, проверка byte bindings, чтение сохранённых GREEN receipts и runtime observations. **Нет:** подтверждённых findings этой оси. **Не было:** нового runtime запуска, tests/build/install, чтения чужих verdict/triage/RESULT, новых threads, Windows, product/plan edits, memory writes, merge/deploy. Изоляция — отдельный report вне candidate; исходный packet не изменён.

PASS ограничен этой осью и этим source hash. Он не закрывает полный Motion, общий размерный/производительный гейт, published artifact identity или пользовательскую sheet/carousel policy.
