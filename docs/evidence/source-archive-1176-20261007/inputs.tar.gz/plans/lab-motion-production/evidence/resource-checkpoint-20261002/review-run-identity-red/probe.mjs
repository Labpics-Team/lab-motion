import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
const base=dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const pins={
 'baseline.mjs':'7a3542e9ebb8c0484354631b8dde72f2d5ffcb1584597dcbfe5cc521fbcc7735',
 'baseline.cjs':'908c8e295fa4e02be62f76251468edd9ef0c4c7aa16e39656dd89a231d374ad8',
 'candidate.mjs':'9e2dc7277e1c7d65aba82505e876bce39def5968990619f9dd9f3aa97405dd42',
 'candidate.cjs':'fcbafc0243288f839e64a0a8699cc32919eced4cceeac27a18eb5f8052e5e994'};
for(const [p,h] of Object.entries(pins))assert.equal(sha(join(base,p)),h);
const started=new Date().toISOString();
const savedTimeout=globalThis.setTimeout;
let timers=[],timerId=0;
globalThis.setTimeout=(cb)=>{assert.equal(typeof cb,'function');timers.push(cb);return ++timerId;};
const spring={mass:1,stiffness:200,damping:20};
function flushTimers(limit=3000){
 let n=0;while(timers.length){assert.ok(++n<=limit);timers.shift()();}
 return n;
}
function clock(strategy=()=>1){
 let requests=0;const queue=[],delivered=new Set();
 const requestFrame=cb=>{
  const id=++requests;
  const once=ts=>{assert.ok(!delivered.has(id),'one-shot callback reused');delivered.add(id);cb(ts);};
  const mode=strategy(id,once);
  if(mode!=='sync')queue.push(once);
  return mode==='sync'?1:mode;
 };
 return {requestFrame,queue,get requests(){return requests;},get delivered(){return delivered.size;},
  next(ts){assert.ok(queue.length);queue.shift()(ts);},
  drain(limit=3000){let n=0;while(queue.length){assert.ok(++n<=limit);this.next();}return n;}};
}
function lateFallback(MV){
 timers=[];const c=clock(id=>id===1?0:1);
 const mv=new MV({initial:0,spring,requestFrame:c.requestFrame}),trace=[];
 mv.onChange(v=>trace.push(v));mv.setTarget(1);
 const fallbackTicks=flushTimers();assert.equal(mv.value,1);
 assert.equal(c.queue.length,1);
 mv.setTarget(2);assert.equal(c.queue.length,2);
 const before={value:mv.value,velocity:mv.velocity,emissions:trace.length,requests:c.requests};
 c.next();
 const after={value:mv.value,velocity:mv.velocity,emissions:trace.length,requests:c.requests};
 const answer={fallbackTicks,before,after,queuedAfter:c.queue.length,oneShotDeliveries:c.delivered};
 mv.destroy();c.drain();flushTimers();
 return answer;
}
function getterHandoff(MV,delivery){
 timers=[];let armed=false,mv;const c=clock((id,cb)=>{
  if(id===2&&delivery==='inside-request'){cb();return 'sync';}
  return 1;
 });
 const params={get mass(){
  if(armed){armed=false;mv.stop();mv.setTarget(2);if(delivery==='inside-getter-after-request')c.next();}
  return 1;
 },stiffness:200,damping:20};
 const trace=[];mv=new MV({initial:0,spring:params,requestFrame:c.requestFrame});
 mv.onChange(v=>trace.push(v));mv.setTarget(1);armed=true;c.next();
 const atReturn={value:mv.value,velocity:mv.velocity,queued:c.queue.length,timers:timers.length,requests:c.requests,emissions:trace.length};
 mv.setTarget(2);
 const retrySameTarget={queued:c.queue.length,timers:timers.length,requests:c.requests};
 flushTimers();c.drain();const valueWithoutIntervention=mv.value;
 if(delivery==='inside-getter-after-request'){
  assert.equal(valueWithoutIntervention,0);assert.equal(c.queue.length,0);
  mv.stop();mv.setTarget(2);c.drain();assert.equal(mv.value,2);
 }else assert.equal(valueWithoutIntervention,2);
 const answer={delivery,atReturn,retrySameTarget,valueWithoutIntervention,valueAfterExplicitRecovery:mv.value};
 mv.destroy();c.drain();flushTimers();return answer;
}
function listenerHandoff(MV){
 timers=[];const c=clock();let armed=false;
 const mv=new MV({initial:0,spring,requestFrame:c.requestFrame}),trace=[];
 mv.onChange(v=>{trace.push(v);if(armed){armed=false;mv.stop();mv.setTarget(2);c.next();}});
 mv.setTarget(1);armed=true;c.next();
 const atReturn={value:mv.value,velocity:mv.velocity,queued:c.queue.length,timers:timers.length,requests:c.requests,emissions:trace.length};
 mv.setTarget(2);assert.equal(c.queue.length,0);assert.equal(timers.length,0);assert.notEqual(mv.value,2);
 const requestsAfterSameTarget=c.requests;
 mv.stop();mv.setTarget(2);c.drain();assert.equal(mv.value,2);
 const answer={atReturn,requestsAfterSameTarget,valueAfterExplicitRecovery:mv.value};
 mv.destroy();flushTimers();return answer;
}
function regularRetarget(MV){
 timers=[];const c=clock(),mv=new MV({initial:0,spring,requestFrame:c.requestFrame});
 const trace=[];mv.onChange(v=>trace.push([v,mv.velocity]));
 mv.setTarget(10);for(let i=0;i<5;i++)c.next(i*16);
 const before=trace.at(-1);mv.setTarget(20);assert.deepEqual(trace.at(-1),before);
 assert.equal(c.queue.length,1);for(let i=5;i<10;i++)c.next(i*16);
 mv.stop();const snapshot=[mv.value,mv.velocity];c.drain();assert.deepEqual([mv.value,mv.velocity],snapshot);
 mv.setTarget(-1);c.drain();assert.equal(mv.value,-1);
 mv.destroy();assert.deepEqual([mv.value,mv.velocity],[-1,0]);return trace;
}
const results=[];
try{
 for(const version of ['baseline','candidate'])for(const format of ['mjs','cjs']){
  const path=join(base,version+'.'+format);
  const {MotionValue}=format==='mjs'?await import(path):require(path);
  results.push({version,format,lateFallback:lateFallback(MotionValue),
   getterAfterRequest:getterHandoff(MotionValue,'inside-getter-after-request'),
   getterSynchronousRequest:getterHandoff(MotionValue,'inside-request'),
   listenerAfterRequest:listenerHandoff(MotionValue),
   regularRetarget:regularRetarget(MotionValue)});
 }
 for(const format of ['mjs','cjs']){
  const a=results.find(r=>r.version==='baseline'&&r.format===format);
  const b=results.find(r=>r.version==='candidate'&&r.format===format);
  for(const name of ['getterAfterRequest','getterSynchronousRequest','listenerAfterRequest','regularRetarget'])assert.deepEqual(a[name],b[name]);
  assert.equal(a.lateFallback.after.emissions-a.lateFallback.before.emissions,1);
  assert.equal(a.lateFallback.after.requests-a.lateFallback.before.requests,1);
  assert.deepEqual(b.lateFallback.after,b.lateFallback.before);
 }
}finally{globalThis.setTimeout=savedTimeout;timers=[];}
const out={started,finished:new Date().toISOString(),pid:process.pid,node:process.version,
 cpuAllowed:readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.*)$/m)[1],
 scriptSha256:sha(fileURLToPath(import.meta.url)),runtimePins:pins,
 observation:'Candidate rejects old one-shot fallback-host callback after natural settle; reentrant successor delivery after requestFrame return is stalled in both snapshots.',
 results};
writeFileSync(join(base,'probe-result.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...out,results:results.map(({regularRetarget,...r})=>({...r,regularRetargetSamples:regularRetarget.length}))}));
