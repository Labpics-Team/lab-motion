# Svelte RESOURCE: кандидат для review

Map связывает callback с revoker текущей регистрации. Повторный subscribe доставляет текущее значение и использует общий revoker; off освобождает callback/registry captures, destroy вызывает все revokers. Broadcast сохраняет прежнюю fail-fast семантику.

Baseline RED воспроизведён до правки:3 focused failures и12 runtime failures при9 успешных controls. GREEN:19 tests/3 suites, TypeScript, canonical tsup и21 runtime checks. Runtime probe побайтово один и тот же для RED/GREEN. Только dist/svelte/index.js и.cjs отличаются от fix12;88 соседних outputs совпадают.

Изменение returned-handle identity отмечено в review-contract.md. Сборка и runtime выполнялись один раз последовательно на CPU0. Install/pack/size/полной квалификации не было. Frozen fix12, main reviewed6,127 characterization tests и shared cache сохранены. Никаких новых variants после GREEN. Кандидат не опубликован; следующий gate — независимый review immutable packet.
