# Происхождение runtime-пробы

Вход — точный независимый probe.mjs SHA 09d08dd8b596c557c82387c163668d9058c4ca9e5ca7bdec80b216d70d8222ce.
One-shot clock, искусственная очередь timers и действия до наблюдения handoff
сохранены. Assertion для фиксированного runtime требует progress до target=2
без дополнительного stop→setTarget. Исторические RED остаются в reviewer packet.
Raw core bytes берутся из новой canonical build; expected digests фиксируются
перед запуском. Обычные 50 samples, внутри-requestFrame сосед и stale fallback
rejection сравниваются с сохранённым exact object-candidate результатом.
Новые шесть Vitest regression/neighbor tests дополняют эти прежние host истории.
