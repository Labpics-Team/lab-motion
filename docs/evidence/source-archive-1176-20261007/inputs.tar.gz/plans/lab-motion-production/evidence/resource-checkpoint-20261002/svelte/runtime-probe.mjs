import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';

const bindingPath = process.argv[2];
assert.equal(typeof bindingPath, 'string', 'Нужен exact artifact binding');
const binding = JSON.parse(readFileSync(bindingPath, 'utf8'));
const sha = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const packageRoot = resolve(binding.packageRoot);
assert.equal(sha(join(packageRoot, 'package.json')), binding.packageManifestSha256, 'manifest binding mismatch');
for (const [relative, digest] of Object.entries(binding.runtimeFiles)) {
  assert.equal(sha(join(packageRoot, relative)), digest, relative + ': runtime binding mismatch');
}
const require = createRequire(import.meta.url);
const specifier = '@labpics/motion/svelte';
const esmPath = fileURLToPath(import.meta.resolve(specifier));
const cjsPath = require.resolve(specifier);
assert.equal(esmPath, join(packageRoot, 'dist/svelte/index.js'));
assert.equal(cjsPath, join(packageRoot, 'dist/svelte/index.cjs'));
const formats = [['esm', await import(specifier)], ['cjs', require(specifier)]];
const gc = globalThis.gc;
assert.equal(typeof gc, 'function', '--expose-gc missing');
const oldWindow = Object.getOwnPropertyDescriptor(globalThis, 'window');
Object.defineProperty(globalThis, 'window', { configurable: true, value: { matchMedia: () => ({ matches: true }) } });
const outcomes = [];
const retainedOwners = [];
const liveStores = [];
const check = (label, test) => {
  try { test(); outcomes.push({ label, status: 'PASS' }); }
  catch (error) { outcomes.push({ label, status: 'FAIL', message: error instanceof Error ? error.message : String(error) }); }
};
const createStore = (mod) => {
  const store = mod.springStore(0, { mass: 1, stiffness: 200, damping: 20 }, 'instant', () => {
    throw new Error('Reduced-motion witness запросил кадр');
  });
  liveStores.push(store);
  return store;
};
const captureMarker = (owner) => (value) => { globalThis.__svelteResourceObserved = owner.id.length + value; };
const retentionCase = (mod, format, kind) => {
  let marker = { id: format + ':' + kind };
  const ref = new WeakRef(marker);
  let callback = kind === 'uncaptured' ? () => {} : captureMarker(marker);
  const store = createStore(mod);
  const off = store.subscribe(callback);
  let duplicate;
  if (kind === 'duplicate-canceled') duplicate = store.subscribe(callback);
  if (kind === 'off' || kind === 'duplicate-canceled') off();
  if (kind === 'destroy') store.destroy();
  retainedOwners.push(store, off, duplicate);
  marker = undefined;
  callback = undefined;
  return { label: format + ':' + kind, ref, expectedRetained: kind === 'live' };
};

try {
  for (const [format, mod] of formats) {
    check(format + ':canceled-off-preserves-successor', () => {
      const store = createStore(mod);
      const received = [];
      const neighbor = [];
      const callback = (value) => { received.push(value); };
      store.subscribe((value) => { neighbor.push(value); });
      const oldOff = store.subscribe(callback);
      oldOff();
      const successorOff = store.subscribe(callback);
      oldOff();
      store.set(1);
      assert.deepEqual(neighbor, [0, 1], 'положительный контроль доставки');
      assert.deepEqual(received, [0, 0, 1], 'старый off удалил новую регистрацию');
      successorOff();
      store.set(2);
      assert.deepEqual(received, [0, 0, 1], 'активный off не прекратил доставку');
      store.destroy();
    });
    for (const cancelIndex of [0, 1]) check(format + ':duplicate-cohort-' + cancelIndex, () => {
      const store = createStore(mod);
      const received = [];
      const callback = (value) => { received.push(value); };
      const handles = [store.subscribe(callback), store.subscribe(callback)];
      assert.deepEqual(received, [0, 0], 'immediate delivery на каждый subscribe');
      store.set(1);
      assert.deepEqual(received, [0, 0, 1], 'duplicate callback доставляется один раз на изменение');
      handles[cancelIndex]();
      store.set(2);
      assert.deepEqual(received, [0, 0, 1], 'любой duplicate off отменяет старую регистрацию');
      const successorOff = store.subscribe(callback);
      handles[1 - cancelIndex]();
      store.set(3);
      assert.deepEqual(received, [0, 0, 1, 2, 3], 'duplicate old off удалил преемника');
      successorOff();
      store.destroy();
    });
    check(format + ':live-immediate-and-off-control', () => {
      const store = createStore(mod);
      const received = [];
      const off = store.subscribe((value) => { received.push(value); });
      store.set(1);
      assert.deepEqual(received, [0, 1]);
      off();
      store.set(2);
      assert.deepEqual(received, [0, 1]);
      store.destroy();
    });
    check(format + ':broadcast-error-policy-control', () => {
      const store = createStore(mod);
      const failure = { label: 'subscriber failure' };
      const neighbor = [];
      store.subscribe((value) => { if (value !== 0) throw failure; });
      store.subscribe((value) => { neighbor.push(value); });
      let thrown;
      try { store.set(1); } catch (error) { thrown = error; }
      assert.equal(thrown, failure);
      assert.deepEqual(neighbor, [0]);
      store.set(2);
      assert.deepEqual(neighbor, [0], 'существующая fail-fast политика изменилась');
      store.destroy();
    });
  }
  const retained = [];
  for (const [format, mod] of formats) {
    for (const kind of ['live', 'off', 'destroy', 'duplicate-canceled', 'uncaptured']) {
      retained.push(retentionCase(mod, format, kind));
    }
  }
  let deliberate = { id: 'deliberate-retention' };
  const deliberateRef = new WeakRef(deliberate);
  retainedOwners.push(deliberate);
  deliberate = undefined;
  globalThis.__svelteResourceOwners = retainedOwners;
  // Тот же ограниченный GC-turn protocol, что в existing actual-package retention test.
  for (let i = 0; i < 60; i++) { await setImmediate(); gc(); }
  check('deliberate-strong-owner-control', () => { assert.notEqual(deliberateRef.deref(), undefined); });
  for (const { label, ref, expectedRetained } of retained) check(label, () => {
    assert.equal(ref.deref() !== undefined, expectedRetained, label + ': callback ownership не совпало с lifecycle');
  });
} finally {
  for (const store of liveStores) store.destroy();
  if (oldWindow) Object.defineProperty(globalThis, 'window', oldWindow);
  else delete globalThis.window;
}
const failures = outcomes.filter((outcome) => outcome.status === 'FAIL');
console.log(JSON.stringify({ artifactBinding: bindingPath, runtimeIdentity: 'EXACT_BOUND_RUNTIME_BYTES', packagingProof: 'NOT_A_PACKED_TARBALL', resolved: { esmPath, cjsPath }, outcomes, failureCount: failures.length }, null, 2));
if (failures.length) process.exitCode = 1;
