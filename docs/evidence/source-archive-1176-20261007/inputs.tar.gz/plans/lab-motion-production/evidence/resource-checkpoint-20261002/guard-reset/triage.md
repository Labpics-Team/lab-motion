# MotionValue: потерянный callback преемника

CONFIRMED, в области run ownership/liveness. Обе точки — spring getter и listener —
вызывают stop→setTarget(2), затем доставляют новый one-shot callback после возврата
requestFrame, пока прежний tick ещё находится на стеке. Публичный RequestFrameFn
не запрещает такую доставку. Общий boolean guard съедает callback, но старый run
уже отозван и не перепланирует работу: active target, queue=0, timers=0.

Точное RED переиспользовано из независимого reviewer packet; probe, result и все
четыре raw core digest сверены с frozen архивами. Это новая квалификация причины,
без повторного runtime. Внутри-requestFrame сосед уже проходит через trampoline.

Минимальное изменение: перенести существующий `_tickActive=false` из natural
terminal в fresh-start owner до присвоения нового `_run` и host IO. Все старты,
включая старты в final emit, проходят через этот owner. Live retarget и тот же
run guard не меняются. Special terminal reset больше не нужен.

Безопасность shared solver: getter может вложенно исполнить successor, затем старый
solver перезапишет общий scratch; старый tick выходит на post-solver mismatch до
чтения результата и не меняет snapshot successor. Listener видит уже скопированные
value/velocity; после вложенного tick старое continuation не проходит schedule(run).
Каждый tick синхронный: вложенный finally завершается до внешнего, поэтому внешний
finally не может снять guard всё ещё исполняющегося successor. Вложенные рассылки
сохраняют live Map semantics, как уже допускает snapTo внутри listener.

Проверки: 127 прежних тестов без правки; getter/listener after-return regressions,
соответствующие inside-requestFrame соседи, natural final-emit restart, same-run
nested guard. Контроль sample successor с отдельным чистым запуском сохраняет
shared-scratch сценарий. Затем TypeScript, canonical build и ESM/CJS runtime probe
с теми же one-shot hosts; прежние обычные traces сравниваются с сохранённым result.
Размерные варианты/sentinel не входят. Все прежние пакеты и общий cache сохраняются.

Отложенное sentinel inquiry: null как no-callback marker меняет sync callback(null)
с nonzero handle на stall. Reuse captured run identity мог бы различить declared
number/undefined и malformed null без allocation, но требует отдельного доказательства
и локального type narrowing; дельта не применялась и runtime не запускался.
