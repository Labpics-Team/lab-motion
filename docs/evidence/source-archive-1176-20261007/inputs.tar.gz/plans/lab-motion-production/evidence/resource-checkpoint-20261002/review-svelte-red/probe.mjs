import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const packet='/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-svelte-unsubscribe-20261002.swaabiwj/evidence';
const base=dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const hash=x=>createHash('sha256').update(x).digest('hex');
assert.equal(hash(readFileSync(join(packet,'manifest.json'))),'7cc09f452e078fbb5f6c5bee2b16a48177b029ee8a85da70a3d8ecbd80f66655');
const started=new Date().toISOString();
const old=Object.getOwnPropertyDescriptor(globalThis,'window');
Object.defineProperty(globalThis,'window',{configurable:true,value:{matchMedia:()=>({matches:true})}});
const result=[];
function store(mod) {
  return mod.springStore(0,{mass:1,stiffness:200,damping:20},'instant',()=>{throw Error('Unexpected frame');});
}
function scenarios(mod) {
  const out={};
  {
    const s=store(mod),trace=[],failure={kind:'initial'},run=v=>{trace.push(v);if(trace.length===1)throw failure;};
    assert.throws(()=>s.subscribe(run),e=>e===failure);
    s.set(1);
    assert.deepEqual(trace,[0,1]);
    const off=s.subscribe(run); off(); s.set(2);
    assert.deepEqual(trace,[0,1,1]); s.destroy();
    out.initialThrowKeepsRegistration=trace;
  }
  {
    const s=store(mod),trace=[],failure={kind:'duplicate'};
    let shouldThrow=false;
    const run=v=>{trace.push(v);if(shouldThrow){shouldThrow=false;throw failure;}};
    const off=s.subscribe(run);shouldThrow=true;
    assert.throws(()=>s.subscribe(run),e=>e===failure);
    s.set(1);off();s.set(2);
    assert.deepEqual(trace,[0,0,1]);s.destroy();
    out.duplicateThrowKeepsRegistration=trace;
  }
  {
    const s=store(mod),trace=[];
    let swapped=false,offB;
    const b=v=>trace.push('b'+v);
    const offA=s.subscribe(v=>{
      trace.push('a'+v);
      if(v===1&&!swapped){swapped=true;offB();offB=s.subscribe(b);}
    });
    offB=s.subscribe(b);s.set(1);offA();s.set(2);
    assert.deepEqual(trace,['a0','b0','a1','b1','b1','b2']);offB();s.destroy();
    out.broadcastDeleteReinsert=trace;
  }
  {
    const s=store(mod),trace=[];
    const off=s.subscribe(v=>{trace.push(v);s.destroy();});
    off();s.destroy();s.set(1);
    assert.deepEqual(trace,[0]);out.destroyDuringImmediate=trace;
  }
  {
    const s=store(mod),trace=[];
    const a=s.subscribe(v=>{trace.push('a'+v);if(v===1)s.destroy();});
    const b=s.subscribe(v=>trace.push('b'+v));
    s.set(1);a();b();s.set(2);
    assert.deepEqual(trace,['a0','b0','a1']);out.destroyDuringBroadcast=trace;
  }
  {
    const s=store(mod),trace=[],run=v=>trace.push(v);
    const a=s.subscribe(run),b=s.subscribe(run);
    out.sameActiveRevoker=a===b;
    assert.equal(typeof a,'function');assert.equal(a.length,0);
    s.set(1);b();s.set(2);a();
    assert.deepEqual(trace,[0,0,1]);s.destroy();out.duplicateDelivery=trace;
  }
  return out;
}
try {
  for(const [version,name] of [['baseline','raw-artifact-binding.json'],['candidate','candidate-runtime-binding.json']]) {
    const binding=JSON.parse(readFileSync(join(packet,name),'utf8'));
    assert.equal(hash(readFileSync(join(binding.packageRoot,'package.json'))),binding.packageManifestSha256);
    for(const [p,h] of Object.entries(binding.runtimeFiles))assert.equal(hash(readFileSync(join(binding.packageRoot,p))),h,p);
    for(const format of ['esm','cjs']) {
      const path=join(binding.packageRoot,'dist/svelte/index.'+(format==='esm'?'js':'cjs'));
      const mod=format==='esm'?await import(pathToFileURL(path).href):require(path);
      const checks=scenarios(mod);
      assert.equal(checks.sameActiveRevoker,version==='candidate');
      result.push({version,format,runtimeSha256:hash(readFileSync(path)),validatedRuntimeFiles:Object.keys(binding.runtimeFiles).length,checks});
    }
  }
  for(const format of ['esm','cjs']) {
    const a=result.find(r=>r.version==='baseline'&&r.format===format).checks;
    const b=result.find(r=>r.version==='candidate'&&r.format===format).checks;
    const {sameActiveRevoker:x,...aa}=a,{sameActiveRevoker:y,...bb}=b;
    assert.deepEqual(aa,bb);
  }
} finally {
  if(old)Object.defineProperty(globalThis,'window',old);else delete globalThis.window;
}
const report={status:'PASS',started,finished:new Date().toISOString(),pid:process.pid,
  node:process.version,cpuAllowed:readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.*)$/m)[1],
  scriptSha256:hash(readFileSync(fileURLToPath(import.meta.url))),result,
  scope:'Independent direct exact ESM/CJS bytes; no pack/install/build, GC rerun, or scale proof'};
writeFileSync(join(base,'probe-result.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
