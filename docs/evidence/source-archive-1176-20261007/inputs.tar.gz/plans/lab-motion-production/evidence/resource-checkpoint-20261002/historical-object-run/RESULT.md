# Результат единственного кандидата MotionValue

Заменены два поля running/generation одним объектом активного запуска. Только
`src/motion-value.ts` отличается от best12. Объект свежий на старте из покоя,
сохраняется при live retarget, отзывается при stop/snap/destroy/terminal.
Таблица переходов передана root до runtime; её digest сохранён в inputs.json.

Проверки: 127 тестов / 5 suites — Да; TypeScript — Да; canonical tsup — Да;
canonical size — Нет (exit 1). Единичный последовательный запуск CPU0,
точные команды/время/source digest — в четырёх stage receipts. Других вариантов нет.

| Consumer | best12 gzip | Кандидат gzip | Порог |
|---|---:|---:|---:|
| only-MotionValue | 1653 | 1640 | 1660 |
| full-core | 2354 | 2340 | 2330 |
| compositor-stagger | 6625 | 6611 | 6600 |
| compositor-follow | 6474 | 6459 | 7474 |
| animate + compositor | 17149 | 17144 | 17500 |
| animate facade | 15245 | 15245 | 15600 |
| animate scope | 15550 | 15550 | 15700 |

Shipped core теперь PASS, stdout показывает 2.15 KB gzip против 2.17 KB best12;
точные shipped-байты из округления не выводятся. Полный вектор: 45 shipped entries,
16 consumers в full-size-vector.json. Остальные gzip-сценарии неизменны.
Brotli only-spring: 612→613 (+1), поэтому строгого Pareto-улучшения всех метрик нет.
Числового утверждения об allocation/heap/скорости нет: один пустой объект на новый
запуск является новой стоимостью; live retarget объектов не создаёт.

Обычная one-shot scheduler-семантика сохранена в characterization-проверках.
Отдельное усиление: callback естественно завершённого запуска после следующего
старта отвергается новым identity; best12 мог принять его с тем же generation.
Это исходный анализ, replay-probe не запускался. Полная эквивалентность для
произвольного повторения host callback не утверждается.

Кандидат сохранён только в отдельном sibling; best12, main reviewed6, Svelte frozen
packet и общий Vite cache сверены и сохранены. Перед поставкой root решает о
принятии per-run allocation/границы replay и выполняет независимое ревью. Size
остаётся открытым: full-core +10 B, stagger +11 B. Нет push/commit/merge/release,
нет numeric resource calibration, нового SpringParams snapshot или ослабления guards.
Для отката достаточно отказаться от isolated candidate; исходная база не менялась.
