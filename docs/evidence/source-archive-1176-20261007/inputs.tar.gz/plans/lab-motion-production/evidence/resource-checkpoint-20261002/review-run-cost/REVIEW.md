# MotionValue active-run identity: стоимость и совместимость

**PASS в узкой оси архитектурной соразмерности и consumer compatibility; подтверждённых findings в этой оси нет.** Объектный token заменяет два согласуемых private поля и остаётся внутри владельца frame loop. Он не добавляет второй scheduler, публичную run identity или домен Lab UI. Его цена — одна явная allocation на новый active run; runtime/retained-memory выигрыш не доказан. Общий size gate остаётся RED.

Это source-only review. Оно не заменяет независимую проверку переходов/host histories и не голосует за runtime correctness. `transition-table.md` автора и чужие reviewer reports не читались.

## Объект

- Candidate manifest: `60cfe60a95e58a70b30681affa3ba43fbbc70a6fc80807f6dbbf820a521e1603`.
- Candidate `src/motion-value.ts`: `0256d46a682a46774c2a04e930097d1d576fb9947ca941930ecbbd69bef4c8e6`.
- Baseline best12 source: `55a57c907b0d505d1d0053c0fe572949ac6122c91e2e0777c89bc8bb7db69632`.
- Narrow patch: `a6e982c38c5d18a6ba7e92023b99ee5f77b86ac4d59e38cf898fc5b43458f7c8`.
- Source archive: `6cd7676acd39c0c8f92a52faafb67d0a9d39042156f8469b237cb2ddd5d937e8`.
- Источник: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-motion-value-run-identity-20261002.hua2jvc3/evidence`. Копии прочитанных inputs и их bindings сохранены отдельно в этом packet.

Исходный consumer result: надёжные общие Motion primitives для Lab UI. Run ownership принадлежит MotionValue; состояние sheet/carousel, gesture history и выбор spring policy остаются потребителям. В данном patch эти границы не расширяются.

## Владение и архитектурный эффект

`_run: object|null` (`src/motion-value.ts:169`) одновременно отвечает на два связанных вопроса: есть ли active frame loop и принадлежит ли выданный callback этому loop. Единственное место создания `{}` — переход из покоя в setTarget (`:305–309`). Stop, snap, destroy и окончание run отзывают эту identity через null. Проверки schedule/tick сравнивают её с захваченной identity.

Таким образом заменяются `_running` и `_generation`; параллельный механизм не появляется. `_tickActive` остаётся orthogonal guard текущего входа в tick, а `_useTimeoutFallback` — способом доставки host callback. Они не дублируют run identity и их объединение потребовало бы другой контракт.

Решение локально скрывает способ freshness проверки. Existing binding/compositor consumer по-прежнему вызывает setTarget/stop/snapTo/destroy и получает value/velocity; ему не нужно знать token, generation, новую стадию или policy. SpringParams reference/getter semantics, registry owner и solver representation этим diff не заменяются. Нет новой infrastructure/service зависимости или общего mutable registry.

## Allocation и retention: что следует из source

- При каждом фактическом idle→active запуске создаётся один пустой объект. Live retarget сохраняет его; _schedule/_tick и последовательные кадры новый token не создают. Повторная активная цель — прежний early return.
- Stop/snap/destroy не создают replacement token. После них следующий active start создаёт новый.
- Token не содержит ссылок на MotionValue, SpringParams, listeners или scheduler. Его захватывают уже существующие host/fallback callback closures; эти closures и прежде захватывали this и scalar generation.
- После отзыва старый token может оставаться достижимым через недоставленный host callback. При частом start/stop это добавляет пустой token на каждый такой удерживаемый run. Нельзя называть его бесплатным или уже собранным только потому, что _run обнулён.
- Дополнительного пути от token к компоненту/callback owner нет. Сохранение/очистка payload ссылок остаётся существующему destroy/listener механизму. Это анализ направлений ссылок, не выполненный GC эксперимент.
- Удаление одного instance field не доказывает суммарного уменьшения heap: object header, representation instance slots, closure contexts, alignment и работа GC зависят от engine. Числа retained bytes, peak heap, latency и restart throughput здесь неизвестны.

Для обычного pointer-follow сценария множество setTarget между кадрами не превращается в множество token allocations: активный run сохраняется. Для частого stop/start allocation происходит на каждом новом run; это честный tradeoff и потенциальный объект отдельного измерения, если целью станет runtime-memory/latency улучшение. Такое измерение не требуется, чтобы утверждать только локальную структурную соразмерность.

## Более простые варианты

**Оставить best12** допустимо: boolean+numeric generation не требует явного heap token на каждый старт. Candidate не доминирует baseline по всем стоимостям; его преимущества — единая private identity и подтверждённый небольшой import-size выигрыш.

**Оставить только boolean, target или существующий SpringParams object** нельзя считать эквивалентным сокращением: stop→resume к той же цели использует те же значения и ссылки, поэтому старый callback нельзя различить с новым. Это именно потребительская история, которую existing tests описывают.

**Один signed numeric generation** может кодировать active/idle в знаке и сохранять счётчик, но вводит arithmetic convention, переходы через sentinel и предел точности number. `number|null` теряет предыдущее значение после null либо требует второго serial counter. Это возможные альтернативы для отдельного сравнения, но не очевидно более простое решение с теми же indefinite-freshness свойствами.

**Symbol token** также даёт fresh identity, но не устраняет allocation/engine cost автоматически; выигрыша относительно `{}` здесь не измерено. Pool/reuse token до доказанного окончания всех старых callbacks возвращает identity aliasing и потребовал бы дополнительного механизма quiescence.

**Использовать один постоянный host callback как token** нельзя считать механическим упрощением: текущий per-request closure хранит sync/called/timestamp для trampoline и late callback поведения. Такое объединение затронуло бы request ownership и потребовало нового разбора, не только удаления пустого объекта. Новая общая run abstraction из этого patch не следует.

## Публичный контракт и tests

Типы MotionValueOptions/RequestFrameFn, constructor arguments, value/velocity и методы onChange/setTarget/stop/snapTo/destroy неизменны. Run token наружу не возвращается; он не новый cancel handle. Imports/package dependencies и subpath export shape не меняются. Reflection/сериализация TypeScript-private fields не представлены публичным контрактом этого snapshot.

`docs/api.md:157–174` обещает перенаправление того же значения при live retarget, отсутствие дополнительных callbacks между кадрами и новую epoch после stop/snap. Private empty token на новом запуске не создаёт новый public animation object; live retarget сохраняет и MotionValue, и token. Документ не обещает нулевых внутренних allocations при любом запуске.

Прочитаны source assertions потребительских историй: destroy не вызывает spring getters и сохраняет snapshot (`test/motion-value.test.ts:207–231`); queued stale frame после stop/resume не удваивает цикл (`:554–574`); retarget из onChange и resume той же цели (`test/motion-value-follow.test.ts:123–142,192–205`); fallback ownership (`:208–230`); одна очередь при live retarget и stop+setTarget из onChange (`test/motion-value-mutation-harden.test.ts:198–209,337–356`).

Пять characterization test files побайтно совпадают с независимым прежним source snapshot, где MotionValue имеет exact best12 digest. В assertions нет зависимости от нового private имени _run. Некоторые historical mutation comments называют старые _generation/_running; они описывают прежнее место sabotage, а behavioral assertions остаются публичными. Это не используется как доказательство прохождения нового mutation run.

Сохранённый raw unit stdout сообщает 127 PASS. Здесь эти tests не исполнялись и этот лог не превращается в утверждение полноты произвольных host histories.

## Размеры по двум raw stdout

Сравнение выполнено чтением закреплённых результатов одного канонического вида: import-cost ESM через esbuild bundle/minify, gzip-9 и Brotli-11. Новых builds или compression runs нет.

Baseline raw stdout SHA256: `0e0cbe4394bf36f7e9ac44848136666a9621e272b0c22c21c08cb779265ca142`.
Candidate raw stdout SHA256: `be95718c510c00a5c68fe0a7184af5c419ae6bb7acc502fdd31935dddcc6f6eb`.
Полные 16 consumer comparisons — `SIZE-AND-TEST-BINDINGS.json`.

| Consumer | gzip best12 → candidate | Brotli best12 → candidate |
|---|---:|---:|
| only-MotionValue | 1653 → 1640 B | 1541 → 1531 B |
| full-core | 2354 → 2340 B | 2184 → 2171 B |
| compositor-stagger | 6625 → 6611 B | 6095 → 6051 B |
| compositor-follow | 6474 → 6459 B | 5929 → 5921 B |
| animate + compositor | 17149 → 17144 B | 14225 → 14221 B |
| only-spring | 660 → 660 B | 612 → 613 B |

Остальные 10 consumer rows совпадают. Нельзя утверждать улучшение каждого размера: only-spring Brotli вырос на 1 B при неизменном gzip и пройденном его gate. Candidate raw gate всё ещё сообщает full-core `2340>2330` и compositor-stagger `6611>6600`, exit 1. Это существующие открытые delivery gates; этот review не разрешает их ослаблять и не называет slice поставленным.

Уменьшение compressed import bytes не измеряет allocation cost или скорость. Для данного структурного эксперимента оно подтверждает маленький source/artifact benefit, а не само по себе оправдывает любую runtime цену.

## Итог оси

PASS означает: локальный owner оправдан, public consumer не получает новую обязанность, явного более простого эквивалентного варианта с доказанно лучшей полной стоимостью не найдено, allocation/retention tradeoff раскрыт. Подтверждённых дефектов этой оси нет.

**Да:** exact source/diff/manifest binding; source-only ownership/compatibility review; unchanged test-byte comparison; сверка двух raw size stdout; собственный manifest/readback.
**Нет:** общий размерный gate candidate по сохранённому raw stdout (два consumer thresholds).
**Не было:** новых tests/build/install, runtime/GC/retention/latency измерений, исполнения архивного кода, чтения transition-table.md или других reviewers, Windows, source edits, новых агентов, memory writes, публикации.
Независимая ось correctness, exact-head CI и delivery admission принадлежат root и соответствующим reviewers.
