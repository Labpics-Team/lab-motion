# Architecture Review

## Violations

Подтверждённых нарушений на назначенной оси нет. Контрпримера вакуумности или ложного GREEN текущего terminal-retention oracle не обнаружено.

## Compliant patterns

- `test/resource-actual-package-retention.test.ts:43–118` — реальный scoped package, сверка runtime bytes, tarball installation и публичные import/require subpaths.
- `test/resource-actual-package-retention.test.ts:189–268` — удерживаемый controller, отдельные target/effect WeakRef, обе истории и live/deliberate controls.
- `src/compositor/follow.ts:124–136`, `src/compositor/core.ts:769–808` — terminal делегирует освобождение существующему superclass; тест наблюдает публичное поведение.
- `red.log:8–18`, `green.log:4–8` — deliberate omission superclass cleanup обнаружен внутри installed consumer; исходный production проходит тот же test.

## Verdict: PASS

PASS относится к корректности и невакуумности данного actual-package terminal-retention oracle. Он не закрывает весь RESOURCE-01, tracker bytes, физическую native/GPU память, browser correctness или production release.

## Норма и точный артефакт

Исходное намерение: foundation LabUI; generic movement остаётся в library, component policy — у recipes. Контракт `plans/plans/lab-motion-production/r11.md:299` требует actual-package terminal retention наряду с отдельными resource obligations. SHA256 r11: `cbeef108b288502165437c375bb259f3f4d6dc8ae4ae9e926db133adeba40d4b`.

Packet: `/home/labpics-ops/work/colors-motion-20261001/evidence/motion/resource-follow-retention-8830-20261001/`.

| Объект | Identity |
|---|---|
| Git base / tree | `8830e6b2961472e78414ee6ef3ced7f3aabc1556` / `88ab97713d5ebd62b12adebc1e7ac5cd2d7082b7` |
| `candidate-source.tar` SHA256 | `ba0e8b26cca6a70d9986267e8bc8091127557d2712b8e01fd7e4b14f11250d5f` |
| `candidate-test.ts` SHA256 | `0f99982542cb66b71d0d6793032f32c31e36d8cd6f13bf31b9277d7466dd2c9f` |
| `candidate.diff` SHA256 | `3fbb105b10b3fad63fa8c326e8a93b04f73ab3f9093252bd5659dfafb521fb6f` |
| `MANIFEST.json` SHA256 | `9a2037bc8cf4467edf2a5d0517fa3635718f91c2152e9c24e1dfef3b0df11b04` |

Архив прочитан в памяти без распаковки/исполнения. Все 617 файлов совпадают с source manifest по путям и SHA256. Сравнение Git blob identity с base даёт ровно одну delta: `test/resource-actual-package-retention.test.ts`. Baseline test совпадает с Git blob; candidate diff совпадает с текущим Git diff; tracked bytes зеркала `motion-follow` совпадают с tar. Production source unchanged.

Mutant manifest отличается только `src/compositor/follow.ts`; сохранённый mutant-файл получается точным удалением `super.destroy();`. Candidate test одинаков. Проверены 32 digest bindings packet-файлов, исключая авторский REPORT. MANIFEST сохранён дополнительным входом. Авторский REPORT и чужие вердикты/рассуждения не читались.

## 1. Реальный installed package и ESM/CJS

`copyTrackedSource` (`test:25–40`) берёт актуальные tracked source bytes. Временный package manifest ограничивается тремя существующими exports (`:54–59`); их import/require объекты не переписываются. `tsup.config.ts:64–101` выводит entry points из exports и строит оба формата. `package.json:349–357,379–397` задаёт frame/compositor/follow цели.

Тест сравнивает шесть rebuilt файлов с соответствующими файлами полной production-сборки (`test:65–75`), выполняет pack и устанавливает tgz через `npm install --ignore-scripts` в отдельный consumer (`:77–102`). Probe находится в этом consumer и импортирует публичный `@labpics/motion/compositor/follow` через ESM/require (`:104–118`), без TypeScript source import.

| Follow entry | SHA256 сохранённого candidate-dist |
|---|---|
| `compositor/follow/index.js` | `f07a6111a7ab0dcf08cf080b6b364289f68252d2d5d61b41aaaf24d86372dde6` |
| `compositor/follow/index.cjs` | `06605889f809c927f28f08416fd0f8247ec3b56bcb8050dd936dbc162159337d` |

Сохранённые bytes совпадают с manifest/green receipt. Это parity каждого entry со своей полной сборкой и одинаковых behavioral assertions в двух форматах, не равенство ESM и CJS bytes. Установлен scoped package с ограниченными exports; полный release tarball, types и остальные exports эта ось не проверяет. Временный tgz удаляется finally (`test:279–280`), отдельного immutable install artifact нет. Полный successful test и обязательные byte assertions подтверждают scoped execution, но не подписанную provenance цепочку публикации.

## 2. Удерживаемый controller и освобождаемые объекты

`followCase` создаёт target с animate; возвращённый effect содержит `target: this`. Для target и effect сохраняются отдельные WeakRef (`test:193–203`). Callbacks format/apply захватывают target (`:210–211`). Таким образом retained effect и retained callback способны удержать target; probe проверяет разрыв этих путей.

Controller сохраняется в retainedOwners, локальный target снимается (`:224–226`), owner-array закрепляется на `globalThis.__resourceOwners` (`:257`). Поэтому collectability не объясняется удалением самих controllers. Production superclass хранит callbacks/target (`core.ts:444–452,511–516`), terminal очищает их (`:769–778`), `_releaseHost` снимает host slot до cancellation (`:805–808`). Follow destroy делегирует туда (`follow.ts:124–127`). Private field names не входят в oracle.

## 3. Обе истории и контроли

Общий префикс — `beginFollow → follow → settle` (`test:215–217`). Animate должен быть вызван ровно один раз, cancellation сразу после settle — ноль (`:218–219`): noop/reduced/live-only setup не может пройти как native-owner case.

| История для каждого ESM/CJS | Cancellation | После GC при удержанном controller |
|---|---|---|
| settle → destroy | один cancel при destroy | target и effect недоступны |
| settle → pickup → destroy | один cancel при pickup; destroy не повторяет | target и прежний effect недоступны |
| settle, live control | ноль cancel | target и effect доступны |
| settle → pickup, live control | один cancel | target доступен, прежний effect освобождён |

Цикл `test:241–250` выполняет все строки для обоих форматов. Pickup live-control отделяет освобождение native donor от разрушения input-owner. Deliberate-retention object имеет сильную ссылку в owner-array и обязан пережить GC (`:252–268`). Это вместе с live controllers защищает от oracle, который ошибочно считает все WeakRef очищенными; deliberate control не назван production mutant.

GC вызывается 60 раз, каждый после await setImmediate; deref идёт только после цикла (`:258–268`). WeakRef не перечитываются в каждом GC-turn и не поддерживают keep-alive проверяемых объектов текущим job. Probe требует globalThis.gc, использует --expose-gc и timeout 20 секунд (`:119–120,274–278`).

## 4. RED относится к terminal boundary

Мутация удаляет только superclass cleanup (`mutant.diff:3–10`). Candidate ESM/CJS dist содержит делегацию super.destroy(), mutant ESM/CJS — нет; frame/compositor bytes совпадают. `mutant-build.json` фиксирует exit 0, raw `mutant-build.log:209–220,277–280` содержит успешные CJS/ESM сборки follow.

Raw RED падает в установленном `consumer/resource-retention.mjs`, followCase: `follow-esm-settled-dropped: terminal owner должен освободить native effect ровно один раз`, actual 0, expected 1 (`red.log:8–18`). Ошибка следует после byte-parity, pack/install/import и animateCalls=1. Это terminal cancellation failure, не setup/compiler failure; `red.json:13` фиксирует exit 1.

Предел RED: он возникает до GC-loop. Этот прогон не доказывает, что mutant пойман именно WeakRef assertion, и не доказывает отдельный CJS mutation-kill: процесс остановился на ESM settled case. Для невакуумности совокупности lifecycle + collectability assertions это релевантный deliberate sabotage; требования отдельного mutant для каждого WeakRef в назначенном контракте нет. Более сильный GC finding не заявляется.

## 5. GREEN и пределы

`green.json:11–13` фиксирует 2026-10-01T05:53:27Z–05:54:12Z, exit 0; raw `green.log:4–8` — complete test success. PASS-marker выводится только после всех GC/live/deliberate assertions (`test:269`), внешний test его требует (`:284–285`). Поэтому GREEN включает оба формата и все истории.

Среда receipt: Linux, Node 24.21.0, Vitest 4.1.11. `toolchain-context.json:2–12` связывает repository cwd с объявленным pnpm 11.11.0; unscoped pnpm 12.8.1 из final-source-state не подменяет cwd-specific pack toolchain. Reviewer не запускал новую версионную диагностику. GC timing на других движках не доказан.

Native effect в probe — контролируемый JavaScript handle с cancel/currentTime/target, не настоящий browser Animation или GPU allocation. GREEN подтверждает cancellation и collectability этого графа. Он не доказывает:

- физические native/GPU bytes или browser rendering correctness;
- budget tracker samples/bytes: tracker не является WeakRef-субъектом;
- полный hostile/reentry/throwing-host/time/resource envelope;
- отсутствие всех утечек, timing гарантию GC либо готовность всего RESOURCE-01.

Старый cache assertion (`test:124–136`) проверяет capacity/size/clear API, не retained bytes. Эти ограничения не объявлены найденным leak и не требуют выдуманной production правки.

## Проверки и сохранность

- **Да:** tar/test/manifest hashes, 617 source bindings, exact test-only Git delta, одинаковый test в mutant, raw build/RED/GREEN, ownership/control logic и scoped ESM/CJS path.
- **Не было:** новые tests/build/install/verifiers, browser/Windows, новые агенты, memory, source/plan изменения, merge/deploy.
- Зеркало сохраняет исходный dirty state: только назначенный test; production совпадает с base. Reviewer не исправлял авторский artifact.
- Авторский REPORT и чужие verdicts не использованы. INPUTS содержит первичные материалы, выбранные source bytes, полный inventory bindings и норму.

## Входной пакет review

`INPUTS.json`: 654 562 байта, SHA256 `803e47d42e1fdaa9813a5ef59dd79eb7e11ac9fa56b9443ac97a6aa0c05c43da`.

Собственные REPORT/INPUTS/MANIFEST замораживаются правами 0444; digest readback возвращается при выдаче результата. Хеш REPORT передаётся отдельно без самоссылки.
