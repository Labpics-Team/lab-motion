# Architecture Review

Дата: 2026-10-01. Ось: архитектурная цена resource fix и конкретное более простое локальное решение при сохранении terminal ownership, старых контрактов и ceilings. Это не полный correctness/resource gate.
Workspace: `/home/labpics-ops/work/colors-motion-20261001`. Candidate: `evidence/motion/resource-motion-value-unsubscribe-fix6-20261001/candidate-motion-value.ts`, SHA256 `21badb4ab10d699724ba3675a5cd0098fa00f05c99fc95dc7d9f57d8d9b03395`; diff `a3a5effc64137f7bb0fe898e4445fa06cd2234a12856986b29b916002923ed02`.
Base: `motion-follow@33f496a0b8350b1902b5c7651b2886ecf95102ed`, tree `b5bd203972f82c6de44286acb31023f3855a0557`. Норма: `plans/plans/lab-motion-production/r11.md`, SHA256 `cbeef108b288502165437c375bb259f3f4d6dc8ae4ae9e926db133adeba40d4b`, строки 118–132, 312–314.

## Violations

- `size.stdout.log:71–73,80` [action_required] [сохранение cost guards] — candidate имеет 1670/2370/6637 B gzip при ceilings 1660/2330/6600; превышение 10/40/37 B. M-07 не разрешает регрессию другой защищённой клетки. Значения привязаны к candidate hashes в `size.json:15–18`; прежние ceilings подтверждены `scripts/size-gate.mjs:118,140,356` на base → defer fix to Motion core builder.
- `candidate-motion-value.ts:507–514` [recommended] [необходимая цена представления] — Map уже хранит пару callback→off, однако `_emit` обходит keys, повторяет get и допускает отсутствующий off. Один конкретный локальный вариант: обходить готовые пары через `Map.forEach((off, cb) => …)`, сохранив текущие try/catch, failed/firstError и throw после обхода → defer fix to Motion core builder.

## Почему это допустимый локальный вариант

Map.forEach передаёт текущие off и cb до пользовательского вызова. При off→повторной регистрации→throw catch получает прежний off; его закрытый listeners уже null, поэтому новая регистрация не отзывается. Удаление непосещённого соседа пропускает его, добавление в конец допускает последующую доставку, destroy очищает оставшийся обход: это та же наблюдаемая семантика текущего Map iterator. Reentrant `_emit` сохраняет собственные failed/firstError. Нельзя заменять эти две переменные truthy-проверкой ошибки: callback может бросить undefined.

Вариант удаляет повторный поиск, keys-итератор и optional-вызов; он не вводит persistent fields, новый lifecycle/API или scheduler protocol. Но создаёт callback-замыкание на каждый `_emit`; выигрыш gzip и суммарная цена closure против iterator не измерены. Нет доказательства, что этот единственный шаг закроет 10/40/37 B. Builder должен проверить тот же consumer vector и сохраняемые случаи duplicate registration, retired-off/reentrant successor, destroy внутри callback, первый throw и actual-package retention. Это рекомендация кандидата, не обещание GREEN.

## Compliant patterns

- `candidate-motion-value.ts:134–146,231–259,327–333` — nullable spring одновременно обозначает terminal и разрывает ссылку на пользовательские metadata; отдельный destroyed-флаг убран. Map с единственным off на регистрацию оправдан: голый Set и старые closures из base сохраняли callback/экземпляр после terminal; возврат к ним не является безопасным упрощением.
- `candidate-motion-value.ts:381–416,438–443` — guards до host IO, после host callback и после solver/getters защищают разные reentrant-границы. Их удаление ради байтов не обосновано. MotionValue не получает знаний о sheet/carousel; UI-протокол не переносится в core.
- `candidate.diff` — сброс CompositorSpring на общий DEFAULT_SPRING ограничен terminal boundary. Не предложены новый subscription store, общий disposal-framework или второй scheduler.

## Verdict: FAIL

Текущий candidate не проходит сохранённые cost guards. Архитектурно обоснован один локальный вариант упрощения `_emit`; его размерный/runtime результат ещё неизвестен. В сохранённых outputs targeted unit slice завершён успешно (111 tests, 5 файлов), size gate — exit 1; это не full gate.
Проверки **Да**: exact candidate/diff/plan hashes, base identity/source, статический разбор владения и сохранённых unit/size outputs. **Не было**: code edits, tests/build/bench, Windows, памяти, новых threads или чтения журналов других кандидатов. Собственные REPORT/MANIFEST заморожены `0444` и сверены точным readback.
