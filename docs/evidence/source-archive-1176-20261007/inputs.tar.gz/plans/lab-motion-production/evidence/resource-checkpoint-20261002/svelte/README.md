# Svelte RESOURCE: подготовка RED

Статус PREPARED_NOT_EXECUTED. CPU0 занят независимым reviewer; tests/build/install не запускались. Product source не изменён.

Source-level counterexample: subscribe(cb), oldOff(), subscribe(cb), oldOff(), set(1). Текущий Set.delete(cb) отзывает преемника. Дополнительный witness: два duplicate handles старой регистрации, один отменяет её, затем после нового subscribe вызывается второй старый handle. Контроль сохраняет immediate delivery при каждом subscribe, одну broadcast-доставку на callback и прекращение доставки активной отпиской.

Retention witness держит store и off после off/destroy; callback замыкает marker. Expected: marker собран; live callback и deliberate strong owner остаются. Uncaptured marker — контроль достижимости сбора. GC protocol повторяет существующий resource-actual-package-retention test:60 event-loop turns с exposed GC. Подготовленный runtime probe проверяет ESM/CJS через публичный @labpics/motion/svelte и сверяет90 файлов с raw-artifact-binding.json до import. Это точные canonical runtime bytes fix12, но не доказательство packed/installed tarball.

Публичный контракт: src/svelte/index.ts:40–45 immediate/current и unsubscribe;60–62 destroy cleanup. Existing tests: test/svelte.test.ts:87,101,154; test/svelte-current-value.test.ts:8. Duplicate callback хранится в Set один раз; identity возвращаемых off функций отдельно не обещана. Проект исправления отправлен владельцу до implementation; source fix ждёт выполнения RED и решения по этой границе.

Разрешённый последующий запуск после освобождения CPU0:

`taskset -c 0 /home/labpics-ops/work/colors-motion-20261001/tools/motion/node-v24.21.0-linux-x64/bin/node --expose-gc resource-svelte-probe.mjs ../evidence/raw-artifact-binding.json`

Рабочая директория — baseline-consumer. Timeout20s; stdout/stderr и exit receipt должны сохраняться. Для focused source RED: прямой Vitest binary, один fork/worker, private vitest.config.mjs и private TMP/cache; без pnpm wrapper. Никакого автоматического запуска из этого документа нет.
