# Architecture Review

Дата: 2026-10-02. Ось: correctness/resource lifetime Svelte subscribe/off/destroy, RESOURCE/M-07.
Объект: `../../tmp/motion/resource-svelte-unsubscribe-20261002.swaabiwj/evidence`.
MANIFEST (`manifest.json`) SHA256: `7cc09f452e078fbb5f6c5bee2b16a48177b029ee8a85da70a3d8ecbd80f66655`.
Narrow patch (`svelte.patch`) SHA256: `99d00597192d182a0508c46caf5109a61620433fe1d4c675db0b23a8cd6ce64b`.
Candidate source SHA256: `c943ffb39fecf4bfed21ad8145181ed8d9e0433a66874b7e1c79ec7e7d45e552`; baseline: `fa802235b5c8b29843abd24bce3c99fd11be7786c5e4ff13c9ae9da73fd5ad53`.
Source archive SHA256: `e9009a76e32436c0e077c7eaacf06fa06255965cfc501fb15a8950051c518e16`; runtime archive: `6ac950f7ee7a60c730707423602cc124aa03c7510a8b428b92ea0318fd86eca9`.

## Violations

Подтверждённых нарушений в назначенной области нет.

## Compliant patterns

- `src/svelte/index.ts:110–127` — одна активная регистрация callback владеет revoker. Первый off удаляет запись и обнуляет callback/registry; повторный off больше не обращается к Map и не удаляет преемника с тем же callback. Duplicate subscribe разделяет это состояние отзыва, сохраняя immediate вызов при каждом subscribe и одну доставку при broadcast.
- `src/svelte/index.ts:142–144` — destroy сначала завершает MotionValue, затем вызывает каждый revoker. Удаление текущего элемента при Map.forEach допустимо; внешние off handles сохраняют обнулённые ячейки, а не callback owner. `src/motion-value.ts:330–335` не вызывает пользовательские callbacks при destroy, поэтому очистка не создаёт нового reentrant пути.
- `src/svelte/index.ts:103–106,113,126` — порядок живого обхода и прежняя fail-fast политика сохранены. Ошибка immediate callback оставляет регистрацию, как в baseline. Новый probe подтвердил initial/duplicate immediate throw, удаление и повторное добавление callback при broadcast, destroy из immediate и broadcast.
- `test/svelte-unsubscribe-lifecycle.test.ts:20–68` — regression проверяет stale off, обе позиции duplicate off, живого соседа и прежнюю errorpolicy. Raw receipts показывают baseline focused 3 FAIL / 1 PASS; candidate 19 targeted tests PASS. Контрактные тесты baseline в source archive побайтово сохранены.
- `runtime-probe.mjs:43–57,124–147` — callbacks действительно захватывают owner, а stores и off handles удерживаются после отмены. Есть live, uncaptured и deliberate strong-owner controls; исходный runtime дал 12 FAIL / 9 PASS, candidate — 21 PASS. Это достижимость owner после 60 GC turns на данном Node/runtime, не калибровка retained bytes.

## Function identity и граница совместимости

`src/svelte/index.ts:111–114` наблюдаемо меняет `subscribe(run) === subscribe(run)`: baseline false, candidate true для одной активной регистрации. Независимый ESM/CJS probe подтвердил различие. Тип `() => void`, форма SpringStore и семантика «любой duplicate off отзывает общую регистрацию» сохранены.
В интерфейсе, найденных публичных docs и existing tests нет обещания новой function identity. Поэтому это не подтверждённое нарушение назначенного контракта. Полная наблюдаемая эквивалентность для потребителя, использующего off как уникальный Map/Set key либо хранящего свойства на функции, не заявляется. Такое ожидание потребителя потребовало бы отдельного контракта; его наличие здесь не доказано.

## Независимая проверка

Все 43 manifest entries проверены. Source archive содержит точные candidate/test bytes, narrow patch затрагивает только два согласованных файла. Проверены все 90 runtime hashes для baseline и candidate; runtime archive совпал с candidate binding. Изменены только `dist/svelte/index.js` и `dist/svelte/index.cjs`; остальные 88 файлов совпадают.
Собственный probe использует точные ESM/CJS bytes после hash checks и заранее заданные expected traces. Шесть историй выполнены для обоих snapshots и форматов; delivery traces совпали, identity difference проверена отдельно. Установки и повторный build не выполнялись.
Артефакты reviewer:

- `probe.mjs`: SHA256 `34142eb9ad849d2f94b9af6a53f0fbff070e88e21c5ea47cb6ee73807138dc25`.
- `probe-result.json`: SHA256 `8b481c5c28867b735caf2de88e576dff69108927945a8c519e86637445299888`.

## Verdict: PASS

PASS относится к lifetime/correctness данного Svelte delta при указанном контракте. Receipt исходного runtime проверяет public export resolution на staged raw bytes; мой probe — прямой import тех же bound bytes. Ни один не является packed/installed-consumer доказательством. Typecheck и tsup подтверждены сохранёнными успешными receipts, а не новым запуском reviewer.
Проверки **Да** — статический baseline/delta review, manifest/source/runtime bindings, чтение RED/GREEN receipts и новый сравнительный probe. **Нет** — ожидаемые baseline regression/retention checks, сохранённые как RED. **Не было** — повторного GC protocol/full suite/build/install, packed tarball, browser, size/scale proof, Windows, новых threads, product/plan mutation, push/merge/release/deploy или записи памяти.
Изоляция: отдельный remote evidence-каталог; новые вычисления только CPU1. Probe PID 2785433 завершён и отсутствует; CPU1 освобождён. Исходный packet не изменён. Size и последующий scale-proof остаются вне этой оси.
