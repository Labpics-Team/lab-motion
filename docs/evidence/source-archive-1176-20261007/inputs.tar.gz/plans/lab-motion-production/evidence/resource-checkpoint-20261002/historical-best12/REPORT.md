# MotionValue: nullable terminal ownership, fix12

Изменён только `src/motion-value.ts` приватного checkout. Constructor, ссылка SpringParams, getter timing, unsubscribe и host/generation guards сохранены. Destroy выключает цикл, затем освобождает spring и scheduler совместным null-присваиванием. Удалён только дублирующий spring guard на входе tick; два callsite используют non-null assertion.

Инвариант: единственная запись running=true находится в setTarget после проверки живого spring. Destroy записывает running=false до освобождения обеих ссылок. Между admission и scheduler/solver callsite нет пользовательского вызова для типизированного контракта. Getter-reentry внутри solver по-прежнему отсекает postsolver guard. Это cross-field invariant исходника, не гарантия, выраженная системой типов.

Контрпример к дальнейшему удалению posthost running guard: ранее выданный callback может завершить текущий run во время requestFrame без изменения generation. Только generation guard не предотвращает новый fallback после сходимости. Этот guard оставлен. Live SpringParams не копируются; их прежнее наблюдаемое поведение сохранено.

Один CPU0 pipeline: 127 targeted tests / 5 suites, TypeScript и canonical tsup — PASS. Size — FAIL. only-MotionValue 1653/1660 B gzip (-3 к best8); full-core 2354/2330 (-3, превышение24); compositor-stagger 6625/6600 (-3, превышение25); follow6474/7474 (-7). Shipped core остаётся RED; stdout округляет его до2.17KB. Полный вектор45 shipped entries и16 consumers сохранён в full-size-vector.json без выдуманной точности. Animate+compositor17149, facade15245, scope15550 — без изменения.

Граф изменения:13 публичных entries,26 runtime-файлов ESM/CJS. Root; девять framework bindings через createBoundValue; compositor, stagger и follow через CompositorSpring/handoff. Прямой MotionValue import в stagger используется лишь как return type. Animate, gestures, frame, presence, behaviors, flip и projection не получают runtime-класс от этого изменения. Shared frame не изменился. Фактические hashes всех26 изменённых outputs — consumer-graph.json.

Best8 archives сохранены. Main reviewed6 и shared Vite cache неизменны. Source/runtime archives проверены побайтово по каждому файлу. Fix12 остаётся в private checkout; повторных запусков, новых вариантов, declaration/package qualification, independent review, commit/push/merge/release/deploy, Windows execution и memory writes в этом срезе не было. Размерный gate и дальнейшая package/delivery квалификация открыты. Rollback — сохранённый best8 source/runtime; автоматический rollback не выполнялся.
