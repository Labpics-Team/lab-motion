# Lab Motion: сохранённый кандидат resource-checkpoint, 2 октября 2026

Пакет сохраняет исходный код и доказательства перед очисткой Linux sandbox. Он не закрывает исследование, план, выпуск или production-доставку. Предыдущие отчёты скопированы без правок; их статус и размеры относятся только к названным там snapshot. Для текущего кандидата приоритет имеет раздел ниже.

## Текущий кандидат

- Product commit: `8a97cfde06087de80b80da078d57065b5ff38164`; parent: `33f496a0b8350b1902b5c7651b2886ecf95102ed`.
- Draft PR: https://github.com/Labpics-Team/lab-motion/pull/458, ветка `codex/motion-generic-follow-20261001`.
- `checkpoint/candidate.patch`: SHA-256 `3e1cbfe3a56e17ba0fd5216b908d22d0ab71428d0aae5e5a47f22e3f3a95e08c`.
- `checkpoint/composition.json` связывает 10 файлов с SHA-256 и фиксирует чистое объединение test delta main `957ceaf26501525eff476cdc1d149d81fd5ebcd7` через git merge-file.
- `checkpoint/remote-durable-readback.json`: PR OPEN/draft, Git ref и все 10 GitHub blobs совпали с локальным commit. Этот readback удостоверяет сохранность исходника на момент чтения.

В кандидат вошли cleanup/retention-изменения, идентичность запуска MotionValue, исправление потери callback при reentrant fresh start, отзыв подписки Svelte и согласованная документация doc2. MotionValue: SHA-256 `f65ee267b86b8041835eae73f42b5d4b64c4199941c4496437b4ea93aabf9adb`; Svelte: `b756eb7acb3a51f991fc2ae499abac7c387557c39763c5e33489662cd2b5777e`.

## Проверки текущего snapshot

**Да:** 16 из 17 локальных стадий завершились успешно. Это pinned pnpm audit без advisory, actionlint, native gate, cycles, error catalog, TypeScript core/browser/motion-program и native TS7, canonical tsup с декларациями (111 файлов каждого формата d.ts/d.cts), docs facts/drift, issue forms, release contract и 188 тестов в 10 suites. Команды, время и привязка к patch записаны в `checkpoint/prepush/results.json`; журналы и receipts лежат рядом. Запуск — CPU0 и один test worker.

**Нет:** size gate завершился exit 1. Текущие consumer gzip bytes:

| Consumer | Размер | Ceiling | Результат |
| --- | ---: | ---: | --- |
| only-MotionValue | 1640 | 1660 | PASS |
| full-core | 2339 | 2330 | RED |
| compositor-stagger | 6610 | 6600 | RED |
| compositor-follow | 6459 | 7474 | PASS |
| animate + compositor | 17144 | 17500 | PASS |
| animate facade | 15245 | 15600 | PASS |
| animate scope | 15550 | 15700 | PASS |

Источник — `checkpoint/prepush/size.stdout.log`. Для shipped core журнал фиксирует PASS; точные bytes из округлённого вывода не выводились. Исторические 2340/6611 относятся к предыдущему object-run candidate. Ceiling не повышались.

**Не было локально в этом checkpoint:** полный test/fuzz/mutation/browser graph, pack/install/compat/Node-floor и полная runtime/resource calibration. Merge, release, production deploy/readback не выполнялись.

**Удалённый CI для того же SHA:** run [36961284260](https://github.com/Labpics-Team/lab-motion/actions/runs/36961284260) завершился failure. `checkpoint/ci-jobs.json` фиксирует success test/fuzz, driver mutation, Chromium, Firefox и WebKit 1/2; size/package и WebKit 2/2 завершились failure, consumer contract Node skipped. `checkpoint/ci-failures-excerpt.json` сохраняет size RED с теми же bytes и WebKit carousel re-pickup: `browser/compositor-follow.spec.ts:125`, getAnimations().length ожидался 1, получен 0. Автоматический retry #1 прошёл, итог — «1 flaky, 60 passed», job exit 1. Это наблюдение не устанавливает причину; retry не закрывает finding. Triage и итоговый lifecycle gate остаются открытыми. Проверка source/сборки и draft push не доказывает готовность к merge или release.

## Как читать RED, исправления и review

1. `review-run-identity-red/`: независимый one-shot probe обнаружил stall в best12 и object-run candidate при доставке callback преемника после возврата requestFrame, но до возврата старого tick. Queue/timers пусты; retry того же target не оживляет запуск. Исходный probe и review сохранены; summary сохраняет все операционные поля, заменяя только массивы ordinary samples количеством и digest. SHA исходного полного результата записан в summary и SOURCE-MAP.
2. `guard-reset/`: reset существующего `_tickActive` перенесён в fresh-start owner. Исправление сохранило same-run guard и stale-run rejection. 133/133 теста, TypeScript, tsup и ESM/CJS probe прошли. Первый прогон 132/133 сохранён: ошибка нового теста исправлена уточнением final-emit trigger через velocity===0; source фикса не менялся. `review-guard-reset/review.md` содержит независимый PASS для точного guard-reset source. Формулировка «review ещё требуется» внутри старого RESULT историческая.
3. `review-svelte-red/` и `svelte/`: первоначальный focused RED 3 fail/1 pass и ESM/CJS RED 12 fail/9 controls; кандидат прошёл 19 тестов и 21 runtime control. Общий revoker освобождает captures; старый off не отзывает регистрацию-преемника. `review-svelte-contract/` сохраняет первоначальное ревью и его ограничения. `svelte-doc2/` и `review-svelte-doc2/` фиксируют окончательную фразу «Повторная подписка с тем же run использует текущую активную регистрацию» и targeted PASS; executable не менялся.
4. `historical-object-run/`, `historical-best12/`, `review-run-cost/` и `historical-review-*` сохраняют предыдущие переходы и границы доказательства. Одна run identity на fresh start не является измерением heap/performance. Их размеры и PASS не переносятся автоматически на текущую композицию.

## Сохранность и продолжение

`SOURCE-MAP.json` перечисляет точные копии, исходные абсолютные пути и SHA-256, а также явно помечает производные summary и CI excerpt. `MANIFEST.sha256` относится к экспортированным файлам. Вложенные старые manifests оставлены как provenance и могут ссылаться на неэкспортированные archives. node_modules, dist, tar-архивы и большие sample traces намеренно исключены; полный код текущего кандидата сохранён в product commit и candidate.patch. При переносе probe/qualify scripts нужно заменить сохранённые sandbox paths на новый checkout, сохранив pinned версии и byte identities.

Следующие обязательные инженерные фронты — закрыть текущий size RED без повышения ceilings, исследовать исходный WebKit flaky failure, затем завершить применимые проверки и review конечной композиции для точного SHA. Подбор новых size-вариантов был остановлен ради durable checkpoint; гипотеза called/timestamp sentinel не реализована и не является решением. Сохранение этого пакета не разрешает merge/release и не меняет нормы плана.

Работа выполнялась в отдельном integration checkout; старые checkout, frozen packets и общий dependency cache сохранены. Откат опубликованного кандидата — отдельный revert через обычный PR после применимого допуска, без force-push; production-состояние этот checkpoint не менял.
