/**
 * @labpics/motion/svelte — Svelte bindings for the headless motion engine.
 *
 * Subpath export: import { springStore } from '@labpics/motion/svelte'
 *
 * Zero runtime dependencies — svelte is a peerDependency only.
 * CSS-safe: only finite values emitted via the store.
 * Compatible with Svelte 4 readable/writable store contract.
 *
 * Reduced-motion policy (northInvariant #5):
 *   When window.matchMedia('(prefers-reduced-motion: reduce)').matches:
 *   - 'instant' (default): new target value is emitted synchronously to subscribers
 *     without spring animation (CHARACTER = snap).
 *   - 'fade': same as instant from the store perspective; caller applies a
 *     short CSS transition on the consuming element for a fade effect.
 *   Both modes change CHARACTER, not hard-off: the value always reaches the
 *   target; only the interpolation style changes.
 */

import type { MotionValue, MotionValueOptions } from '../motion-value.js';
import { createBoundValue } from '../internal/binding-value.js';
import { type SpringParams } from '../spring.js';

// ─── Reduced-motion detection ─────────────────────────────────────────────

function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// ─── Svelte store interface ───────────────────────────────────────────────

/**
 * A Svelte-compatible store that animates toward its target value using spring physics.
 *
 * Implements the Svelte store contract: `{ subscribe, set }`.
 * Also exposes `destroy()` for cleanup in `onDestroy`.
 */
export interface SpringStore {
  /**
   * Подписка Svelte: каждый вызов сразу доставляет run текущее значение.
   * Повторная подписка с тем же run использует текущую активную регистрацию.
   * Любая её отписка отзывает регистрацию; повтор отписки не затрагивает преемника.
   */
  subscribe(run: (value: number) => void): () => void;

  /**
   * Set a new target value. The store animates toward it using spring physics.
   *
   * When `prefers-reduced-motion: reduce` is active, CHARACTER switches:
   * - 'instant': value snaps to `target` synchronously without spring.
   * - 'fade': value jumps to `target`; caller applies CSS opacity transition.
   *
   * @param target - New target value. Must be finite.
   * @param reducedMotionMode - Override per-call. Defaults to store-level setting.
   */
  set(target: number, reducedMotionMode?: 'instant' | 'fade'): void;

  /**
   * Stop all animations and clean up. Call in `onDestroy`.
   */
  destroy(): void;
}

// ─── springStore ──────────────────────────────────────────────────────────

/**
 * Creates a Svelte store that animates a numeric value toward its target
 * using spring physics with smooth velocity pickup on re-target.
 *
 * @param initial - Initial numeric value. Must be finite.
 * @param spring  - Spring physics parameters.
 * @param reducedMotionMode - 'instant' | 'fade'. Default: 'instant'.
 *   Controls CHARACTER of animation when prefers-reduced-motion is active.
 * @param requestFrame - Injectable rAF seam for deterministic testing.
 *
 * @example
 * ```svelte
 * <script>
 *   import { springStore } from '@labpics/motion/svelte';
 *   import { onDestroy } from 'svelte';
 *
 *   const x = springStore(0, { mass: 1, stiffness: 200, damping: 20 });
 *   onDestroy(() => x.destroy());
 * </script>
 *
 * <div style="transform: translateX({$x}px)">Hello</div>
 * <button on:click={() => x.set(100)}>Animate</button>
 * ```
 */
export function springStore(
  initial: number,
  spring: SpringParams = { mass: 1, stiffness: 200, damping: 20 },
  reducedMotionMode: 'instant' | 'fade' = 'instant',
  requestFrame?: MotionValueOptions['requestFrame'],
): SpringStore {
  const mv = createBoundValue({ initial, spring, requestFrame });

  // Callback владеет одной активной регистрацией и общей функцией её отзыва.
  const subscribers = new Map<(value: number) => void, () => void>();

  // Listen to MotionValue changes and broadcast to all Svelte subscribers.
  mv.onChange((v) => {
    for (const run of subscribers.keys()) {
      run(v);
    }
  });

  return {
    subscribe(run) {
      const existing = subscribers.get(run);
      if (existing) {
        run(mv.value);
        return existing;
      }
      let registry: typeof subscribers | null = subscribers;
      let callback: typeof run | null = run;
      const off = () => {
        if (callback === null) return;
        registry?.delete(callback);
        registry = null;
        callback = null;
      };
      subscribers.set(run, off);
      // Немедленная доставка и её прежняя ошибка остаются частью subscribe.
      run(mv.value);
      return off;
    },

    set(target, modeOverride) {
      const mode = modeOverride ?? reducedMotionMode;
      if (prefersReducedMotion()) {
        // Подписка уже транслирует эмиссию в store; snapTo останавливает
        // старый цикл и не даёт queued-кадру перезатереть reduced-снап.
        mv.snapTo(target);
      } else {
        mv.setTarget(target);
      }
      void mode; // mode is read above; void prevents lint unused warning
    },

    destroy() {
      mv.destroy();
      subscribers.forEach((off) => off());
    },
  };
}
