# MotionValue: исправление потери callback преемника

В fresh-start owner перенесён существующий сброс `_tickActive`. Новый запуск
не наследует guard прежнего tick, ещё исполняющего getter/listener. Отдельный reset
перед terminal emit удалён: этот переход тоже входит через setTarget fresh start.
Одно изменение поведения: допустимый one-shot callback нового запуска после
возврата requestFrame больше не теряется. Scheduler, solver, falsey error policy,
подписки и stale-run identity не менялись. Sentinel/прочие ужимы не включены.

Проверки **Да**: 133/133 теста (127 прежних без правок + 6 новых), TypeScript,
canonical tsup, raw ESM/CJS runtime probe с one-shot hosts независимого reviewer.
Getter/listener after-return теперь оставляют следующий кадр и достигают 2 без
повторного stop→setTarget. Сохранённые 50 ordinary value/velocity samples совпали
побайтово в каждом формате; inside-requestFrame control и stale fallback rejection
также совпали с прежним object candidate. Общий scratch проверен отдельным control
snapshot в новых тестах. Независимое повторное review ещё требуется.

Исходное RED **Нет** — liveness нарушалось в best12 и object candidate; точные
review/probe/result/core bytes сверены и переиспользованы без повторного запуска.
Первый qualification дал 132/133: неверный новый тест считал clamped target финалом.
Исправлен только тестовый trigger через velocity===0; исходник фикса не менялся.
Attempt1, исходные test bytes и triage сохранены; окончательный gate 133/133.

Проверки **Не было**: новый size gate, packed/installed consumer, resource calibration,
production/deploy/readback. Прежние 2340/2330 и 6611/6600 относятся к предыдущему
object candidate и не являются размерным доказательством этих новых runtime bytes.

Артефакты: narrow guard-reset.patch; guard-reset-and-tests.patch к object candidate;
delta-from-best12.patch; полные source/runtime archives и пофайловые hashes.
Commands, timestamps, source identity и outputs находятся в stage receipts/logs.
Все исходные packets, main, best12, object-run, Svelte/doc sidecars и общий cache
сверены и сохранены. Рабочий кандидат существует только в отдельном sibling.
Нет commit/push/merge/release. Откат — отказаться от этого sibling; источники сохранены.
