# Svelte unsubscribe: публичный контракт и стоимость решения

**Вердикт: REQUEST_CHANGES по одному локальному documentation finding (P2).** Архитектурная граница и локальный Map соразмерны задаче; новых dependencies, методов API или домена компонентов в patch нет. Исправление finding требует только точной формулировки подписки. Это source-only review последствий контракта, а не голосование за runtime correctness, GC доказательство или разрешение release.

## Неизменяемый объект

- Artifact: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-svelte-unsubscribe-20261002.swaabiwj/evidence`.
- `manifest.json`: `7cc09f452e078fbb5f6c5bee2b16a48177b029ee8a85da70a3d8ecbd80f66655`.
- `svelte.patch`: `99d00597192d182a0508c46caf5109a61620433fe1d4c675db0b23a8cd6ce64b`.
- `source.tar.gz`: `e9009a76e32436c0e077c7eaacf06fa06255965cfc501fb15a8950051c518e16`.
- Candidate `src/svelte/index.ts`: `c943ffb39fecf4bfed21ad8145181ed8d9e0433a66874b7e1c79ec7e7d45e552`; bytes в archive и отдельной candidate-копии совпадают.

Намерение пользователя: надёжные Motion primitives для Lab UI при сохранении headless generic library; sheet/carousel domain остаётся потребителю. Локальный контракт из review-contract: закрыть stale unsubscribe и callback retention у springStore, сохранив immediate delivery, duplicate-callback dedup, fail-fast broadcast и форму API.

## F-01 — P2: новая JSDoc обещает frame cadence

**Место:** `src/svelte/index.ts:42`: «Повторный run разделяет активную подписку и получает один вызов на кадр».

В этом unsubscribe-срезе registry устраняет duplicate registration, но не ограничивает число synchronous emissions между кадрами. При active reduced-motion preference и initial=0 допустима история в одном JS turn: подписать callback; вызвать `store.set(1)`; вызвать `store.set(2)`. По `src/svelte/index.ts:130–135` оба вызова идут в snapTo. По `src/motion-value.ts:363–375` каждый новый target синхронно вызывает _emit; `:506–520` доставляет значение listener, а Svelte wrapper `:103–105` — callback. Между этими двумя доставками rAF не нужен. Это вывод по source control flow, не новый test run.

Поэтому «один вызов на кадр» вводит не подтверждённое обещание cadence и может заставить потребителя ошибочно считать subscription frame-coalesced. Существующая reduced-motion semantics в этом patch не меняется; ошибочен новый публичный текст.

**Минимальное исправление:** «Повторная подписка с тем же run использует текущую активную регистрацию». Это объясняет dedup без нового обещания cadence или function identity. Не заменять фразу безусловным «один вызов на каждую эмиссию»: отдельная гарантия для reentrant mutation текущей коллекции этим review не доказана.

**Условие закрытия:** narrow diff меняет только эту формулировку, не scheduler/dispatch semantics; targeted reread обновлённого exact artifact. Для такой правки документации новые runtime tests не нужны.

## Identity handles: изменение наблюдаемо, но не необходимая часть retention fix

Baseline `subscribe` создаёт новый function object при каждом вызове. Candidate `:111–114` возвращает сохранённый revoker для duplicate callback. Следовательно для двух активных duplicate subscriptions baseline `off1!==off2`, candidate `off1===off2`. Это реальное наблюдаемое различие. Например, внешний `Map<unsubscribe, metadata>` различал бы две записи и теперь объединял бы их.

В прочитанных `SpringStore` types, JSDoc, README, docs/api.md, existing Svelte tests и focused/runtime-probe source нет обещания distinct handles или найденного consumer, использующего их как уникальные subscription IDs. Это ограниченная проверка данного snapshot, не доказательство отсутствия внешних consumers. Review-contract сам явно раскрывает identity delta. Поэтому здесь нет подтверждённого нарушения объявленной identity-гарантии и это **не отдельный blocker**.

Shared function identity не требуется для логики освобождения owner: можно сохранить один общий revoker в Map, а наружу возвращать свежие wrappers вокруг него. Отмена по-прежнему обнуляет общий callback/registry state; старые wrappers не получают successor. Такой вариант сохраняет baseline public identity, создавая свежий wrapper на каждый subscribe плюс общий внутренний revoker на registration. Baseline тоже создавал per-call handle, но равенство суммарной allocation cost этим не утверждается; это source-level альтернатива, её GC/runtime evidence здесь не выполнялось. Candidate избегает этих duplicate wrapper allocations и повторяет уже используемый локальный pattern MotionValue. Выбор не требует нового subscription API или общей abstraction.

Не стоит превращать incidental stable revoker identity в новую публичную гарантию: отсутствие такой гарантии сохраняет свободу позже поменять registry representation. Текущие focused tests и runtime-probe проверяют lifecycle, а не `off1===off2`; лишнего identity oracle в них не найдено.

## Владелец и более простые альтернативы

Svelte adapter владеет dedup и lifetime одной callback registration, immediate delivery на каждый subscribe и своей fail-fast broadcast semantics. MotionValue продолжает владеть физикой, frame scheduling и жизнью значения. Lab UI продолжает владеть состоянием компонентов; patch не добавляет sheet/carousel states или их policy.

Простой Set плюс независимый boolean в каждой off-функции недостаточен: duplicate off, ещё не вызванная после отмены соседней off, сохраняет право удалить successor того же callback. Нужно общее состояние generation/registration, находящееся по callback. Локальный Map делает это непосредственно; WeakMap плюс отдельная iterable collection либо линейный поиск registry entries создают лишние согласуемые представления или lookup cost.

Прямая замена adapter registry на `mv.onChange(run)` короче, но нарушает заданную совместимость: MotionValue `:249–255` откатывает новую регистрацию при ошибке immediate callback, а adapter сохраняет прежнее поведение без rollback. MotionValue `:509–520` ловит ошибку отдельного listener и продолжает остальных; единый Svelte wrapper прекращает свой обход на первой ошибке. Поэтому этот путь не является эквивалентным упрощением текущего среза.

Map здесь не новый глобальный owner или постоянный эксплуатационный путь. Он заменяет Set внутри существующего adapter. Destroy проходит по revokers, чтобы очистить также state, достижимый через внешние handles; одно удаление registry entries не отзывает такие захваты. Нужды выносить generic subscription module из этого patch не установлено.

## API и dependency footprint

Diff содержит только `src/svelte/index.ts` и новый focused test. Сигнатуры SpringStore.subscribe/set/destroy и springStore не меняются; imports остаются прежними. Package exports сохраняют `@labpics/motion/svelte` для ESM/CJS. Source package.json не содержит runtime dependencies; Svelte остаётся optional peer `>=4.0.0`. Новый Map не добавляет package import, scheduler или product-specific API.

Это source-footprint вывод. Размер emitted bundle, runtime performance и установленный package здесь не измерялись. Из авторского review-contract не переносится готовность core size gate или release.

## Проверка и предел

**Да:** exact manifest/patch/source hashes; archive member binding; source walkthrough lifecycle owner и observable identity; comparison альтернатив; traceback публичного cadence finding; собственный manifest/readback.
**Нет:** новая документационная cadence-гарантия не соответствует поддерживаемому synchronous emission path (F-01).
**Не было:** исполнения продукта/архивного кода, tests/build/install, GC или numerical runs, Windows, чтения других reviewer reports, source edits, новых агентов, memory writes, push/release.
Изоляция: записан только отдельный report packet; исходный frozen artifact сохранён.
