# Architecture Review

Дата: 2026-10-02. Ось: MotionValue active-run correctness/resource ownership.
Объект: `../../tmp/motion/resource-motion-value-run-identity-20261002.hua2jvc3/evidence`.
MANIFEST SHA256: `60cfe60a95e58a70b30681affa3ba43fbbc70a6fc80807f6dbbf820a521e1603`.
Candidate source: `0256d46a682a46774c2a04e930097d1d576fb9947ca941930ecbbd69bef4c8e6`; best12 baseline: `55a57c907b0d505d1d0053c0fe572949ac6122c91e2e0777c89bc8bb7db69632`.
Narrow patch: `a6e982c38c5d18a6ba7e92023b99ee5f77b86ac4d59e38cf898fc5b43458f7c8`.
Source archive: `6cd7676acd39c0c8f92a52faafb67d0a9d39042156f8469b237cb2ddd5d937e8`; runtime archive: `a23dd9e144264d500df6e56338ddf397303b78b27a48b1081377a9f77a1c262b`.

## Violations

- `src/motion-value.ts:411` [recommended] [scheduler liveness / timing contract] — подтверждён унаследованный stall при следующей one-shot истории: старый tick исполняет spring getter либо listener; тот вызывает stop→setTarget(2), а host доставляет новый callback после возврата нового requestFrame, но до выхода старого tick. Общий `_tickActive` поглощает callback преемника; старый tick уже отозван и не перепланирует работу. Очередь и timers пусты, `_run` остаётся active, повтор setTarget(2) — no-op. Точно тот же исход есть в best12; патч его не создаёт. Runtime-факт подтверждён; нарушение обещанного API зависит от допустимости такого timing: публичный RequestFrameFn запрещения не содержит, но rAF-подобный deferred host эту историю не порождает. Зафиксировать timing contract и обработку допустимого случая через владельца → defer fix/contract decision to владельцу MotionValue (TypeScript builder). Это открытая локальная оговорка, не новый global gate.

## Compliant patterns

- `src/motion-value.ts:262–313,319–362` — только запуск из покоя создаёт свежий объект; live retarget и повтор активной цели сохраняют run. Stop, snap, destroy и естественное завершение отзывают его. Сохранены SpringParams reference/getter semantics и числовой snapshot; destroy по-прежнему освобождает spring, scheduler и listener ownership.
- `src/motion-value.ts:372–405,408–431` — captured run сверяется до host IO, после возврата requestFrame, при входе в tick и после solver getters. Старый callback не получает право на successor после отзыва. Schedule failure отзывает только свой ещё текущий run; чужой reentrant successor не останавливается.
- `src/motion-value.ts:466–489,493–508` — final snapshot публикуется после отзыва run; прежний reset guard перед final emit сохранён. Listener first-error policy, включая falsey exceptions, и precedence над вторичной ошибкой перепланирования побайтово не изменены. Listener revocation относится к исходной регистрации.
- `unit.json`, `unit.stdout.log:4–13` — сохранённые 127 characterization tests прошли на candidate; TS и tsup имеют успешные receipts с тем же source digest. Все test bytes совпали с best12; reviewer не запускал полный pipeline повторно.

## Независимые истории и наблюдаемое изменение

В собственном probe каждый host callback имеет one-shot guard; искусственная очередь timers позволяет различить fallback и host lanes без sleeps и полного test suite. Выполнены exact ESM/CJS snapshots baseline и candidate.

1. Старый host выдал handle=0 и сохранил callback. Fallback довёл первый run до natural settle; стартовал successor с обычным queued host. Поздняя первая доставка старого callback у best12 добавила emission и новый request, изменив successor snapshot. Candidate сохранил snapshot, число emissions и requests. Это полезное наблюдаемое изменение, а не полная behavioral equivalence: естественное завершение раньше не меняло generation.
2. Getter handoff из finding: после возврата старого tick value=0, target=2, очередь=0, timers=0, requests=2; same-target retry не планирует кадр. Baseline и candidate совпали. Явный stop→setTarget восстанавливает прогресс до 2.
3. Положительный сосед: новый callback вызван внутри самого requestFrame. Он проходит через существующий trampoline, оставляет timer и достигает 2 в обоих snapshots. Поэтому finding не относится ко всем синхронным hosts.
4. Listener handoff после возврата requestFrame даёт тот же inherited stall в обоих snapshots.
5. Обычный timestamped live retarget, stop/resume и destroy: все 50 value/velocity samples побайтово совпали между snapshots для каждого формата.

`_run` — пустой private identity token; он не хранит owner-ссылок. Captured stale callbacks сохраняют ссылку на MotionValue, как и baseline, но destroy освобождает его внешние spring/scheduler/listener owners. Число retained bytes и allocation cost этим review не устанавливаются.

## Evidence и область

Проверены 31 manifest entry, пофайловые карты всех 617 source и 90 runtime файлов. Source archives baseline/candidate отличаются только `src/motion-value.ts`; прочие исходники и тесты сохранены. Проба импортировала точные standalone core runtime bytes из архивов; это raw-runtime proof, не packed/installed-consumer qualification.
Авторские transition-table.md, RESULT.md, reasoning и чужие verdicts не использовались; manifest integrity проверена без чтения их содержания для review.

Артефакты reviewer, все 0444:

- `probe.mjs`: SHA256 `09d08dd8b596c557c82387c163668d9058c4ca9e5ca7bdec80b216d70d8222ce`.
- `probe-result.json`: SHA256 `5719cd0d8fa41c5fb50313c92a54e2d5a296504c5fc9b1f1e488a2038b2a8f96`.
- `baseline.mjs/.cjs` и `candidate.mjs/.cjs`: exact core bytes; четыре digest сохранены в probe и result.

## Verdict: PASS_WITH_NOTES

Для замены running/generation на active-run identity подтверждённых регрессий не найдено; stale-host-after-natural-settle улучшен. Полная liveness произвольных after-return reentrant hosts не закрыта: finding выше унаследован и требует решения timing-контракта владельцем.
Проверки **Да** — source/diff/contract review, immutable bindings, сохранённые 127-test/TS/build receipts, один независимый CPU0 probe. **Нет** — liveness в двух описанных reentrant-after-return историях у обоих snapshots; stale one-shot fallback callback у baseline. **Не было** — новых installs, полного pipeline, GC/retained-byte calibration, cost/size review, Windows, новых threads, author/product/plan mutations, публикаций или записи памяти.
Probe PID 2836589 завершён и отсутствует; CPU0 освобождён. Исходный packet неизменён. Этот verdict не является ship/merge/readiness claim.
