# Targeted F-01: PASS

Новый exact candidate b756eb7acb3a51f991fc2ae499abac7c387557c39763c5e33489662cd2b5777e содержит только замену одной JSDoc-строки относительно исходного candidate. Executable bytes неизменны.

«Повторная подписка с тем же run использует текущую активную регистрацию» точно описывает dedup и не вводит cadence/cardinality/handle-identity гарантии. F-01 закрыт.

Проверка source-only; runtime tests не выполнялись и для этой документационной правки не требуются. PASS ограничен F-01, остальные review и delivery gates не переоцениваются. Предыдущие verdicts и snapshots сохранены.
