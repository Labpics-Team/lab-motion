from pathlib import Path
import os,subprocess,json,time,datetime,hashlib,sys
r=Path('/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-svelte-unsubscribe-20261002.swaabiwj');b=Path('/home/labpics-ops/work/colors-motion-20261001');c=r/'checkout';e=r/'evidence'
node=str(b/'tools/motion/node-v24.21.0-linux-x64/bin/node')
env=os.environ.copy();env.update({'TMPDIR':str(r/'temp'),'npm_config_cache':str(r/'npm-cache'),'NODE_COMPILE_CACHE':str(r/'node-compile-cache'),'COREPACK_HOME':str(b/'tools/motion/corepack'),'PATH':str(b/'tools/motion/node-v24.21.0-linux-x64/bin')+':'+str(b/'tools/motion/bin')+':'+env['PATH'],'npm_config_offline':'true','npm_config_legacy_peer_deps':'true'})
focused=[node,'node_modules/vitest/vitest.mjs','run','test/svelte-unsubscribe-lifecycle.test.ts','--config',str(r/'vitest.config.mjs'),'--pool=forks','--maxWorkers=1','--fileParallelism=false']
stages={'red-focused':(focused,c,60),'red-runtime':([node,'--expose-gc',str(r/'baseline-consumer/resource-svelte-probe.mjs'),str(e/'raw-artifact-binding.json')],r/'baseline-consumer',20)}
stages.update({
 'green-targeted':([node,'node_modules/vitest/vitest.mjs','run','test/svelte-unsubscribe-lifecycle.test.ts','test/svelte.test.ts','test/svelte-current-value.test.ts','--config',str(r/'vitest.config.mjs'),'--pool=forks','--maxWorkers=1','--fileParallelism=false'],c,60),
 'green-typecheck':([node,'node_modules/typescript/bin/tsc','--noEmit'],c,90),
 'green-build':([node,'node_modules/tsup/dist/cli-default.js'],c,180),
 'green-runtime':([node,'--expose-gc',str(r/'candidate-consumer/resource-svelte-probe.mjs'),str(e/'candidate-runtime-binding.json')],r/'candidate-consumer',20)
})
name=sys.argv[1];args,cwd,timeout=stages[name];assert not (e/(name+'.json')).exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={'sourceSha256':sha(c/'src/svelte/index.ts'),'focusedTestSha256':sha(c/'test/svelte-unsubscribe-lifecycle.test.ts'),'runtimeProbeSha256':sha(r/'baseline-consumer/resource-svelte-probe.mjs'),'rawBindingSha256':sha(e/'raw-artifact-binding.json')}
inputs['executedRuntimeBindingSha256']=sha(e/('candidate-runtime-binding.json' if name=='green-runtime' else 'raw-artifact-binding.json'))
cmd=['taskset','-c','0']+args;started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with (e/(name+'.stdout.log')).open('w') as out,(e/(name+'.stderr.log')).open('w') as err:
 proc=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=out,stderr=err);(e/(name+'-dispatch.json')).write_text(json.dumps({'pid':proc.pid,'command':cmd,'cwd':str(cwd),'startedAt':started,**inputs},indent=2)+'\n')
 try:code=proc.wait(timeout=timeout);timed_out=False
 except subprocess.TimeoutExpired:proc.kill();code=proc.wait();timed_out=True
receipt={'pid':proc.pid,'command':cmd,'cwd':str(cwd),'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtimeSeconds':time.monotonic()-clock,'exitCode':code,'timedOut':timed_out,**inputs};(e/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
