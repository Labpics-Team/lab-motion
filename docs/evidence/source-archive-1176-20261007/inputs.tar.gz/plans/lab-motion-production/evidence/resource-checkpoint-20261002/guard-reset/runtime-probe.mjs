import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
const base=dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const pins=JSON.parse(readFileSync(join(base,'runtime-inputs.json'),'utf8')).runtimePins;
for(const [p,h] of Object.entries(pins))assert.equal(sha(join(base,p)),h);
const started=new Date().toISOString();
const savedTimeout=globalThis.setTimeout;
let timers=[],timerId=0;
globalThis.setTimeout=(cb)=>{assert.equal(typeof cb,'function');timers.push(cb);return ++timerId;};
const spring={mass:1,stiffness:200,damping:20};
function flushTimers(limit=3000){
 let n=0;while(timers.length){assert.ok(++n<=limit);timers.shift()();}
 return n;
}
function clock(strategy=()=>1){
 let requests=0;const queue=[],delivered=new Set();
 const requestFrame=cb=>{
  const id=++requests;
  const once=ts=>{assert.ok(!delivered.has(id),'one-shot callback reused');delivered.add(id);cb(ts);};
  const mode=strategy(id,once);
  if(mode!=='sync')queue.push(once);
  return mode==='sync'?1:mode;
 };
 return {requestFrame,queue,get requests(){return requests;},get delivered(){return delivered.size;},
  next(ts){assert.ok(queue.length);queue.shift()(ts);},
  drain(limit=3000){let n=0;while(queue.length){assert.ok(++n<=limit);this.next();}return n;}};
}
function lateFallback(MV){
 timers=[];const c=clock(id=>id===1?0:1);
 const mv=new MV({initial:0,spring,requestFrame:c.requestFrame}),trace=[];
 mv.onChange(v=>trace.push(v));mv.setTarget(1);
 const fallbackTicks=flushTimers();assert.equal(mv.value,1);
 assert.equal(c.queue.length,1);
 mv.setTarget(2);assert.equal(c.queue.length,2);
 const before={value:mv.value,velocity:mv.velocity,emissions:trace.length,requests:c.requests};
 c.next();
 const after={value:mv.value,velocity:mv.velocity,emissions:trace.length,requests:c.requests};
 const answer={fallbackTicks,before,after,queuedAfter:c.queue.length,oneShotDeliveries:c.delivered};
 mv.destroy();c.drain();flushTimers();
 return answer;
}
function getterHandoff(MV,delivery){
 timers=[];let armed=false,mv;const c=clock((id,cb)=>{
  if(id===2&&delivery==='inside-request'){cb();return 'sync';}
  return 1;
 });
 const params={get mass(){
  if(armed){armed=false;mv.stop();mv.setTarget(2);if(delivery==='inside-getter-after-request')c.next();}
  return 1;
 },stiffness:200,damping:20};
 const trace=[];mv=new MV({initial:0,spring:params,requestFrame:c.requestFrame});
 mv.onChange(v=>trace.push(v));mv.setTarget(1);armed=true;c.next();
 const atReturn={value:mv.value,velocity:mv.velocity,queued:c.queue.length,timers:timers.length,requests:c.requests,emissions:trace.length};
 mv.setTarget(2);
 const retrySameTarget={queued:c.queue.length,timers:timers.length,requests:c.requests};
 flushTimers();c.drain();const valueWithoutIntervention=mv.value;
 assert.equal(valueWithoutIntervention,2);
 assert.equal(c.queue.length,0);
 const answer={delivery,atReturn,retrySameTarget,valueWithoutIntervention,valueAfterDrain:mv.value};
 mv.destroy();c.drain();flushTimers();return answer;
}
function listenerHandoff(MV){
 timers=[];const c=clock();let armed=false;
 const mv=new MV({initial:0,spring,requestFrame:c.requestFrame}),trace=[];
 mv.onChange(v=>{trace.push(v);if(armed){armed=false;mv.stop();mv.setTarget(2);c.next();}});
 mv.setTarget(1);armed=true;c.next();
 const atReturn={value:mv.value,velocity:mv.velocity,queued:c.queue.length,timers:timers.length,requests:c.requests,emissions:trace.length};
 mv.setTarget(2);assert.equal(c.queue.length,1);assert.equal(timers.length,0);
 const requestsAfterSameTarget=c.requests;
 c.drain();assert.equal(mv.value,2);
 const answer={atReturn,requestsAfterSameTarget,valueAfterDrain:mv.value};
 mv.destroy();flushTimers();return answer;
}
function regularRetarget(MV){
 timers=[];const c=clock(),mv=new MV({initial:0,spring,requestFrame:c.requestFrame});
 const trace=[];mv.onChange(v=>trace.push([v,mv.velocity]));
 mv.setTarget(10);for(let i=0;i<5;i++)c.next(i*16);
 const before=trace.at(-1);mv.setTarget(20);assert.deepEqual(trace.at(-1),before);
 assert.equal(c.queue.length,1);for(let i=5;i<10;i++)c.next(i*16);
 mv.stop();const snapshot=[mv.value,mv.velocity];c.drain();assert.deepEqual([mv.value,mv.velocity],snapshot);
 mv.setTarget(-1);c.drain();assert.equal(mv.value,-1);
 mv.destroy();assert.deepEqual([mv.value,mv.velocity],[-1,0]);return trace;
}
const results=[];
try{
 for(const version of ['fixed'])for(const format of ['mjs','cjs']){
  const path=join(base,version+'.'+format);
  const {MotionValue}=format==='mjs'?await import(path):require(path);
  results.push({version,format,lateFallback:lateFallback(MotionValue),
   getterAfterRequest:getterHandoff(MotionValue,'inside-getter-after-request'),
   getterSynchronousRequest:getterHandoff(MotionValue,'inside-request'),
   listenerAfterRequest:listenerHandoff(MotionValue),
   regularRetarget:regularRetarget(MotionValue)});
 }
 const previous=JSON.parse(readFileSync('/home/labpics-ops/work/colors-motion-20261001/evidence/motion-run-identity-correctness-review-20261002/probe-result.json','utf8'));
 for(const format of ['mjs','cjs']){
  const a=previous.results.find(r=>r.version==='candidate'&&r.format===format);
  const b=results.find(r=>r.version==='fixed'&&r.format===format);
  assert.deepEqual(a.regularRetarget,b.regularRetarget);
  assert.deepEqual(a.lateFallback,b.lateFallback);
  const {valueAfterExplicitRecovery,...beforeSync}=a.getterSynchronousRequest;
  const {valueAfterDrain,...afterSync}=b.getterSynchronousRequest;
  assert.deepEqual(beforeSync,afterSync);assert.equal(valueAfterDrain,valueAfterExplicitRecovery);
  assert.equal(b.getterAfterRequest.atReturn.queued,1);
  assert.equal(b.getterAfterRequest.atReturn.timers,0);
  assert.equal(b.getterAfterRequest.valueWithoutIntervention,2);
  assert.equal(b.listenerAfterRequest.atReturn.queued,1);
  assert.equal(b.listenerAfterRequest.valueAfterDrain,2);
 }

}finally{globalThis.setTimeout=savedTimeout;timers=[];}
const out={started,finished:new Date().toISOString(),pid:process.pid,node:process.version,
 cpuAllowed:readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.*)$/m)[1],
 scriptSha256:sha(fileURLToPath(import.meta.url)),runtimePins:pins,
 observation:'Fixed fresh-start owner preserves getter/listener after-return successor liveness without explicit recovery; saved regular traces, sync-request control and late-fallback rejection match object candidate.',
 results};
writeFileSync(join(base,'runtime-probe-result.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({...out,results:results.map(({regularRetarget,...r})=>({...r,regularRetargetSamples:regularRetarget.length}))}));
