# Объект независимого review

Намерение: закрыть RESOURCE/M-07 для springStore — отменённая отписка не отзывает преемника с тем же callback; off/destroy освобождают callback owner при сохранённых внешних off handles. Scope: только src/svelte/index.ts и test/svelte-unsubscribe-lifecycle.test.ts поверх frozen fix12. Никакой общей subscription-абстракции, изменения физики, scheduler, broadcast errorpolicy или API shape.

Исходный контракт: src/svelte/index.ts:40–45 — immediate текущего значения и unsubscribe;60–62 — destroy cleanup. Existing tests/svelte.test.ts:87,101,154; test/svelte-current-value.test.ts:8. Исходный Set хранит один callback, каждый subscribe вызывает его немедленно, любая duplicate-off удаляет общую регистрацию. Broadcast fail-fast; ошибка подписчика прерывает обход и проходит через существующий MotionValue listener handler. Это поведение сохранено и явно проверено.

Наблюдаемое изменение identity: duplicate subscribe теперь возвращает тот же revoker активной регистрации; baseline создавал разные function objects. Отдельной гарантии разных identities в найденных публичных docs/tests нет. Тип SpringStore и набор методов не меняются. Ошибка немедленного callback сохраняет прежнюю регистрацию: rollback/новая errorpolicy не вводились.

Точные объекты: candidate-svelte.ts, focused-test.ts, svelte.patch, source.tar.gz, runtime-dist.tar.gz; hashes в manifest.json и completion-readback.json. Полный snapshot включает неизменённый resource baseline fix12, narrow patch содержит только два Svelte-файла.

Evidence: до fix focused3 FAIL/1 PASS, exact ESM/CJS runtime12 FAIL/9 control PASS; после fix19 targeted tests PASS, TS PASS, canonical tsup PASS, тот же runtime-probe21 PASS. Public package export resolution и90 runtime file hashes проверены до import; между baseline/candidate изменились только2 Svelte outputs. GC protocol:60 turns setImmediate+gc с live, uncaptured и deliberate controls; это callback reachability evidence, не numeric retained-byte calibration.

Не выполнено: packed/installed tarball, browser, полный test suite, size gate, независимый review, push/merge/release/deploy. Core full-core/stagger size RED исходного12 остаётся отдельным открытым гейтом; этот срез его не закрывает. Публикации и изменения чужих checkouts не было.
