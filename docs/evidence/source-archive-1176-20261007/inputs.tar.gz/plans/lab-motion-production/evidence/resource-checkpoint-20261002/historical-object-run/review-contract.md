# Контракт независимого ревью

Исходная задача: оценить объединение `_running` и `_generation` в один private
active-run identity; stop/snap/destroy отзывают его, setTarget из покоя создаёт новый,
live retarget сохраняет, schedule/tick сравнивают identity. Сохранить SpringParams
getter/reference semantics, callback-boundary guards, fallback/trampoline, falsey
first-error policy, listener revocation. Одна изолированная попытка от best12,
127 characterization tests + TS + canonical build + full sizes, CPU0; без смены
бюджетов, solver/API redesign, публикаций и resource calibration.

Базовый исходник: baseline-motion-value.ts, digest в inputs.json.
Точный кандидат: candidate-motion-value.ts; unified diff: run-identity.patch.
Полные исходники и runtime: source.tar.gz и runtime-dist.tar.gz; содержимое пофайлово
в artifact-files.json. Исходные 127 тестов не менялись и включены в source archive.
Команды и выходы: unit/typecheck/build/size .json и stdout/stderr.log.
Полный размерный вектор: full-size-vector.json. Identity и сохранность общих
ресурсов: completion-readback.json. Manifest фиксирует неизменяемый пакет.

Каждый reviewer проверяет одну ось по заданию root. Не считать локальный PASS
подтверждением независимого review, полноты произвольных host histories, числа
удерживаемых байтов или готовности к поставке. Подтверждённый finding требует
точного пути/строки и контрпримера либо нарушенного свойства.
