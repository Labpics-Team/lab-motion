# Контракт targeted повторного ревью

Проверить исправление MotionValue liveness: spring getter или listener вызывает
stop→setTarget(2), затем доставляет новый one-shot callback после возврата
requestFrame до возврата прежнего tick. Новый запуск должен сохранить прогресс;
публичный RequestFrameFn такой timing не запрещает. Сохранить same-run reentrancy
guard, обычные deferred/sync/trampoline paths, SpringParams getter/reference
semantics, shared solver scratch, falsey first-error policy и stale-run rejection.

База — frozen object-run candidate source 0256d46a682a46774c2a04e930097d1d576fb9947ca941930ecbbd69bef4c8e6.
Точный source и тесты, narrow delta и hashes — candidate-motion-value.ts,
candidate-regression.test.ts, guard-reset-and-tests.patch, inputs.json.
Полные snapshots — source.tar.gz, runtime-dist.tar.gz, artifact-files.json.
RED source: независимый packet /home/labpics-ops/work/colors-motion-20261001/evidence/motion-run-identity-correctness-review-20261002;
точные identity привязаны в triage-receipt.json, повтор RED не выполнялся.
GREEN outputs — unit/typecheck/build/runtime-probe receipts/logs и runtime-probe-result.json.
Изоляция/сохранность — completion-readback.json; immutable hashes — manifest.json.

Один запрос — одна ось. Не считать author triage/RESULT рассуждениями reviewer:
проверять исходный контракт, immutable source/diff и фактические tests/probe evidence.
Это raw-runtime qualification, без installed package, size или delivery claims.
