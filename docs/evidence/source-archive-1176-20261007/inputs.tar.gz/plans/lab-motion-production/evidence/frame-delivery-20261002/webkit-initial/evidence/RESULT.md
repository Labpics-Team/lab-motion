# WebKit carousel: уточнение фазы native oracle

Исходный CI failure сохранён: run 36961284260, commit 8a97cfde, WebKit 2/2; 1 flaky / 60 passed, retry #1 прошёл, job exit 1. В исходном trace после currentTime=30 pickup записал translateX(-445.036036px), следующий drag40 упёрся в -480, release выбрал страницу3/target-480. `_retargetFrom` при нулевом range и ненулевой velocity использует live fallback; безусловный native-count oracle исключал допустимое поведение.

Кандидат меняет только spec: currentTime=0 фиксирует pickup в -145 независимо от первого input impulse; перед вторым release проверяется -185, после — страница2/target-240. Native-count1 остаётся строгим. Проверки pickup continuity, кнопок и cleanup сохранены. Product source, документация, clocks, policies и budgets не меняются. In-flight sampling остаётся в соседнем panel scenario; исправленный carousel сценарий проверяет pickup в начале native run.

**Да:** точный CI artifact digest и вложенные spec/harness bytes сверены. Chromium consumer probe на exact CI bundle показал native nonzero range (-145→-185→target-240, animations1/frames0) и live zero range (-240→-480→target-480, animations0, frames3, движение до -502.368). Последнее значение — наблюдение этого запуска, не численный oracle. 28/28 существующих follow tests прошли, в том числе canonical zero-range fallback и возврат к compositor. Browser TypeScript прошёл на финальных bytes browser spec. Diff check прошёл.

**Не было:** локальный полный canonical browser spec, успешный локальный WebKit (missing host libraries), новый exact-head remote CI, merge/release. Локальный Chromium не закрывает WebKit gate. Соседний size RED 2339/2330 и 6610/6600 не затронут.

Диагностические неудачи сохранены: первый Chromium trace adapter передавал функцию строкой без вызова, поэтому mount/hook не исполнялись; corrected script вызывает обе функции явно. Это не evidence дефекта продукта. Пробный дополнительный unit дублировал уже существующий zero-range test и ошибочно ожидал перемещение на первом callback, задающем epoch; пробный diff и failed log сохранены, дубликат удалён. Итоговый unit файл побайтово равен base. Production поведение не менялось.

Работа: isolated continuation branch, CPU0/один test worker; shared dependency cache и frozen checkpoints сохранены. Independent review требуется перед push. Откат кандидата — отказ от единственной правки spec до commit либо отдельный revert после публикации.
