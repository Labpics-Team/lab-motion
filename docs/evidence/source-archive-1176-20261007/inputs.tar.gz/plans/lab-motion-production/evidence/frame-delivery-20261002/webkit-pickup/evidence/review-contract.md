# Повторное изолированное review carousel oracle

Намерение: устранить WebKit CI36961284260 failure без ослабления consumer-проверок, fail-on-flaky и retry policy. Scope: один browser spec, без production code, clock subsystem, budgets или публичной документации.

Ось: различает ли исправленная проверка корректное чтение native snapshot и возврат устаревшего from, сохраняя native settle при ненулевом диапазоне. Проверь точный diff и необходимые observable предусловия, не переноси прежний verdict.

Base8a97cfde06087de80b80da078d57065b5ff38164. Кандидат browser/compositor-follow.spec.ts SHA2756c6a0a7939962b3a7ed482c89f8802c6c2972641bbe537c4e182acbd3b326. Patch candidate.patch SHAb9cf15dd633bbe7c202f06fce64a4700480e89588ee1b55870816c40e3287a7f; bindings в manifest.json.

Evidence: runtime-end-pickup.mjs/result/receipt — Chromium на точном сохранённом CI bundle, положительный consumer и stale-time-reader falsifier; typecheck-browser.json. Первичный CI artifact и trace сохранены read-only в sibling resource-webkit-repickup-20261002.ebnr3znx/evidence. Там же прежний rejected patch и исходные28 follow tests, включая zero-range fallback. Локальный canonical browser spec и WebKit не выполнялись; remote exact-head gate открыт. Нужен PASS либо конкретный finding.
