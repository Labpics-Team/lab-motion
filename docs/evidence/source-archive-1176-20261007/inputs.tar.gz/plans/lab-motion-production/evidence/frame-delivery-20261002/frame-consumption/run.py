from pathlib import Path
import subprocess, json, datetime, hashlib, os, sys
r=Path(__file__).resolve().parent; w=r/'checkout'; e=r/'evidence'
node='/home/labpics-ops/work/colors-motion-20261001/tools/motion/node-v24.21.0-linux-x64/bin/node'
stage=sys.argv[1]; command=[node]+sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy();env['PATH']=str(Path(node).parent)+os.pathsep+str(w/'node_modules/.bin')+os.pathsep+env['PATH']
source=(w/'src/motion-value.ts').read_bytes()
patch=subprocess.run(['git','diff','--binary'],cwd=w,capture_output=True,check=True).stdout
with (e/(stage+'.stdout.log')).open('wb') as out,(e/(stage+'.stderr.log')).open('wb') as err:
 p=subprocess.Popen(command,cwd=w,stdout=out,stderr=err,env=env)
 (e/(stage+'-dispatch.json')).write_text(json.dumps({'pid':p.pid,'command':command,'startedAt':started},indent=2)+'\n')
 code=p.wait()
(e/(stage+'.json')).write_text(json.dumps({'stage':stage,'command':command,'pid':p.pid,'exitCode':code,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':hashlib.sha256(source).hexdigest(),'patchSha256':hashlib.sha256(patch).hexdigest()},indent=2)+'\n')
