import { chromium } from '../../follow-current-base-20261001/checkout/node_modules/.pnpm/playwright@1.63.0/node_modules/playwright/index.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import assert from 'node:assert/strict';
const dir = new URL('./', import.meta.url);
const bundle = readFileSync(new URL('ci-recipe-bundle.js', dir));
const actions = JSON.parse(readFileSync(new URL('ci-trace-actions.json', dir), 'utf8'));
const hook = actions.find(x => x.id === 'call@888').params.expression;
const mount = actions.find(x => x.id === 'call@892').params.expression;
const html = actions.find(x => x.method === 'setContent').params.html;
const server = createServer((req,res) => {
  res.setHeader('Content-Type', req.url.endsWith('.js') ? 'application/javascript' : 'text/html');
  res.end(req.url.endsWith('.js') ? bundle : '<!doctype html><html><body></body></html>');
});
await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
let browser;
const results=[];
try {
  browser = await chromium.launch({headless:true});
  for (const kind of ['native-end-pickup','stale-time-reader']) {
    const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:2});
    const page=await context.newPage();
    await page.goto(`http://127.0.0.1:${server.address().port}/browser/fixtures/harness.html`);
    await page.evaluate('(' + hook + ')()');
    await page.setContent(html);
    await page.evaluate('(' + mount + ')()');
    const viewport=await page.locator('[data-viewport]').boundingBox();
    const x=viewport.x+190,y=viewport.y+30;
    await page.mouse.move(x,y);await page.mouse.down();
    await page.mouse.move(x-145,y,{steps:5});await page.mouse.up();
    assert.equal(await page.locator('[data-track]').evaluate(el=>el.getAnimations().length),1);
    await page.evaluate(kind=>{
      const a=window.followProbe.animations.at(-1);
      a.currentTime=Number(a.effect.getComputedTiming().duration);
    },kind);
    const before=await page.locator('[data-track]').evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).m41);
    if(kind==='stale-time-reader') await page.evaluate(()=>Object.defineProperty(window.followProbe.animations.at(-1),'currentTime',{get:()=>0}));
    await page.mouse.move(x,y);await page.mouse.down();
    const pickup=await page.locator('[data-track]').evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).m41);
    if(kind==='stale-time-reader'){
      assert.equal(before,-240);assert.equal(pickup,-145);assert.ok(Math.abs(pickup-before)>.01);
      results.push({kind,before,pickup,continuityAssertion:'REJECTED'});
      await page.evaluate(()=>window.followProbe.cleanup());await context.close();continue;
    }
    await page.mouse.move(x-40,y,{steps:3});
    const followed=await page.locator('[data-track]').evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).m41);
    await page.mouse.up();
    const result=await page.evaluate(()=>({
      animations:document.querySelector('[data-track]').getAnimations().length,
      frames:window.followProbe.frames,
      page:document.querySelector('#carousel-root').dataset.page,
      inline:document.querySelector('[data-track]').style.transform,
    }));
    assert.ok(Math.abs(pickup-before)<.01);
    assert.equal(before,-240);assert.equal(followed,-280);assert.equal(result.page,'1');
    assert.equal(result.animations,1);assert.equal(result.frames,0);
    await page.locator('[data-next]').focus();await page.keyboard.press('Enter');
    assert.equal(await page.locator('[data-page-status]').textContent(),'Страница 3 из 3');
    results.push({kind,before,pickup,followed,...result});
    await page.evaluate(()=>window.followProbe.cleanup());await context.close();
  }
} finally {await browser?.close();await new Promise(resolve=>server.close(resolve));}
const output={bundleSha256:createHash('sha256').update(bundle).digest('hex'),results};
writeFileSync(new URL('runtime-end-pickup-result.json',dir),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output));
