# Подтверждённый finding: совпадение snapshot и from

В отвергнутом candidate SHA c666d7dd currentTime=0 давал native pose=-145, совпадающий с from/inline=-145. Ошибочный pickup, читающий начальное значение вместо текущего native snapshot, сохранял прежний C0 assertion. Finding принят; этот candidate не предназначен для push.

Новый candidate ставит paused native run на duration: before=-240, а исходный inline/from остаётся -145. После drag40 значение -280, цель страницы2=-240; диапазон ненулевой. Исходный strict native-count1, кнопки и cleanup сохранены. Производственный код и политика CI не меняются.

На exact CI bundle Chromium control получил before/pickup=-240, followed=-280, animations1, frames0; keyboard next дошёл до страницы3. Единственный falsifier подменяет чтение Animation.currentTime старым нулём после фиксации видимой позы: before=-240, pickup=-145, C0 assertion отвергает его. Это проверка силы oracle, а не аппаратная точность или локальное доказательство WebKit. TypeScript browser PASS; локальный WebKit по-прежнему не доступен из-за host libraries. Новый exact-head CI и review открыты.
