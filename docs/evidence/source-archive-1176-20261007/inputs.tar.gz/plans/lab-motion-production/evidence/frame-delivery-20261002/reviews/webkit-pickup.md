# Architecture Review

Дата: 2026-10-02. Targeted re-review: carousel pickup oracle и ненулевой settle range.

## Артефакт

- Каталог: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-webkit-pickup-end-20261002.68m9hcum`.
- Base/HEAD: `8a97cfde06087de80b80da078d57065b5ff38164`; изменён только `browser/compositor-follow.spec.ts`.
- Source SHA-256: `2756c6a0a7939962b3a7ed482c89f8802c6c2972641bbe537c4e182acbd3b326`.
- Patch SHA-256: `b9cf15dd633bbe7c202f06fce64a4700480e89588ee1b55870816c40e3287a7f`.
- Manifest SHA-256: `35b271a9476310c98bb4bb2f549867e170a134083862e29432a3e0e25ec4dbf0`.
- Все перечисленные manifest inputs и shared primary evidence проверены по SHA-256. Авторский `triage.md` не читался; его bytes проверены только по hash.

## Violations

Нет подтверждённых нарушений по заданной оси. Finding предыдущего кандидата устранён; предыдущий FAIL сохраняется для прежнего patch.

## Compliant patterns

- `browser/compositor-follow.spec.ts:120` — seek к duration при paused animation даёт точный endpoint; assertion на строке 123 требует −240, что отличается от stale from −145.
- `browser/compositor-follow.spec.ts:127` — continuity assertion различает корректное чтение native позиции и возвращение stale from.
- `browser/compositor-follow.spec.ts:130` — после drag ожидается −280; строка 132 удерживает страницу 2, чей target −240. Диапазон settle равен 40 и не зависит от overshoot промежуточной позы.
- `browser/compositor-follow.spec.ts:133` — native animation, отсутствие RAF на строке 143, keyboard и cleanup сохраняются. Panel in-flight pickup на строках 69–76 не менялся.

## Evidence и пределы

`runtime-end-pickup.mjs:38` подменяет чтение currentTime на 0 после установки видимой native позы −240. Сохранённый Chromium falsifier получает pickup −145 и отклонён continuity assertion. Положительный raw результат: before/pickup −240, followed −280, native animations 1, frames 0, внутренняя page 1. Проверены исходник probe, raw JSON/stdout, receipt exit 0 и pinned bundle. Browser TypeScript receipt имеет exit 0 и совпадающие source/patch hashes. Сам reviewer ничего не исполнял из продукта. Canonical browser spec, новый WebKit и exact-head CI этим не доказаны; гейт исполнения открыт.

## Verdict: PASS
