# Architecture Review

Дата: 2026-10-02. Ось 1: consumption frame callback, reentrant successor liveness и error policy.

## Артефакт

Candidate: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-frame-consumption-20261002.fve8072_`; base/HEAD `8a97cfde06087de80b80da078d57065b5ff38164`.
Source SHA-256 `2c179e54fffe6fe36bb347c188f5197318565f4516af504523fec9c5e8e618d5`; patch `b644ef9b0fe179f0b7f66827f8b85f879fc7a7c652375cad7c03cacf5502b0e4`; manifest `8415a7fdb4946ddd153bea56e2ab96bdb62b85a6b21850d933309043c41aa64b`.
Все manifest files и размеры совпали; production diff ограничен MotionValue, добавлен один regression. В checkout и ancestors AGENTS.md отсутствует; применены переданный канон и публичные контракты.

## Violations

Нет подтверждённых нарушений по заданной оси.

## Compliant patterns

- `src/motion-value.ts:382` — callback получает локальное состояние consumed до `_tick`, поэтому повтор той же заявки, в том числе из getter, не двигает физику и не создаёт второй цикл.
- `src/motion-value.ts:373` — отдельная заявка имеет собственный `called`; `_run` на строках 371, 411 и 429 отсекает старого владельца, сохраняя кадр нового запуска из getter/listener. Удалённый общий `_tickActive` больше не может подавить отдельную заявку.
- `src/motion-value.ts:390` — sync delivery остаётся за одним существующим trampoline; после возврата stale host callback не получает второй тик. Stop/destroy ревокируют run до дальнейшего исполнения.
- `src/motion-value.ts:399` — ошибка выдачи отзывает только принадлежащий ей run; уже созданный преемник не отменяется старой ошибкой.
- `src/motion-value.ts:476` — после listener error перепланирование сохраняет живость, вторичная scheduler error не маскирует исходную. `_emit` использует отдельный `failed` на строке 486, поэтому undefined/null/false/0/empty-string throw сохраняются.

## Evidence и пределы

Да: статически проверены exact diff, scheduler/tick/emit, reentrant-start и listener-isolation tests. Baseline source hash проверен через Git; raw RED показывает повторное продвижение sample/эмиссии старой заявки. Candidate receipt и stdout подтверждают 174 tests, включая отдельного преемника, nested duplicate, falsey error precedence, stop/snap/destroy и shared scratch. Raw ESM/CJS probe содержит по 5 законченных сценариев; entry hashes совпадают с manifest, receipts exit 0. Typecheck/build/declarations receipts также привязаны к candidate.
Не было: reviewer test/build execution, новых browser/runtime/release проверок. Достаточный сохранённый evidence не повторялся. Совместимость всей host-поверхности и последствия второго порядка относятся к отдельно назначенной оси 2; exact-head CI этим verdict не закрывается.

## Verdict: PASS
