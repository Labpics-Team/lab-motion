# Architecture Review

Дата: 2026-10-02. Ось 2: совместимость injected RequestFrameFn/asRequestFrame и минимальность владельца consumption. Lifecycle findings оси 1 здесь не повторяются.

## Артефакт

Candidate: `/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-frame-consumption-20261002.fve8072_`; base `8a97cfde06087de80b80da078d57065b5ff38164`.
Source SHA-256 `2c179e54fffe6fe36bb347c188f5197318565f4516af504523fec9c5e8e618d5`; patch `b644ef9b0fe179f0b7f66827f8b85f879fc7a7c652375cad7c03cacf5502b0e4`; manifest `8415a7fdb4946ddd153bea56e2ab96bdb62b85a6b21850d933309043c41aa64b`. Pins ранее прочитанного неизменяемого packet проверены; изменены только MotionValue и новый regression.

## Violations

Нет подтверждённых нарушений по заданной оси.

## Compliant patterns

- `src/motion-value.ts:47` и `src/drive.ts:57` — публичная инъекция определена как requestAnimationFrame substitute. Периодическая подписка одной callback-функции не является обещанием этого шва.
- `src/frame/index.ts:285` — существующий документированный consumer прямо задаёт «заявка = once-подписка»; строки 296–299 реализуют её через update/once:true и ненулевой handle. One-shot consumption следует из существующего контракта.
- `src/motion-value.ts:373` — consumption принадлежит callback closure отдельной заявки. Не возникает требования уникальности handle: постоянный handle 1 остаётся допустимым. Отдельная следующая регистрация имеет собственный флаг и timestamp.
- `src/motion-value.ts:379` — sync delivery по-прежнему сохраняет timestamp и переводится в прежний trampoline; async delivery использует переданный timestamp либо прежний fixed step. Правила handle=0 и late callback остаются прежними.
- `src/frame/index.ts:298` — адаптер продолжает входить через порт ядра; MotionValue не импортирует frame/compositor/DOM. Фазы и batch-boundary принадлежат FrameLoop, а право одной MotionValue-заявки — её `_schedule`.
- `src/compositor/core.ts:940` — обёртка scheduler/callback через `_resume` сохраняется; нормализация не вводит обход её capability.
- `src/motion-value.ts:382` — повторно использован существующий локальный `called`, удалён общий tick guard. Новых публичных типов, параметров, зависимостей, механизмов clock или ceilings нет; более общий abstraction owner не требуется для этого среза.

## Evidence и пределы

Да: отдельно сопоставлены публичные типы/опции, DriveOptions, default scheduler, asRequestFrame, batch/once owner FrameLoop, compositor wrapper и 11 frame-adapter tests. Последние проверяют Object.is журналы own/shared clock, retarget/stop/snap/resume, interleaving, фазу update, D11, сон/пробуждение и reentry; candidate raw stdout/receipt подтверждают их PASS. Sync/async scheduler coverage имеется в сохранённом packet. Size raw показывает полный вектор PASS без изменения thresholds, включая full-core 2319/2330 и compositor-stagger 6597/6600 bytes gzip.
Не было: новых reviewer test/build runs. Этот verdict не утверждает совместимость с произвольным periodic-callback API вне опубликованного rAF substitute и не закрывает exact-head CI/release. Проверка достаточна для сохранения заявленного шва без его сужения.

## Verdict: PASS
