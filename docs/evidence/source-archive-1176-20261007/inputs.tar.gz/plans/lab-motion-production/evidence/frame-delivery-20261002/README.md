# Однократная доставка кадра и повторный захват анимации

Кандидат Motion: `c59e47ae3a7083a2469b878b89ca807e81bdb6ba`, [PR458](https://github.com/Labpics-Team/lab-motion/pull/458). [CI36973432623](https://github.com/Labpics-Team/lab-motion/actions/runs/36973432623) завершился SUCCESS: все 10 проверок, включая package/consumer contract и Chromium/Firefox/WebKit.

`MotionValue` погашает заявку до вызова пользовательского кода. Повторная доставка той же заявки инертна; новая reentrant-анимация получает собственную заявку. Удалён общий `_tickActive` guard. [Lifecycle review](reviews/frame-axis1.md) и [host compatibility review](reviews/frame-axis2.md) получили отдельные PASS. Сохранены исходный RED, 174 затронутых теста, typecheck, сборка/declarations, size и raw ESM/CJS consumer-сценарии в [frame-consumption/evidence](frame-consumption/evidence).

Все прежние size ceilings сохранены. Измерение sandbox: full-core 2319/2330 B gzip, stagger 6597/6600; animate+compositor 17152/17500 (+8 B к предшествующему снимку). Это проверка размеров и поведения, не измерение общего выигрыша runtime/heap.

Первый вариант carousel oracle с `currentTime=0` отклонён: он не различал правильный pickup и старый `from`. [Finding](reviews/webkit-initial.md) сохранён вместе с [первичным пакетом](webkit-initial/evidence). [Исправленный пакет](webkit-pickup/evidence) использует позицию −240, отличную от старой −145; drag даёт −280 и ненулевой settle range. Контроль с подменой чтения на старую позицию отвергается. [Повторное review](reviews/webkit-pickup.md) — PASS.

Файлы — побайтные копии исходных пакетов. Их manifests описывают исходные snapshots; абсолютные пути относятся к прошлым запускам. Копии checkout/dist, caches и node_modules не включены: код закреплён Git-коммитом, hashes сборки сохранены в исходном manifest. Для повторения запусков нужно восстановить пути и зависимости из соответствующего checkout. Исторические «review/CI открыт» внутри исходных документов сохраняют дату своего среза.

Полные RESOURCE-01/M-07, JOURNEY-01 и PROFILE-01 этим срезом не закрываются. Merge, release и deploy не выполнялись.
