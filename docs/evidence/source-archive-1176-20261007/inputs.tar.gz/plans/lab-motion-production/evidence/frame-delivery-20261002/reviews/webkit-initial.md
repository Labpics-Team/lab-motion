# Architecture Review

Объект: `tmp/motion/resource-webkit-repickup-20261002.ebnr3znx`, base `8a97cfde06087de80b80da078d57065b5ff38164`.
Patch SHA256 `725fd87952199e59f1316c481cb2ae7af43b5a312714e9dcc9d4dab8dea5dba6`; browser source `c666d7dda2311045924b8c8796763ca8a4132449e6f4f6660b6c9dc80cd294e6`; manifest `fd26fbb754ad88fe3a105a867949200a0ee9f5a3d1498706ddbced9d19d8e25b`.
Ось: устранение flaky browser oracle без потери потребительского различающего свойства. Авторский RESULT/RCA не читался.

## Violations

- [browser/compositor-follow.spec.ts:118] [action_required] [Невакуумность oracle / сохранение регрессионного свойства] — `currentTime=0` делает native position равной start/from `-145` (строка 120), то есть старому direct/inline значению после первого drag. Равенство before/after pickup на строке 124 теперь проходит и при ошибочном возврате к старому from вместо текущей native position. Прежний `currentTime=30` мог различать эти состояния. Новый Chromium witness тоже использует t=0 и не закрывает потерянное различение. Не утверждается, что весь набор тестов потерял общий handoff-контроль: panel:69–76 и unit:60–67 проверяют другой контекст. Finding относится к изменённому carousel consumer oracle → defer fix to qa-tester / Motion owner.

Минимальная корректировка тестового состояния: сохранить детерминированную native position, отличающуюся от старого from, затем сделать ненулевой settle. Например, конец первого paused native-прогона имеет target `-240`; drag ещё на 40 даёт `-280`, page 2 и settle к `-240` с ненулевым диапазоном. Это предложение основано на recipe:539–540 и сохранённом runtime witness для before=-240; новый изменённый тест нужно проверить отдельно. Не требуется менять production fallback, ceilings или retry policy.

## Compliant patterns (acknowledge good architecture)

- [browser/compositor-follow.spec.ts:14] — package tarball/bundle binding сохранён; изменён только browser spec. Manifest/source/diff identity проверены.
- [browser/compositor-follow.spec.ts:125] — added releasedFrom/page assertions делают предпосылку nonzero settle наблюдаемой; это правильная граница для native-count assertion.
- [test/compositor-follow.test.ts:370] — существующий zero-range+impulse случай требует canonical live fallback, ноль native animations и mode fallback. Файл совпадает с base; final unit receipt сохраняет 28 passing tests.
- [runtime-witness-corrected-result.json:1] — два Chromium случая подтверждают разные допустимые outcomes: nonzero range даёт native animation, zero range+impulse — frames без native animation. Это не новое исполнение WebKit и не доказательство причины исходного CI failure.
- [review-contract.md:11] — ограничения раскрыты: новый WebKit exact-head CI и полный canonical browser spec ещё не пройдены. Первичные CI log/trace фиксируют 0 вместо ожидаемой 1; успешный автоматический retry не переименован в исправление.
- [manifest.json:39] — TypeScript receipt относится к более раннему общему patch; browser bytes сохранились, удалена только добавка unit-теста. Область typecheck reuse объяснена; это не fresh browser runtime PASS.

## Evidence и границы

Прочитаны exact diff/spec, общий pointerInput и recipe release, unchanged unit controls, первичный trace ZIP и receipts. Manifest entries и обе source identities совпали. Trace подтверждает paused native wrapper и выставление t=30 в исходном прогоне; recipe выбирает страницу из позиции, а не по наличию native animation.

**Да:** статическая независимая проверка oracle и первичного evidence.
**Нет:** сохранение различающего carousel pickup assertion в предложенном t=0 варианте.
**Не было:** новых tests/browser/build, source edits, Windows, новых агентов или чтения авторского RESULT. Поиск дополнительных багов продукта не проводился.

## Verdict: FAIL
