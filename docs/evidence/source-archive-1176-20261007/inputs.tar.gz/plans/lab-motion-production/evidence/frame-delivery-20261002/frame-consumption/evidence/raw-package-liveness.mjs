import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const format = process.argv[2];
assert.ok(format === 'esm' || format === 'cjs');
const entry = path.resolve(`dist/index.${format === 'esm' ? 'js' : 'cjs'}`);
const { MotionValue } = format === 'esm'
  ? await import(pathToFileURL(entry).href)
  : createRequire(import.meta.url)(entry);
const SPRING = { mass: 1, stiffness: 200, damping: 20 };
const cases = [];

function makeClock(syncSuccessor = false) {
  const queue = [];
  const delivered = new Set();
  let requests = 0;
  return {
    requestFrame(callback) {
      const handle = ++requests;
      const once = () => {
        assert.equal(delivered.has(handle), false);
        delivered.add(handle);
        callback();
      };
      if (syncSuccessor && handle === 2) once();
      else queue.push(once);
      return handle;
    },
    next() { assert.ok(queue.length > 0); queue.shift()(); },
    drain() {
      for (let steps = 0; queue.length > 0; steps++) {
        assert.ok(steps < 1000);
        this.next();
      }
    },
    pending: () => queue.length,
    requests: () => requests,
  };
}

for (const site of ['getter', 'listener']) {
  const clock = makeClock();
  let value;
  let armed = false;
  let origin;
  const handoff = () => {
    if (!armed) return;
    armed = false;
    origin = [value.value, value.velocity];
    value.stop();
    value.setTarget(2);
    clock.next();
  };
  const params = {
    get mass() { if (site === 'getter') handoff(); return 1; },
    stiffness: 200, damping: 20,
  };
  value = new MotionValue({ initial: 0, spring: params, requestFrame: clock.requestFrame });
  value.onChange(() => { if (site === 'listener') handoff(); });
  value.setTarget(1);
  armed = true;
  clock.next();
  assert.ok(origin);
  assert.equal(clock.pending(), 1);
  const before = clock.requests();
  value.setTarget(2);
  assert.equal(clock.requests(), before);
  const referenceClock = makeClock();
  const reference = new MotionValue({
    initial: origin[0], initialVelocity: origin[1], spring: SPRING,
    requestFrame: referenceClock.requestFrame,
  });
  reference.setTarget(2);
  referenceClock.next();
  assert.deepEqual([value.value, value.velocity], [reference.value, reference.velocity]);
  reference.destroy();
  referenceClock.drain();
  clock.drain();
  assert.deepEqual([value.value, value.velocity, clock.pending()], [2, 0, 0]);
  value.destroy();
  cases.push(`${site}: distinct successor stays live`);
}

for (const site of ['getter', 'listener']) {
  const clock = makeClock(true);
  let value;
  let armed = false;
  let finish;
  const settled = new Promise(resolve => { finish = resolve; });
  const handoff = () => {
    if (!armed) return;
    armed = false;
    value.stop();
    value.setTarget(2);
  };
  value = new MotionValue({
    initial: 0,
    spring: { get mass() { if (site === 'getter') handoff(); return 1; }, stiffness: 200, damping: 20 },
    requestFrame: clock.requestFrame,
  });
  value.onChange(current => {
    if (site === 'listener') handoff();
    if (current === 2 && value.velocity === 0) finish();
  });
  value.setTarget(1);
  armed = true;
  clock.next();
  assert.equal(clock.pending(), 0);
  let timeout;
  try {
    await Promise.race([settled, new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('successor did not settle')), 2000); })]);
    assert.deepEqual([value.value, value.velocity, clock.requests()], [2, 0, 2]);
  } finally {
    clearTimeout(timeout);
    value.destroy();
  }
  cases.push(`${site}: synchronous successor trampoline settles`);
}

const queue = [];
const value = new MotionValue({
  initial: 0, spring: SPRING,
  requestFrame(callback) { queue.push(callback); return 1; },
});
let emissions = 0;
value.onChange(() => emissions++);
value.setTarget(1);
const delivered = queue.shift();
delivered();
const snapshot = [value.value, value.velocity, emissions];
delivered();
assert.deepEqual([value.value, value.velocity, emissions], snapshot);
assert.equal(queue.length, 1);
queue.shift()();
assert.ok(value.value > snapshot[0]);
assert.equal(emissions, snapshot[2] + 1);
assert.equal(queue.length, 1);
value.destroy();
queue.shift()();
assert.equal(queue.length, 0);
cases.push('duplicate request consumed; next request progresses');

console.log(JSON.stringify({ format, entry, entrySha256: createHash('sha256').update(readFileSync(entry)).digest('hex'), cases, passed: cases.length }));
