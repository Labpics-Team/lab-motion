# Изолированное review: граница native oracle в carousel spec

Намерение пользователя: устранить исходный WebKit failure run 36961284260, сохранив понятный OSS-код, поддерживаемость и сильные границы. Случайный retry не считается исправлением. Fail-on-flaky и retry policy не ослаблять; production fallback не подгонять под native-count assertion.

Ось: корректность и достаточность изменения browser oracle. Проверь, что выбранная фаза native animation и проверяемые значения обеспечивают нужный сценарий, а существующий zero-range/fallback сосед не потерян. Учитывай, что pointer timestamps реальные; это не hardware/latency claim. Не менять файлы; не запускать новые проверки без отдельной необходимости.

Кандидат: base `8a97cfde06087de80b80da078d57065b5ff38164`, единственный изменённый файл `browser/compositor-follow.spec.ts`, SHA-256 `c666d7dda2311045924b8c8796763ca8a4132449e6f4f6660b6c9dc80cd294e6`. Diff: `candidate-final.patch`; точная карта: `manifest.json`.

Первичное evidence: `ci-artifacts.json`, `ci-artifact.zip` (digest совпал с GitHub), `ci-failure-trace.zip`, `ci-failure.log`, `ci-jobs.json`. Trace содержит исходники spec/harness и resource JS/receipt. `ci-trace-actions.json` — производная проекция before/after действий, не полный trace. `ci-recipe-bundle.js` — точные JS bytes из trace; receipt подтверждает их SHA.

Выполненные проверки: `runtime-witness-corrected.mjs`, result/receipt/log — Chromium, ровно два consumer случая с исходным CI recipe bundle; `unit-final.json`/stdout — 28 существующих follow tests; `typecheck-browser.json` — browser TypeScript с теми же candidate browser bytes. Локальный WebKit не стартовал из-за недостающих host libraries; его новый exact-head CI gate открыт. Полный canonical browser spec локально не запускался. Нужен PASS либо finding с конкретным противоречием контракта и evidence.
