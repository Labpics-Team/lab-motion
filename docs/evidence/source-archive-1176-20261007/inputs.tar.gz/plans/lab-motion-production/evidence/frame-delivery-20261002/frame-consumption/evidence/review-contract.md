# Контракт независимой проверки

Намерение: восстановить размерные гейты Motion, сохранив владельцев подписок и запусков из checkpoint 8a97cfde06087de80b80da078d57065b5ff38164. Пороговые значения, публичные опции, зависимости и пути доставки не меняются. Браузерное исправление является отдельным коммитом и не входит в этот diff.

Объект: candidate.patch; два файла — src/motion-value.ts и test/motion-value-frame-delivery.test.ts. Точные digest находятся в candidate-inputs.json; исходники скопированы в candidate-source.ts и candidate-test.ts. Checkout заморожен до вердикта.

Первая ось: право на один кадр и жизнеспособность нового запуска. Отдельная заявка преемника из getter/listener после возврата requestFrame должна исполниться; синхронная доставка внутри requestFrame должна пройти через один trampoline. Повтор уже доставленной заявки не должен размножать цикл. Stop/destroy и host throw сохраняют прежний результат, порядок listener/scheduler ошибок сохраняется, falsey throw не теряется.

Вторая ось для отдельного запроса: совместимость инжектированных планировщиков и цена контракта. Проверить, следует ли однократность заявки из существующего шва, не возникает ли новое скрытое ограничение или потеря законного callback, и остаётся ли решение минимальным. Публичный RequestFrameFn — src/motion-value.ts:37; описание substitute — MotionValueOptions; исходный соседний контракт — DriveOptions.requestFrame; штатные владельцы — src/internal/request-frame.ts, src/frame/index.ts (asRequestFrame), src/compositor/core.ts (_liveCandidate).

Evidence:
- red-delivery.*: исходный checkpoint с новым тестом; ошибка на повторной доставке той же заявки, изменение observable sample и числа эмиссий. В receipt patch пустой: тест тогда был untracked, его digest зафиксирован в inputs.json.
- unit.*: 174 теста, включая существующие reentrant-start, listener isolation, shared scratch, follow и 11 differential frame-adapter.
- typecheck.*, build-js.*, build-declarations.*, size.*: канонические команды на данном source digest, полный размерный вектор.
- raw-package-liveness.mjs, raw-esm.*, raw-cjs.*: прямой Node import/require собранных dist; по пять сценариев преемника, trampoline и повторной заявки; digest entry в stdout.

Удалённые проверки exact-head и независимое review ещё не закрыты этим локальным evidence. Никаких новых browser или production claims здесь нет.
