from pathlib import Path
import subprocess,json
r=Path('/home/labpics-ops/work/colors-motion-20261001/tmp/motion/resource-frame-consumption-20261002.fve8072_')
stages=[('typecheck', ['node_modules/typescript/bin/tsc', '--noEmit']), ('build-js', ['node_modules/tsup/dist/cli-default.js']), ('build-declarations', ['scripts/emit-declarations.mjs']), ('size', ['scripts/size-gate.mjs'])]
for name,args in stages:
 subprocess.run(["python3",str(r/"run.py"),name]+args,check=True)
 receipt=json.loads((r/"evidence"/(name+".json")).read_text())
 if receipt["exitCode"]!=0: break
