# Motion: локальный пакет для draft review

Кандидат78e7ab200f473667d8863ff028c17c2e0d7debbc, tree41bf2ed317ac4c3f98c08c12ea85f20c651f5238; product base957ceaf26501525eff476cdc1d149d81fd5ebcd7. Authority cutoff70df60b58d085800d09fe1b29b612c0373982db1, ACTIVE/r11.

Начните с evidence/draft-pr-body.md и evidence/draft-local-gates-78e7ab2.json. Полный unit RED5127/10; static и driver mutation PASS; broad mutation RED на initial healthy timeout, campaign НЕ БЫЛО. WebKit, remote CI, substantive CodeRabbit и публичный carrier не закрыты. Ни архив, ни локальный PASS не означают готовность к merge/release/deploy.

MANIFEST.json связывает каждый относительный путь, исходный путь и SHA256. Архив содержит тексты и первичные receipts, а не свидетельство их публичной публикации. reviews/ хранит копии независимых отчётов с их ограниченной областью; исходные Git commits перечислены в отчётах.

resource/previous-pass и resource/current-red сохраняют разные наблюдения того же tarball6e81 и probe. Единственная копия actual qualified tarball находится в packages/; это канонические bytes, дубли package.tgz из raw run-каталогов опущены. Если scope browser использовал repack с mode-only отличием, его отдельный архив и сравнение member bytes сохранены. Никакого равенства archive SHA между ними не заявлено.

Source bundle incremental: prerequisite9e61edeffc864f6710845ef242bc76e077a49701; head78e7ab2. Он переносит финальные commits и не заменяет исходную историю #460/#461. Полный diff к main и отдельная integration delta лежат рядом; refs исходных PR не переписаны. Исторические FAILED runs не переименованы в текущий PASS.

Абсолютные пути в сырых receipts сохраняют происхождение Linux sandbox. Для чтения из архива используйте относительный carrierPath из MANIFEST, а не предполагайте наличие прежнего рабочего каталога. Здесь нет нового product runtime, runner или deployment механизма.
