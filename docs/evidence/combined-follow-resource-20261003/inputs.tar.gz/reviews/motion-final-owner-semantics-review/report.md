# Независимое ревью owner/lifecycle

**PASS** — подтверждённых нарушений в проверенном семантическом срезе не обнаружено.

Объект: `Labpics-Team/lab-motion@76b90e6210904224bd867df032096531fb736222`, tree `c89e0cf3da87470a13df7d9b5a732085d3377601`. База runtime-сравнения: `7153f1031e824bdb9ad24110dd66d85fe5d5ec38`. Проверена одна ось: сохранение owner/lifecycle при интеграции follow и RESOURCE, включая native/live/follow, CAS, повторный вход, сохранение successor, terminal cleanup и семантику declare-полей. Архитектура/TCO и полная приёмка плана в этот вердикт не входят.

Намерение: выполнить согласованные планы Lab Colors r19 и Lab Motion production r11 в Linux sandbox; изолированная ветка/draft PR допустимы, merge/deploy не разрешены. Сохраняются исходные limits, 38 RESOURCE-ячеек и cancellation/reentry-инварианты. Рецензент не менял исходники, тесты или writer evidence; прочие вердикты и рассуждения автора не использовались.

## Норма и идентичность

Прочитаны переданные AGENTS-инструкции, навыки verify/qa, CONTRIBUTING и действующий compositor API-контракт. Отдельных AGENTS.md в checkout и проверенных родительских каталогах не найдено. План прочитан через Git-объект `agents-config@a3b751b151124d4bb05b4b0ac2dbf9270843f2da:plans/lab-motion-production/r11.md`: INV-01/02/04/06/07, M-07, G-PERF и применимая граница G-COMPOSE.

Git-проверка подтвердила clean HEAD и ровно три изменённых пути относительно baseline: `src/compositor/core.ts`, `src/compositor/follow.ts`, `src/compositor/stagger.ts` (37 добавлений, 50 удалений). Обе RESOURCE fixture и `scripts/size-gate.mjs` байт-неизменны относительно baseline. Полный tree доказательного commit `0a0149eb505e9e631211679a6b0503c08ebbbddc` равен tree FINAL, включая зависимости, тесты и build-конфигурацию.

Readset, Git blob IDs, SHA-256, области чтения, точная копия r11, runtime diff и копии raw logs сохранены рядом. `manifest.json` фиксирует происхождение каждого файла. SHA-256 runtime diff: `6933354cbdcb367d25963789c2ca65300b5c1bb9c96a61d3823525189c19d23d`.

## Проверенные свойства

1. **Timer CAS и одноразовое завершение.** В `core.ts:594–621` бывшее тело `_adoptTimer` встроено без изменения reservation/generation-протокола: слот резервируется до setTimer; callback снимает host и продвигает epoch до setTarget; stale return освобождает только чужой handle; совпадающий с current handle не отменяется. Throw освобождает ещё не занятый reservation и инвалидирует утёкший callback. Для delay=0 повторная проверка epoch была избыточной: успешный `_ensureFallback` уже проверил generation, а новой внешней границы до setTarget нет. Конечный неотрицательный delay валидируется в конструкторе; -0 сохраняет прежний immediate путь. Адресные проверки: `compositor-host-owner.test.ts:179–451,485–545`; положительный successor существует и продолжает работу.

2. **Отзыв live при native commit.** В `core.ts:932–947` CAS остаётся до публикации host/metadata. Новый native host принимается перед отзывом live, старый live уничтожается до donor cancel. `_commitOwner` в `core.ts:1017–1020` сначала снимает `_mv`; переопределение `follow.ts:124–127` снимает input session и вызывает базовую очистку. `MotionValue.destroy` (`motion-value.ts:317–322`) отзывает run, зависимости и внутренние unsubscribe-замыкания, не вызывая пользовательские listeners; перестановка очистки не добавляет внешней callback-границы. Native отказ до commit сохраняет donor; stale native return оплачивается и не подменяет current owner. Адресные проверки: `compositor-return-to-native.test.ts:61–218` и `compositor-follow.test.ts:205–307`.

3. **Публикация live successor.** В `core.ts:985–998` после host cleanup остаётся повторный CAS. `_commitOwner` выполняется до присваивания нового `_mv`, поэтому новый loan не уничтожается вместе со старым. `_to` и `_mv` опубликованы до scheduler IO; scheduler throw оставляет повторяемый новый owner. Старый owner не восстанавливается после reentrant intent. Проверены `compositor-host-owner.test.ts:589–639,785–839`, reduced-loan и native→live→native сценарии, а также follow→live→pickup→settle. Сохранены полезная доставка цели, режим исполнения и отсутствие stale write/reschedule.

4. **Terminal cleanup и reentry.** `destroy` (`core.ts:812–821`) публикует terminal `_now=undefined` и снимает захваты до commit/host cleanup. Удалённый override InputSpring.destroy заменён тем же отзывом `_following` через единственный commit hook. `_releaseHost` снимает ссылку до недоверенного cancel; повторный destroy не отменяет handle второй раз. `_cleaning`/`_resume` по-прежнему отделяют хвост stale cleanup от continuation текущего owner. Проверены адресные hostile-host traces и ограниченная модель из `compositor-host-owner.test.ts:890–951`: два host-типа, все 4^5 последовательности, активный owner и cancel-count проверяются после каждого шага. Это bounded evidence, не доказательство всех возможных трасс.

5. **declare и группа.** `declare` действительно убирает runtime-инициализацию поля; равенство собственных ключей объекта не заявляется. `_cleaning` до первой записи читался как undefined и продолжает давать тот же результат. `_plan` присваивается после compile/validation; `_springs` получает тот же массив до заполнения вместо после заполнения. Конструктор не публикует group наружу, публичные методы вызываются на уже построенном объекте. Ни порядок child options, ни их capture, ни delay/count/index guards не изменены. Нет поддерживаемого публичного чтения этих полей до присваивания. Адресные проверки: `compositor-stagger.test.ts:278–404`, count-boundary suite; сохранён предел count=100000 и отказ 100001 до materialization.

6. **RESOURCE denominator.** В wrapper независимо перечислены те же 19 kinds, что в probe, для ESM и CJS — ровно 38 уникальных ячеек. Сохраняются 10000 циклов на ячейку, сравнение полного ожидаемого списка, positive live-owner/dropped/deliberate controls и terminal проверки cancel/effects/jobs. Follow-native, follow-pickup и follow-live присутствуют. В scope этого review установлены неизменность fixture и пригодность относящихся к изменению assertions; fresh выполнение всей RESOURCE-матрицы принадлежит writer.

## Evidence и пределы

- **Да:** независимое чтение source/diff/contracts; Git/Python проверки exact commit/tree, clean state, трёх изменённых путей, byte identity fixtures/size-gate и denominator=38.
- **Да, сохранённое выполнение writer:** raw `group-owner-focused.log` содержит 145 passed / 7 files / 0 failed; receipts указывают commit `0a0149…`, чей полный tree равен FINAL. Это поддерживает семантический вывод для этого снимка.
- **Да, сохранённое выполнение writer:** build завершён, raw size log содержит compositor-stagger capability 6600 B gzip при прежнем пороге 6600; threshold-файл неизменён. Это не самостоятельная performance qualification.
- **Не было у reviewer:** нового запуска tests/build/browser/RESOURCE/mutation; нагрузка не конкурировала с текущими измерениями writer. Изменений исходников, merge/deploy/readback production не было.

PASS относится к перечисленной оси и immutable FINAL. Новые exact-head CI, полная RESOURCE/browser/package/mutation-матрица и другие обязательные delivery gates должны завершаться отдельно; этот review не закрывает их и не разрешает merge/deploy. Изменение трёх runtime-файлов, MotionValue cleanup, TS emission-настроек или проверенных контрактов инвалидирует соответствующий вывод.

Подтверждённых findings: **0**. Открытых семантических findings в проверенном срезе: **0**.
