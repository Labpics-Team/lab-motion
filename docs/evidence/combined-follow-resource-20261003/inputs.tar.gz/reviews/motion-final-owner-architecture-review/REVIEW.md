# Architecture Review

## Anchor и область

**Вердикт: PASS в проверенной структурной оси.** Подтверждённых нарушений нет.

- Репозиторий: `Labpics-Team/lab-motion`; checkout: `/home/labpics-ops/work/motion-follow-resource-integration-20261002/source`.
- FINAL: `76b90e6210904224bd867df032096531fb736222`; tree: `c89e0cf3da87470a13df7d9b5a732085d3377601`.
- Baseline: `7153f1031e824bdb9ad24110dd66d85fe5d5ec38`. Diff: только `src/compositor/{core,follow,stagger}.ts`, 37 добавленных и 50 удалённых строк. Рабочее дерево чистое.
- План: `agents-config@a3b751b151124d4bb05b4b0ac2dbf9270843f2da:plans/lab-motion-production/r11.md`, §4 INV-01/02/05/09/12 и RESOURCE-01. Намерение: единый Motion-пакет с сохранением бюджетов, гарантий и публичной совместимости; review не разрешает merge/deploy.
- Ось: последствия второго порядка, стоимость изменения, единственный владелец исполнения, публичное наследование и эмиссия типов. Детальная correctness/reentry-ось, полная продуктовая приёмка и новая qualification ресурсов сюда не входят.

Точный readset, Git blob ID, SHA-256 и проверенные диапазоны сохранены в `readset.json`. Применимых `AGENTS.md` в проверенных Linux ancestors и внутри compositor нет; применены переданный канон и `CONTRIBUTING.md`. Навыки: backend, architecture, verify, write; в текущем backend отдельной секции architecture нет, поэтому правила границ взяты из действующего architecture skill. Skill tool в доступной surface отсутствует; SKILL.md прочитаны непосредственно.

## Violations

Нет подтверждённых нарушений в заданном diff. Исправления не требуются; source и входные evidence не изменялись.

## Compliant patterns (acknowledge good architecture)

- `src/compositor/core.ts:1016`, `src/compositor/follow.ts:124` — отзыв прежнего live/input исполнения сходится в существующей commit-границе. База освобождает принадлежащий ей MotionValue; единственный внутренний подкласс очищает свой input state и вызывает `super._commitOwner()`. Отдельный private `_releaseLive` и отдельный override `destroy` удалены. Новый глобальный store, scheduler, registry или второй controller не добавлены.
- `src/compositor/follow.ts:4`, `src/compositor/index.ts:6`, `src/compositor/follow/index.ts:2` — зависимость остаётся `follow → core`; ядро не импортирует follow. Factory возвращает ограниченный `CompositorFollow`, класс `InputSpring` не экспортируется. Опциональная композиция не расширяет старые barrels.
- `scripts/emit-declarations.mjs:28`, `scripts/pack-compat.mjs:40`, `tsup.config.ts:113` — внутренние underscore hooks не являются обещанным API: `stripInternal` удаляет их из деклараций, runtime-сборка переименовывает private/internal имена. Четыре просмотренных d.ts/d.cts не содержат `_commitOwner` или protected fields. Существующий packaged-consumer контракт явно запрещает override этого hook, а `scripts/pack-smoke.mjs:183` проверяет наследование через публичные `value`/`stop`. Новая обязанность внешнего subclass вызывать internal `super` не возникает.
- `src/compositor/stagger.ts:212` — `_plan` и `_springs` остаются частным состоянием группы; раннее присваивание массива происходит в конструкторе, семантика публичных getter и методов не меняется. `declare` согласован с существующими непубличными полями core. Изменяемое состояние не вынесено за границу группы.
- `src/compositor/core.ts:595` — одноразовый `_adoptTimer` встроен в единственное место вызова; прежний host-slot, reservation и epoch остаются у того же владельца. Не появляется новый общий callback-протокол или платформа таймеров.

## Сценарии и простота

| Сценарий | Проверенная граница и вывод |
|---|---|
| Существующий внешний subclass использует public `value`, `start`, `retarget`, `stop`, `destroy` | Сигнатуры и пакетные entry не изменены; internal hook отсутствует в обеих ветках типов. Source-only override внутреннего имени не является поддержанным контрактом наследования. |
| Sheet/pager меняет UI-координаты или snap policy | Рецепт `docs/recipes.md:732` хранит pointer state и ограничения у consumer; `docs/compositor.md:83` сохраняет эту границу. Изменение owner-cleanup не заставляет UI знать `_mv`, epoch или этапы host cancellation. |
| Обновляется способ освобождения live исполнения | Правило находится в base `_commitOwner`; внутренний follow добавляет только отзыв собственного input state. Публичным consumers не нужен согласованный выпуск или миграция. |

SOLID и dependency rule не нарушены новым diff: platform seams остаются у controller, чистая математика не получает transport/UI dependency. Для DDD здесь применим lifecycle одного output-owner, а не DB aggregate; новый доменный store не создаётся. Комментарии у commit и timer описывают проверяемый порядок отзыва, а не новую публичную терминологию.

Самая близкая альтернатива — оставить отдельный private `_releaseLive` и no-op `_commitOwner`, как в baseline. Она сохраняет два действия, порядок которых надо согласовывать в каждом lifecycle caller; текущая консолидация уменьшает это обязательство. Невиртуальная обёртка с дополнительным hook могла бы исключить необходимость `super` для будущих внутренних subclasses, но при единственном существующем subclass создаёт ещё один механизм без доказанного потребителя и выигрыша. Перенос input state в core увеличил бы связанность опциональной capability. Существенно более простой эквивалентный вариант по просмотренным границам не установлен; неизмеренные альтернативы не объявляются Pareto-улучшениями.

Условие пересмотра: новый экспортируемый hook/subclass, второй внутренний override без полного base cleanup, требование UI управлять owner stages, либо контрпример на поддержанном public subclass. Эти наблюдения открыли бы затронутую ось; одна лишь техническая возможность обратиться к internal имени её не открывает.

## Evidence и пределы

**Да — выполнено reviewer:** сверка SHA/tree/branch/remote/dirty state, точный diff, read-only аудит границ и consumer declarations, проверка Git-байтов readset, tree equivalence и RESOURCE blob identity. Команды исполнялись только в Linux через Tailscale transport.

**Входное evidence:** `group-owner-candidate-receipts.json` и три соответствующих лога сообщают 145 tests / 7 files, успешные build и size для `0a0149eb505e9e631211679a6b0503c08ebbbddc`. Этот commit имеет тот же tree, что FINAL. Лог size фиксирует canonical stagger consumer 6600 B при cap 6600 и follow 6455 B при cap 7474. В diff нет изменения thresholds. Это точное совпадение исходного дерева, а не утверждение о новом выполнении полной FINAL-матрицы.

Два RESOURCE fixture-файла из atomic FINAL-коммита имеют те же Git blobs, что baseline: `0aa5bf6f904a85706bad91a1fbd5856cc8f6baa6` и `7056bc900ce32bd77da4b46c2528ec51a35f3880`. Их runtime correctness не переоценивается этой осью.

**Не было — reviewer не запускал:** build/test workloads, pack smoke/compat, ресурсные или performance замеры, remote CI, deploy и runtime readback. Просмотр emitted declarations — ограниченное наблюдение с сохранёнными хэшами; actual-tarball qualification остаётся отдельным gate. Полная FINAL-матрица и остальные независимые оси не закрываются этим отчётом. Порог size без запаса сохранён; будущие изменения требуют обычного cost gate.

Изоляция: авторский diff и первичные контракты прочитаны без рассуждений автора или чужих reviewer verdicts. Созданы только файлы этого review-каталога; исходники, evidence и чужие процессы сохранены. Изменений runtime и rollback-обязательства нет.

## Verdict: PASS

Относится только к указанному FINAL и структурной оси. Не означает завершение RESOURCE-01, production r11, merge, release или deploy.
