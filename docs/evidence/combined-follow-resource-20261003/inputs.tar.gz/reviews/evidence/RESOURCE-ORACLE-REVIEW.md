# Motion: Host oracle и сохранение RESOURCE proof

Вердикт: **PASS** для назначенной оси на
`7153f1031e824bdb9ad24110dd66d85fe5d5ec38`, дерево
`2027df6bd7d02e657b3e8185cd8296f6518d714a`.
Подтверждённых нерешённых findings в проверенном изменении нет.

База — `dbd42ee508bdb846a0f7ea029ff94455b14c83d3`; представление Host изменено
в `8fa0d20d6c3c86c979114f901f090f47917073a0`, контроль cancellation дополнен
в `7153f10`. Изменён только `test/fixtures/resource-package-probe.mjs`.
Продукт, test driver, CI, package и лимиты не изменены.

Fixture SHA256:
`1cbd6e0d2e89fd99a10b37292305c819b269bd24b700d9bde799d99e9467174f`.
Прочитан r11 из agents-config origin/main
`593906d0e59c89625121e7c3a9a9f7fb37cae65f`.

## Сохранение семантики и roots

**Да** — независимые relational-пробы старого и текущего Host дали одинаковый
наблюдаемый результат на используемых операциях: идентичность callback,
несколько заявок одного callback, next-frame scheduling, повторный вход в step,
исключение внутри кадра, detached requestFrame/setTimer/animate/cancel,
подставленный this, отмена старого timer, несколько независимых hosts,
1000-step bound и нормальный terminal drain.

Методы, передаваемые продукту отдельно, остаются привязанными к своему host.
Prototype-вариант меняет отражение формы объекта и идентичность методов step
между экземплярами; эти свойства продукт и fixture не используют. Такое
изменение не является эквивалентностью произвольных JavaScript-объектов.

**Да** — короткие GC-пробы обоих представлений при сохранённых host roots:
pending frame/timer/effect удерживает callback/target; после обработки или
отмены объект освобождается. Сохранённый timer off не удерживает снятый callback;
живой соседний host не удерживает чужую очередь.

`runCase` по-прежнему возвращает `[host, ...owners]` (строки 386–388), а retention
сохраняет эти массивы в `terminalOwners` и глобальном root. Удаляются только
опустевшие приватные контейнеры. Общий prototype не содержит component state;
сильные очереди, timer callbacks, native effects и package owners не заменены
WeakRef и не исключены из проверки.

Изменение снижает стоимость самого observer. Оно не доказывает ускорение
продукта или причинность всего прежнего timeout. Detached seams должны сохранять
привязку к экземпляру при дальнейших правках класса.

## Controls и измерение

**Да** — побайтная проверка вне Host-блока для `dbd42ee..8fa0d20` и девяти
аддитивных строк для `8fa0d20..7153f10` подтверждает сохранение:
- 38 ESM/CJS cells × 10 000 циклов; исходных сценариев и component roots;
- live/dropped/deliberate, unsubscribe, Promise и 36 inherited controls;
- всех GC rounds, частоты промежуточного GC и 90 000 ms дочернего timeout;
- capacities 2/256, 1000-step guard, 256 KiB максимальной A/A-полосы,
  8 KiB readout allowance, 4× различимости и пяти checkpoint-измерений.

Bytes lane по-прежнему измеряет возвращение heap после dropped owners;
сохранённые terminal shells проверяются отдельным retention lane. Новое
представление observer участвует и в A/A, и в candidate batches. Правило
вычисления baseline, отказ при неразрешимой полосе и условия PASS не изменены.
Этот Node host не измеряет native/GPU bytes; исходная граница сохранена.

## Исправленная потеря exact-once oracle

Замечание подтверждено и закрыто. Старый activeEffects=0 не различал два вызова
cancel одного effect. На прежней fixture инъекция двойного cancel проходила;
на текущей даёт RED `2 !== 1` в followEffectRoot. Это дефект чувствительности
oracle, а не наблюдение двойного cancel в runtime.

Теперь счётчик увеличивается на каждом вызове cancel. Проверка вне host cleanup
не может быть поглощена catch продукта. Пустой набор effects означает хотя бы
одну отмену каждого созданного effect; равенство cancelled/created тогда
доказывает ровно одну. Условие проверяется до и после stale-frame drain.
Follow reference controls также проверяют 1 create / 0 premature cancel,
точную отмену на pickup и отсутствие повторной отмены на destroy.

**Да** — независимый targeted probe различил двойной cancel и повтор из stale
кадра, сохранил независимость соседнего host и пропустил нормальные несколько
effects и повторный terminalDrain. Тем самым требование прежнего #461 восстановлено.

## Первичные результаты и точная привязка

Архив `run-NJkert/package.tgz` имеет SHA256
`4773db1b460231a212b317fdb18abd136dd5887c8dda09adeb67407e07cc9636`.
Manifest совпал с Git; 14 runtime-хешей совпали с tuple. Весь сохранённый
установленный healthy package побайтно совпал с архивом.

Исторический полный прогон на **8fa0d20**: witness, lifecycle, retention и bytes
прошли. У трёх полных lanes по 38 × 10 000 executions; retained references — 0,
live — 38, dropped — 0, deliberate — 1. Bytes band — 172 008 B при потолке
262 144 B; все пять excess равны 0. Retention завершился за 76 389 ms по raw
Vitest log. Первый прогон на dbd42ee сохранил ETIMEDOUT на прежних 90 s;
последующий успех не стирает этот отказ.

**Да** — независимый witness на точной fixture **7153f10** и проверенных
healthy package bytes: exit 0, 38 cells, все reference controls прошли.

**Нет, ожидаемый RED** — та же точная fixture на мутанте без super.destroy():
exit 1, followEffectRoot наблюдает activeEffects `1 !== 0`. Сохранённый installed
mutant отличается от healthy package только двумя ESM/CJS follow-файлами;
в обоих байтовая разница — ровно удалённый вызов `super.destroy()`.
Проверка повторена независимо без build/install. SHA архива мутанта
`1b5118a0…` прочитан из квитанции; сам этот архив не найден и его хеш повторно
не проверялся. Для RED проверены фактически исполненные installed bytes.

**Не было** — независимого полного RESOURCE-прогона на 7153f10, full suite,
browser, build или install. Исторический полный GREEN 8fa0d20 не выдан за
результат полного прогона 7153f10. Это PASS fidelity/oracle, не закрытие
RESOURCE/JOURNEY/REVIEW r11 или допуск merge/deploy.

## Артефакты и изоляция

`current-conservation.json` содержит exact identity и проверенные свойства;
`host-relational-current.json`, `exact-once-probe.json`, `current-witness-runs.json`
и соответствующие scripts/logs содержат независимые observations.
`evidence-check.json` сохраняет проверку исторического полного 8fa0d20 run;
`mutant-binding.json` — точную привязку повреждённых runtime bytes.
Все записи сделаны только в отдельной review-директории. Checkout чист;
временные witness consumer-каталоги удалены, чужие исходники не менялись.
