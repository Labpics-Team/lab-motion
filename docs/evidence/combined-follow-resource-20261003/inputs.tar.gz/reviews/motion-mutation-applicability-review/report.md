# Применимость широкого mutation-гейта

Вердикт: **APPLY** — для полного candidate `78e7ab200f473667d8863ff028c17c2e0d7debbc`, tree `41bf2ed317ac4c3f98c08c12ea85f20c651f5238`, действует условное требование `pnpm mutation` из CONTRIBUTING. Основание — изменение поведения вычислительного владельца MotionValue, а не совпадение имени файла с scheduled scope. Этот вывод не утверждает прохождение или отсутствие уже выполненного mutation-прогона.

Базы проверены отдельно: live main `957ceaf26501525eff476cdc1d149d81fd5ebcd7`, tree `469c15fb84354603032b0c789b2ee300f9d126e1`; parent #460 `939e7f4a7ebef2dd494f9dec8690932fecebfd73`, tree `deba4db1952029bdb7d2244b207f570007700b19`. Обе ревизии — предки candidate. GitHub GET подтвердил указанный live main во время ревью. Source checkout оставался чистым.

## Норма и разные точки её исполнения

- `CONTRIBUTING.md:93–105` перечисляет обычные обязательные проверки. Строки 107–111 отдельно требуют: «Для изменений численного ядра дополнительно: pnpm mutation». Строки 113–114 делегируют cadence и break-порог **планового** прогона workflow/config. Они не отменяют предыдущее условное требование для конкретного изменения. PR template:47 повторяет условие «для затронутого критического численного ядра».
- `stryker.config.mjs:2–16` описывает широкий scheduled baseline, включающий stateful MotionValue, frame requester и schedule, а не исключительно формулы solver. Строка 34 задаёт точный mutate scope; строки 39–40 — timeoutMS=30000 и break=76. `package.json` связывает `pnpm mutation` с `stryker run`.
- `.github/workflows/mutation.yml:3–6` запускается только по schedule/workflow_dispatch; core job:20–53 исполняет `pnpm mutation`, с 120-минутным ceiling. Автоматического broad per-PR job здесь нет. Нельзя выводить из этого файла требование нового полного прогона перед каждым произвольным draft.
- `.github/workflows/ci.yml:3–8` запускается на PR и merge_group. Его `mutation` job:204–234 исполняет **driver-only** `pnpm exec stryker run stryker.driver.config.mjs`. Конфиг driver:13 мутирует src/driver.ts, break=80; это самостоятельный существующий gate. Агрегатор `CI` (:280–302) требует success от verify, tests, mutation, node-floor и browser-static. Изменение driver-файла не является условием запуска этого job.
- Live GitHub rules `/repos/Labpics-Team/lab-motion/rules/branches/main` требуют context `CI` со strict policy. Broad core не указан отдельным required status. Rules также требуют PR и linear history; отсутствие требуемых approvals в API не отменяет пользовательскую норму независимого ревью и разрешённых действий.

До **draft push** пользовательский AGENTS требует «Перед push — локальные эквиваленты обязательных checks». Для данного семантического diff условный broad check из CONTRIBUTING применим вместе с обычными проверками и driver gate; draft-исключение этими источниками не задано. Это обязанность локальной подготовки, не утверждение, что GitHub технически блокирует feature-branch push до CI.

До **merge** остаются exact-candidate обязательные remote checks с зелёным агрегатором CI, требуемое независимое review и закрытие applicable broad evidence; зелёный driver-only job не является результатом broad core. В данной задаче merge/release/deploy не авторизованы. Ревью применимости не создаёт такого разрешения и не меняет workflow/ruleset.

## Почему это изменение ядра по смыслу

В 78e `src/motion-value.ts:370–405` привязывает доставку host callback к объекту запуска, потребляет callback один раз и проверяет живой run после внешнего scheduler-вызова. В :408–429 `_tick` допускает вычисление для текущего run, продвигает elapsed и frameCount, вызывает solveSpring и затем повторно проверяет владельца после потенциального getter reentry. У parent #460 :404–410 вместо этого стоит общий `_tickActive`, блокирующий любой вложенный tick, в том числе tick уже нового запуска. Это не просто освобождение ссылок: меняется, какой sample и когда может быть вычислен и опубликован.

**Различающая история без изменения формул:** текущий tick вызывает getter spring.mass либо listener; callback выполняет stop(), setTarget(2) и один раз доставляет уже поставленный callback преемника после возврата его requestFrame. В parent общий `_tickActive` остаётся true и теряет этот единственный callback; новый run в candidate допускает successor solve. Старый run после getter больше не вправе публиковать вычисление. Это затрагивает value/velocity, elapsed, продолжение и сходимость stateful численного owner. История точно представлена в `test/motion-value-reentrant-start.test.ts:38–98`; особенно :48–55 и :76–91. В ревью проведена статическая трассировка, тест заново не запускался.

Второй различитель — повторная доставка одной host-заявки без timestamp. Candidate :382–385 её отвергает; прежний callback мог второй раз продвинуть FIXED_DT, frameCount и value/velocity. `test/motion-value-frame-delivery.test.ts:4–25` отдельно проверяет неподвижный snapshot после повторной доставки. Этот случай не нужен для вывода сам по себе: первая история использует одноразовый callback преемника и уже достаточна.

Широкий mutation owner явно охватывает stateful MotionValue, в комментариях конфигурации отдельно обсуждаются generation mutations. Поэтому сохранение арифметической формулы не делает изменённые правила исполнения ядра автоматически вне условия CONTRIBUTING.

## Что не служит основанием и что осталось неизменным

- `src/projection/geometry.ts` меняет только добавление `@internal` в комментарий к createProjector. Этот diff сам по себе **NOT_APPLY** для условия изменения численного ядра, несмотря на присутствие geometry.ts в mutate scope.
- Выражение `Math.abs(targetRange) <= EPSILON` → `!(Math.abs(targetRange) > EPSILON)` относительно parent не доказывает смены допустимой физики: NaN не принадлежит этому пути после finite входных/публикуемых значений; разность конечных значений может стать ±Infinity, где выражения также совпадают. В live main уже стоит итоговая форма. На этой строке вывод APPLY не основан.
- `src/internal/solver.ts`, src/spring.ts, constants.ts, sliding-window.ts, schedule-v1.ts и repeat-cursor.ts побайтно совпадают на main/parent/candidate. Точность, threshold и формулы solver данным diff не переопределяются. CONTRIBUTING и оба Stryker-конфига, mutation workflow, Vitest Stryker-конфиги также совпадают на трёх anchors.
- Новые follow/velocity-tracker реализуют перенос/оценку входной скорости; broad config не мутирует эти новые файлы напрямую. Broad PASS не должен выдавать ложное утверждение об их прямом mutation coverage. Их функциональные/дифференциальные/контрпримерные проверки и независимое ревью остаются отдельными доказательствами. Scope здесь не расширяется.

## Условие пересмотра

NOT_APPLY было бы обосновано для другого immutable diff, который оставляет только comments/types/retention без изменения выбора, времени, входов или публикации numerical samples; конкретный пример — рассмотренный geometry-comment отдельно. Также вывод изменит применимая явная норма владельца, уточняющая исключение или lifecycle данного условного gate. Только слова «scheduled», неизменные solver formulas, driver-only PASS либо разрешение draft PR сами по себе не отменяют действующее условие для данного core diff.

## Evidence и пределы

Проверки **Да**: pinned source/diff и hashes на трёх anchors, семантическая трассировка, чтение CONTRIBUTING/config/workflow/регрессионных fixtures; live read-only GitHub branch/rules. Проверки **Не было**: tests, builds, installs, mutation run, bench/profile и runtime readback. Отчёт не заявляет RED/GREEN нового запуска и не сертифицирует полную корректность реализации.

Другие reviewer verdicts и авторские обсуждения не читались. Изменены только report/readset/verdict/hash внутри этого каталога. Сохранены существующие обычные проверки, driver mutation и remote CI; новый workflow, lowering thresholds или изменение test corpus не предлагаются.
