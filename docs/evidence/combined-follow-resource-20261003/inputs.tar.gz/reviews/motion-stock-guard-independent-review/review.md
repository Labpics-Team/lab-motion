# PASS — every-call stock guard и история producer

Anchor: `78e7ab200f473667d8863ff028c17c2e0d7debbc`, tree `41bf2ed317ac4c3f98c08c12ea85f20c651f5238`, base `4f6bee1c1aff41475c0ea9cfabfb1ddb607f6754`.

Область: только сохранение проверок входа на каждом вызове и полного исполнения зарегистрированного stock C corpus. Независимая проверка выполнена на чистом detached worktree; reasoning автора и другие verdict не использовались. Source, producer, thresholds, timeout, число повторений и corpus не меняются: diff затрагивает только `test/server-profile-contract.test.ts`.

Подтверждённых findings в этой области нет.

## Основание

- `same` (строки 419–421) использует тот же `Object.is`, что pinned Vitest 4.1.11 `toBe`. Проверки initial, own clamp и target вызываются каждый раз без кеша, sampling или branch по индексу. `-0` продолжает отвергаться.
- Для spring (строки 433–434) несовпадение быстрого пути передаётся прежнему `toEqual`; разрешённый extra undefined и другой prototype остаются допустимыми. Registered `scene.spring` — рекурсивно замороженный plain record (`bench/profile/server-profile-registration.mjs:6–14,36–37`), передаваемый producer без преобразования (`scripts/bench-support.mjs:29`).
- Clamp исходно проверялся через `Object.hasOwn`, а не `toHaveProperty`: own `clamp: undefined` запрещён, унаследованный clamp этим контрактом не запрещался. Операнд проверки и Object.is-семантика сохранены.
- Успех сохраняет 2 × 2000 warmup-вызовов и 8 × 4000 timed-вызовов: всего 36 000 constructor/setTarget/destroy. В каждом результате 47 кадров и конечное значение 100; denominator 2000 сохранён. Поздний отказ destroy на индексе 4002 сохраняет две warmup-последовательности, 2 полностью завершённых вызова, unfinished index 2 и только before CPU endpoint.
- Все 23 SHA-256 из immutable manifest совпали. Manifest SHA-256: `de7d726932e56869e0a539b261f6a9bef3c1fe65133387a7d6be97fbc31ffa65`. Все 6 mutant/neighbor commits — прямые потомки candidate, patches byte-for-byte совпадают с соответствующими Git diff.
- Raw Vitest results: targeted positive — 1 PASS; late initial -0, stiffness 171, own clamp undefined, target 99 на constructor index 30003 — каждый 1 предметный FAIL в соответствующем guard; extra undefined и prototype — каждый 1 PASS. В каждом запуске 203 теста не выбирались; это не полный suite.

## Пределы

Это PASS для зарегистрированного producer и неизменённого corpus, не универсальная эквивалентность `isDeepStrictEqual` и `toEqual`. Один короткий независимый differential probe pinned matcher на Node v22.23.2 подтвердил стандартные пары, но показал вне текущей достижимой области: spring с non-enumerable `asymmetricMatch: () => false` имеет old=false/new=true. В exact fixture такого значения нет: frozen plain record и неизменённый producer. При добавлении accessor, asymmetric matcher, custom equality tester либо другого происхождения spring этот review инвалидируется и быстрый путь нужно пересмотреть. Гипотеза об accessor wrong-then-right в использованной паре не дала расхождения; она не объявлена finding.

Тяжёлые тесты, полный suite, performance, browser, remote CI, merge/deploy и runtime не выполнялись и этим verdict не закрываются. Единственный независимый исполняемый probe — прямой Node differential без runner/install; исходный candidate не изменялся. Профиль CPU и baseline timing хешировались, но не использовались как evidence производительности в этой оси.

## Артефакты

- `integrity-readback.json`: exact anchor, clean source state и 23 digest comparisons.
- `candidate.diff`: точный рассматриваемый diff.
- `receipt-git-readback.json`: родительские commits и byte comparisons.
- `producer-history-readback.json`: 14 проверок raw positive/failure history.
- `differential.mjs`, `differential-result.json`: воспроизводимый bounded matcher probe и исходный результат.

Изоляция: `/home/labpics-ops/work/colors-motion-goal-20261002/motion-stock-guard-independent-review/artifact`. Worktree чист и оставлен для воспроизводимости. Внешних публикаций, source edits, installs или оставленных тестовых процессов нет.
