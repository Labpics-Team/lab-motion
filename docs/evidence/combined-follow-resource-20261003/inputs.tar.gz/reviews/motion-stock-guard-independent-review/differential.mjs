import {isDeepStrictEqual} from 'node:util';
import {equals, iterableEquality} from 'file:///home/labpics-ops/work/motion-follow-resource-integration-20261002/source/node_modules/.pnpm/%40vitest%2Bexpect%404.1.11/node_modules/%40vitest/expect/dist/index.js';
const expected = {mass:1,stiffness:170,damping:26};
const cases = {
 plain: () => ({...expected}),
 wrong: () => ({...expected,stiffness:171}),
 extraUndefined: () => ({...expected,unused:undefined}),
 prototype: () => Object.assign(Object.create({fixturePrototype:true}),expected),
 nonenumerableAsymmetricFalse: () => Object.defineProperty({...expected},'asymmetricMatch',{value:()=>false}),
 accessorWrongThenRight: () => { let n=0; return {mass:1,get stiffness(){return n++===0 ? 171 : 170;},damping:26}; }
};
const rows = Object.entries(cases).map(([name,make]) => {
 const baseline = equals(make(),expected,[iterableEquality]);
 const actual = make(); const strict = isDeepStrictEqual(actual,expected);
 const candidate = strict || equals(actual,expected,[iterableEquality]);
 return {name,baseline,strict,candidate,equivalent:baseline===candidate};
});
console.log(JSON.stringify({node:process.version,rows},null,2));
