# Независимое ревью тестового контракта Motion

**PASS** — подтверждённых нарушений на оси сохранения контракта и доказательной силы двух тестовых правок не найдено.

- Кандидат: `389faa294cdcf7e628901bd39827e30ed9850847`.
- Дерево: `6f933f86c518f3b282d586ccf5bd77a084413774`.
- Сравнение: `76b90e6210904224bd867df032096531fb736222..389faa294cdcf7e628901bd39827e30ed9850847`.
- Diff: только `test/profile-measurement.test.ts` и `test/benchmark-report-contract.test.ts`; 8 добавленных и 7 удалённых строк.
- План: agents-config `a3b751b151124d4bb05b4b0ac2dbf9270843f2da:plans/lab-motion-production/r11.md`.
- Readset: `readset-manifest.json`, SHA-256 `79dfdad67f31c0f1281820801428184105e6ae57c07374589b4a951849891d18`.

## Норма и предмет

Исходное намерение: выполнить r11 с сохранением прежних numerical/resource/budget limits, полного workload и обязательных checks; не переписывать historical preregistration, не увеличивать timeout и не уменьшать fixtures. Применимые нормы: r11 M-01 (строка 124), INV-05 (207–209), PROFILE-01 (339–351), G-PERF (435–457). Новая optional стоимость допустима при сохранении прежнего protected envelope.

Ревью проведено по Git-объектам и исходным логам, без рассуждений автора и чужих вердиктов. Навыки qa и verify прочитаны из файлов, поскольку отдельный Skill tool в доступной поверхности отсутствует. Проверены exact source identity и чистое рабочее дерево на момент readset (2026-10-02T16:16:50Z).

## PROFILE

`PROFILE_01.oldCostVectorGzipBytes` — исторический вектор, связанный с product base `7d3ed42e5b054a06e4f6ca7f0c2efc02484e20fd` и size-gate blob `4b0f181212b65a881e750e84564778f5828448a3` (preregistration:19–80). Он содержит 15 bespoke и 15 scenario ключей. Все прежние ключи и точные значения остаются обязательными: actual gate проверяется через `toMatchObject(registered...)` (test:124–127), ещё 11 скалярных `toBe` не изменены (128–138).

Preregistration, исполняемый size-gate, benchmark validator/methodology, config, package, lockfile и CI workflow побайтно совпадают с comparison base; Git blob identities сохранены в `readset/identity-comparison.json`. У preregistration сохраняются неизменные рекурсивные проверки потери, подмены и лишних полей (test:141–184).

Исторический size-gate отличается от текущего только добавлением optional follow constant, bespoke entry и consumer scenario. Новый потолок 7474 B относится только к `./compositor/follow` и `compositor-follow capability` (size-gate:142–144,202,377–381). Он не меняет прежние entries, consumer code или потолки. Канонический size-gate по-прежнему измеряет все scenario, учитывает initial/total и завершает работу с ошибкой при превышении (935–966). Поэтому запрет дополнительных ключей в историческом equality был ложным ограничением расширения, а inclusion сохраняет требуемый старый контракт.

## Benchmark

Два прежних вызова `fixture()` и `fixture(40)` заменены на `it.each([20, 40])` с тем же полным `validateBenchmarkReportPair(fixture(startRuns))` (test:825–827). Тело fixture и validator не изменены.

Каждый вход сохраняет 4 start participants, 8 freeze participants, все warm/cold сценарии, semantic/timer evidence, 8 freeze runs на participant, round-robin orders и 200 bootstrap iterations (fixture:40–47,107–209,212–352). Validator продолжает проверять полноту участников и числа run-clusters, schema, samples, semantic evidence, freeze и пересчитанные claims (report-contract:489–566,943–998).

Персональный timeout не задан ни в test, ни в config. У установленного Vitest 4.1.11 Node default равен 5000 ms (`coverage.DM_a_rWm.js:538`). CLI targeted receipt также не содержит override. Оба независимых входа теперь получают этот же default отдельно; общий elapsed двух задач закономерно может превышать 5 s. Это не доказательство ускорения fixture или performance admission; полный workload сохранён.

## Различающие свидетельства

Из `profile-benchmark-scope-targeted.json/.log`: точный кандидат, exit 0; PROFILE проходит; 20-run case — 1986 ms, 40-run case — 3922 ms. Все три выбранных теста прошли. 138 остальных тестов отфильтрованы `-t`; это не свидетельство полного suite и не новая skip-декларация в исходнике.

| Контроль | Наблюдение |
|---|---|
| Текущий gate со старым baseline и новым follow | PROFILE PASS |
| `./compositor`: 6450 → 6451 | AssertionError, test:124 |
| Удалена строка старого `./compositor` | AssertionError, test:124 |
| Старый scenario cap: 6600 → 6601 | AssertionError, test:127 |
| Старое имя scenario заменено на `removed-baseline-scenario` | AssertionError отсутствующего старого ключа, test:127 |

Все четыре RED — предметные mismatch failures, не syntax/import/timeout errors. Каждый мутированный gate восстановлен независимо из candidate bytes в памяти; SHA-256 совпал с существующим receipt. Точные преобразования и сравнения сохранены в `readset/mutation-reconstruction.json`, исходные patches/logs — в `readset/evidence/`. Дополнительных прогонов не было.

## Пределы

- **Да:** независимое чтение diff/нормативных владельцев; сверка identity; анализ полноты fixtures; проверка raw positive/negative evidence и byte reconstruction всех четырёх mutations.
- **Не было:** новых тестов, сборок, измерений, LSP diagnostics, remote CI, анализа всего runtime diff, delivery/deploy/readback.
- Source checkout и frozen evidence не менялись. Записаны только этот отчёт и собственный readset.
- PASS относится только к двум тестовым правкам. Общая готовность интеграции и фактическое прохождение остальных checks остаются за соответствующими gates.
- Инвалидатор: изменение проверяемого diff, fixture/validator/config/lockfile, применимой нормы либо контрпример, показывающий потерю старого обязательства.
