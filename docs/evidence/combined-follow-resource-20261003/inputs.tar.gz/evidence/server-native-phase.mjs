import { writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
const root = '/home/labpics-ops/work/motion-follow-resource-integration-20261002/source';
const [revision, output] = process.argv.slice(2);
const ts = (await import(pathToFileURL(resolve(root, 'node_modules/typescript/lib/typescript.js')).href)).default;
const sha = value => createHash('sha256').update(value).digest('hex');
const source = execFileSync('git', ['show', revision + ':test/server-profile-contract.test.ts'], { cwd: root, encoding: 'utf8' });
const cutoff = source.indexOf('\ndescribe(');
if (cutoff < 0) throw new Error('fixture boundary missing');
let prefix = source.slice(0, cutoff).replace(/^import .* from 'vitest';\r?\n/m, '');
prefix = prefix.replace(/from '(\.\.\/[^']+)'/g, (_, value) => "from '" + pathToFileURL(resolve(root, 'test', value)).href + "'");
const split = prefix.indexOf('const hash');
let header = prefix.slice(0, split), body = prefix.slice(split);
const measuredImports = ['serverProfileDigest', 'serverCellPairs', 'compactServerCpuEvidence', 'serverArtifactDigest'];
for (const name of measuredImports) {
  if (!header.includes(name + ',')) throw new Error('named import absent: ' + name);
  header = header.replace(name + ',', name + ' as original_' + name + ',');
}
const measuredFunctions = ['stage', 'healthyAdmission', 'admissionEvents', 'chain', 'admissionHistory'];
for (const name of measuredFunctions) {
  const needle = 'function ' + name + '(';
  if (!body.includes(needle)) throw new Error('fixture function absent: ' + name);
  body = body.replace(needle, 'function original_' + name + '(');
}
const prelude = `const phases = new Map();
function observe(name, callback, args) {
  const begin = performance.now();
  try { return callback(...args); }
  finally { const row = phases.get(name) ?? { calls: 0, inclusiveMs: 0 }; row.calls++; row.inclusiveMs += performance.now() - begin; phases.set(name, row); }
}\n`;
const wrappers = [...measuredImports, ...measuredFunctions].map(name => 'function ' + name + '(...args) { return observe(' + JSON.stringify(name) + ', original_' + name + ', args); }').join('\n');
const compiled = ts.transpileModule(header + prelude + wrappers + '\n' + body + '\nexport { admissionHistory, phases };\n', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const inputs = {};
for (const file of ['bench/profile/server-profile-contract.mjs', 'bench/profile/server-profile-registration.mjs', 'bench/profile/server-profile-runner.mjs', 'bench/compare/methodology.mjs']) {
  const pinned = execFileSync('git', ['show', revision + ':' + file], { cwd: root });
  const current = readFileSync(resolve(root, file));
  if (!pinned.equals(current)) throw new Error('helper source drift: ' + file);
  inputs[file] = sha(current);
}
const fixture = await import('data:text/javascript;base64,' + Buffer.from(compiled).toString('base64'));
const { validateServerArtifact, validateServerJournal } = await import(pathToFileURL(resolve(root, 'bench/profile/server-profile-contract.mjs')).href);
const began = performance.now(), cpu = process.cpuUsage();
const history = fixture.admissionHistory();
const buildMs = performance.now() - began;
let phase = performance.now(); const artifactResult = validateServerArtifact(history.artifact); const validateArtifactMs = performance.now() - phase;
phase = performance.now(); const journalResult = validateServerJournal(history.artifact, history.records); const validateJournalMs = performance.now() - phase;
if (artifactResult.verdict !== 'PASS' || !journalResult.journalFinalDigest) throw new Error('native diagnostic failed full verification');
const report = { revision, scope: 'diagnostic only; same full fixture and two validators through native ESM; no Vitest deadline admission', node: process.version,
  fixtureSourceSha256: sha(source), fixturePrefixSha256: sha(source.slice(0, cutoff)), compiledPrefixSha256: sha(compiled), inputs,
  totalMs: performance.now() - began, cpuMicroseconds: process.cpuUsage(cpu), buildMs, validateArtifactMs, validateJournalMs,
  nestedInclusivePhases: Object.fromEntries(fixture.phases), runs: history.artifact.samplePlan.runs,
  stages: Object.fromEntries(['warmup', 'pilot', 'aa', 'positive', 'ab'].map(name => [name, { rows: history.artifact[name].rows.length, blocks: history.artifact[name].blocks.length }])),
  records: history.records.length, journalFinalDigest: journalResult.journalFinalDigest, artifactVerdict: artifactResult.verdict,
  processResourceUsage: process.resourceUsage() };
writeFileSync(output, JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report));
