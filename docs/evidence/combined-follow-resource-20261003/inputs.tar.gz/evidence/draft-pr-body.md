## Пользовательский результат

Интегрирует интерактивный compositor follow, возврат native/live и освобождение MotionValue/подписок из #460 и #461 в один проверяемый пакет. Исходные PR и их refs сохранены: `939e7f4a7ebef2dd494f9dec8690932fecebfd73` и `4341f80c7a20d3802f7528b13519db6e5586a462` входят в историю кандидата.

Draft-кандидат: `78e7ab200f473667d8863ff028c17c2e0d7debbc`, tree `41bf2ed317ac4c3f98c08c12ea85f20c651f5238`; база сравнения — `957ceaf26501525eff476cdc1d149d81fd5ebcd7`. Готовность к merge не заявляется.

## Контракт

- Native, live и follow сохраняют одного владельца исполнения, передачу value/velocity, отмену ровно один раз и защиту от stale callbacks и повторного входа.
- RESOURCE сохраняет 38 ESM/CJS cells, по 10 000 циклов, live/dropped/deliberate controls, GC rounds, caps и timeout 90 s.
- Исторические PROFILE budgets остаются обязательным подмножеством; новые optional entries не меняют старые caps.
- Stock-проверки сохраняются на каждом из 36 000 вызовов. Независимые benchmark cases получают прежний default 5 s каждый; полный workload сохранён.

## Доказательство

Локальные независимые ревью исходной композиции, RESOURCE oracle, runtime owner/lifecycle, архитектуры, PROFILE/benchmark guards, browser observation и stock guard дали PASS в своих точных областях. Перенос на финальный commit основан на Git-идентичности неизменённых входов; он не заменяет remote CI.

Actual tarball SHA256: `6e81f47096286fba47feb1d43f4a862bd28078a93f7aa3d4e5e18d8225d6438b`. Все 312 dist-файлов финального checkout совпадают с ним. Owner-hook mutant и late extra-native-effect mutant сохраняют предметный RED; stock late mutations проверяют -0, stiffness, own clamp и target.

## Архитектура

Отзыв live/input исполнения использует существующую commit-границу владельца. Публичный API, optional entry и приватные hooks сохраняют свои границы; новый scheduler/store не добавлен. Timer reservation/CAS и successor cleanup проверены отдельной семантической осью.

## Производительность

Canonical size прошёл для runtime-equivalent source: compositor-stagger — 6600 B gzip при прежнем cap 6600, запас 0 B. Это результат конкретных package/toolchain bytes. Физические performance, mobile и GPU/raster claims не делаются.

## Риски и не-цели

Полный локальный unit на точном кандидате: **5127 PASS / 10 FAIL**, 347 PASS / 4 FAIL files, skips/todo 0; elapsed 1164.349 s. Stock, PROFILE baseline, benchmark cases и dist freshness проходят.

Открытые отказы: healthy 70.964 s и partial 62.225 s при 30 s, пять зависимых проверок отказов; RESOURCE forced-GC 90.477 s при 90 s; animate-scope-package 5.631 s и reorder-package 5.461 s при 5 s. Предыдущий RESOURCE PASS не отменяет новый RED на тех же package/probe bytes. Причина изменения длительности не установлена; повторов ради GREEN и ослабления лимитов нет.

## Документация и выпуск

Действующие API, recipes и CHANGELOG входят в исходную интеграцию. Docs-drift на финальном source проходит. Merge, auto-merge, npm release и deploy не разрешены. Откат подготовки сохраняет исходные #460/#461 и затрагивает только отдельную candidate-ветку/PR.

## Гейты

| Проверка | Результат и область |
|---|---|
| Static: audit, typecheck, browser/motion-program types, native gate, cycles, error catalog | PASS на exact78e; 62.928 s |
| Native TS7 typecheck | PASS на exact78e; 5.717 s |
| Build, size, package smoke/compat, compiler acceptance | PASS по неизменным входам и подтверждённым bytes; не новый запуск на78e |
| Node consumer floor 22.0.0 / Node24 | PASS actual tarball6e81 |
| Finiteness fuzz, docs facts, issue forms, release contract, actionlint | PASS по неизменным входам; docs-drift также PASS на78e |
| Native clock на зарегистрированном Node24.19 | PASS API/ABI/refusal controls; physical timing samples 0 |
| Full unit и RESOURCE | RED; полный список выше |
| Chromium + Firefox | PASS 348/348, skipped/flaky 0, workers1/retries0 на4f6bee1; browser/runtime inputs до78e неизменны |
| WebKit | НЕ БЫЛО: локальный запуск недоступен из-за системных библиотек; требуется canonical CI |
| Driver mutation | PASS на78e, score83.72 при break80; 301 mutants, 249 killed,3 timeout,37 survivors,12 no coverage |
| Broad core mutation | RED на initial dry run: healthy PROFILE timeout30 s; generated2376 mutants/13 paths, campaign НЕ БЫЛО, score отсутствует |
| Exact-head remote CI и substantive CodeRabbit | НЕ БЫЛО; требуются после публикации draft |

Raw receipts, immutable diff, package tuple, review anchors и проверка переноса находятся в локальном portable packet; публичного carrier со ссылкой пока нет. GitHub-ссылки #460/#461 дают доступ к исходным PR, но не к этим локальным reports. Draft нужен для exact-head CI и содержательного review; открытые гейты остаются открытыми.
