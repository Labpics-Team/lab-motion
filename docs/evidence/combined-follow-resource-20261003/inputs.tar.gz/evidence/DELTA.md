# Интеграция Motion RESOURCE

Исходное намерение: сохранить принятые контракты #460 и #461, затем доказать terminal ownership нового compositor/follow существующим actual-package RESOURCE-стендом r11. Production merge, release и deploy запрещены.

Снимок подготовки: 9e61edeffc864f6710845ef242bc76e077a49701, tree 22bf576f69f0676be4885cae38803231a8629b14. Его родители — exact #460 939e7f4a7ebef2dd494f9dec8690932fecebfd73 и #461 4341f80c7a20d3802f7528b13519db6e5586a462. Это source snapshot, не утверждение о работоспособности или performance.

## Разрешение пересечений

| Путь | Сохранённое свойство и решение |
|---|---|
| src/motion-value.ts | Run-token, одноразовая доставка host callback, Map с отзывом прежней регистрации и terminal очистка spring/scheduler из #461. Signed-zero bounded orientation и malformed-scheduler validation #460 остаются в прежних тестах. Declaration-only поле timeout из #460 сохраняет отсутствие лишней инициализации. |
| src/compositor/core.ts | Сохранены handoffToCompositor, pending native time и отзыв live donor до host cleanup из #460; добавлены protected follow seams и очистка spring metadata #461. Общий _retargetFrom получает optional returning live owner, чтобы отказ lowering сохранял прежний live путь. Native commit отзывает input state и live donor до cancel внешнего host. |
| docs/recipes.md | Сохранены динамические sheet/pager recipes #460 и фиксированные при mount follow recipes #461; lifecycle, resize, focus и области применимости не подменяются друг другом. |
| browser/fixtures/compile-artifacts.mjs | Scope builder #460 остаётся владельцем reorder; дублирующий buildReorderRecipe не вызывается. Follow package builder #461 вызывается отдельно. Один общий tarball для обоих browser builders ещё предстоит связать. |
| test/resource-actual-package-retention.test.ts | Выбран существующий полный tarball/32 owner/10 000-cycle fixture #460. Узкие follow/spring/callback witnesses #461 пока не перенесены в этот промежуточный снимок; это обязательная следующая delta, а не закрытый ресурсный proof. |
| CHANGELOG.md | Обе пользовательские delta сохранены; название Set заменено наблюдаемой дедупликацией callback. |

## Граница способности

Потребители — документационные panel/carousel и Component adapters. Они задают координаты, выбранный snap/page, геометрию, focus и собственные listeners. Follow владеет текущим input состоянием и передаёт физику и native/live effects существующему CompositorSpring; MotionValue остаётся владельцем scheduler и подписок. Новый runtime, tier, store и numeric solver не добавляются. Vue scope/Svelte ownership из #461 сохраняются; профилировщик, native CPU clock, calibration, caps, thresholds и CI из #460 не меняются.

Проверка не связывает Lab UI/Icons с новым runtime. Совместимый physical contract достаточен; semantic feel остаётся у дизайн-системы. Адопция соседями и performance admission не входят в этот срез.

## Следующее доказательство

В существующий fixture добавляются ESM/CJS follow-native, follow-pickup и follow-live. Сохраняются все 32 прежних owner cells, 10 000 циклов, live/dropped/deliberate controls и неизменная A/A byte-band. Узкий witness должен обнаружить отсутствие super.destroy в InputSpring.destroy; корректный superclass consumer остаётся здоровым. Исходный first-fail сохраняется. Полный resource proof требует одного согласованного package tuple, отдельного forced-GC retention и actual browser ownership. Node heap не выдаётся за raster/GPU bytes.

Invalidators: изменение shared core, adapter lifetime, package exports/build/lock/toolchain, resource fixture либо нормативного terminal outcome. PROFILE-01 и его статистическая серия не закрываются этим функциональным доказательством.

Все исходные PR/worktrees сохранены. Откат подготовки — удалить только собственную непубликованную ветку после сохранения её evidence. На этом снимке проверки ещё не завершены.

## RESOURCE snapshot dbd42ee

Commit `dbd42ee508bdb846a0f7ea029ff94455b14c83d3`, tree `a242696eeb4e8fc8e42d172303addca46a3e30ef`. Два изменённых файла: `test/fixtures/resource-package-probe.mjs` и `test/resource-actual-package-retention.test.ts`. Сохранены 32 прежних cells и добавлены шесть ESM/CJS follow-native/pickup/live. Каждый lifecycle/retention/bytes cell проходит 10 000 циклов; 36 узких spring, late-callback и follow target/effect проверок перенесены в тот же actual-package witness. Второй harness не добавлялся.

Canonical build PASS; focused 11 файлов, 190 PASS. Первый полный RESOURCE run: witness PASS, lifecycle 38 × 10 000 PASS, bytes PASS; forced-GC retention завершился `ETIMEDOUT` на неизменных 90 секундах. Поэтому RESOURCE на этом snapshot не принят. Исходные логи и actual tarball сохранены в `source/scratchpad/resource-evidence/run-LMFNZu/`; archive SHA256 `4773db1b460231a212b317fdb18abd136dd5887c8dda09adeb67407e07cc9636`. A/A baseline 6 870 144–7 046 544 bytes, разрешение 184 592 bytes при прежнем максимуме 262 144; excess пяти батчей равен нулю. Эти данные не отменяют retention failure.

Целевой mutant `398a6774959bf53054f1594187e66863af2a7ca9` удаляет только `super.destroy()` из `InputSpring.destroy()`. Canonical build PASS; установленный mutant package даёт предметный RED: `followEffectRoot`, active native effect `1 !== 0` после destroy. Healthy package проходит тот же witness. Mutant изолирован и не интегрируется.

Диагностические подмножества того же package: original32 также превышает 90 секунд (10 000 циклов достигнуты за 69,96 секунды, heap 1,367 GB); follow6 проходит за 14,25 секунды. Перенос методов host double на общий prototype снижает heap полного корпуса до 1,009 GB, но 38 cells всё ещё не заканчивают финальные 16 GC в 90 секунд. Это сохранённые отрицательные результаты, не admission и не причина повышать timeout. Диагностические scripts, hashes, commands, timeouts, process CPU и /proc/stat лежат в `retention-diagnostic/`.

## Снижение стоимости observer: 8fa0d20

Commit `8fa0d20d6c3c86c979114f901f090f47917073a0`, tree `c5c0ba455e93c7d1c25e68531a3e59bbbe1c5413`. Изменён только существующий RESOURCE host double: методы и getters разделяются через prototype; скрытые queues/maps/sets существуют при наличии элементов. Все host identities и package owner roots остаются сохранёнными. Число cells, циклов, GC rounds, controls, максимальная A/A band и timeout не изменены.

Полный uninstrumented actual-package RESOURCE: 4 PASS; retention 76,389 сек, lifecycle 12,545 сек, bytes 31,148 сек. Raw tuple: `source/scratchpad/resource-evidence/run-NJkert/`. Archive SHA совпадает с первым failed run: `4773db1b460231a212b317fdb18abd136dd5887c8dda09adeb67407e07cc9636`. A/A band 172 008 bytes, maximum 262 144, excess всех пяти батчей нулевой; live/deliberate signals больше 1 MB. Конечный fixture сохраняет RED на прежнем actual-package missing-super.destroy mutant.

Браузерная композиция: 18 PASS в Chromium 153.0.8010.12 и Firefox 155.0, включая по 10 000 native/live/serialized циклов. Рецепты scope и follow использовали тот же archive SHA; оба manifest readback сохранены. WebKit 2359 не стартовал из-за отсутствующих системных библиотек; browser-тесты WebKit не выполнялись. Никакого нового sysroot и повышения caps не делалось.

Изолированный source-conservation review exact8fa — PASS, подтверждённых findings нет; полный ответ сохранён в `SOURCE-CONSERVATION-REVIEW.md`. Его область исключает fixture oracle и не закрывает review следующего изменения.

## Восстановление точного cancel control: 7153f10

Reviewer предъявил oracle counterexample: повторный cancel оставляет Set пустым, поэтому activeEffects=0 не сохраняет прежнюю проверку #461 cancelCalls=1. Исходные asserts #461 (compositor lines177–182; follow lines218–223) подтверждают требование. Runtime double-cancel этим finding не доказан.

Commit `7153f1031e824bdb9ad24110dd66d85fe5d5ec38`, tree `2027df6bd7d02e657b3e8185cd8296f6518d714a`: девять добавленных строк в том же fixture. Счётчик отмен сохраняет multiplicity; terminal/stale drain проверяет cancelled=created, follow settle/pickup/destroy проверяет точные 0/1.

Тот же actual package с целевым double-cancel host fault проходит старый8fa witness (сохранённый false GREEN), но новый7153 witness отвергает его по предметному `2 !== 1`. Healthy7153 witness проходит. Полные scripts, package/fixture hashes и outputs закреплены в `double-cancel-old-receipt.json` и `double-cancel-new-receipt.json`. Полный 4-mode прогон7153 и targeted oracle review на момент этой записи ещё выполняются. Product source/package/browser inputs относительно8fa не изменены.

## Завершённые локальные результаты7153

Полный actual-package RESOURCE7153: 4 PASS; retention 67,013 сек, lifecycle 13,603 сек, bytes 26,699 сек. Exact tuple/raw лежат в `source/scratchpad/resource-evidence/run-v9Arsd/`; `final-check-receipts.json` сохраняет command/head/tree/time/exit.

Package smoke и compat прошли на том же archive SHA. Первый smoke отклонил сохранённое имя `package.tgz`, требуя canonical `labpics-motion-0.3.0.tgz`; исходный отказ сохранён. Побайтно одинаковая копия под правильным именем прошла существующий release-artifact-check. Иные обходы не добавлялись. Static checks exact7153 прошли. Квитанции — `package-static-final-receipts.json`.

Изолированный RESOURCE fidelity/oracle review exact7153 — PASS, confirmed findings отсутствуют. Исходный report сохранён побайтно как `RESOURCE-ORACLE-REVIEW.md`, SHA256 `e6a9f61980edf9f15a234ad303e9af2ac61765e962584d5327856e11c19838c6`. Он охватывает relational host semantics, roots/GC, неизменность полосы/caps и targeted exact-once regression. Полный прогон автора не выдаётся за независимый повтор.

Candidate остаётся отдельной веткой; исходные #460/#461 не изменены. Новое поручение parent — завершить canonical local pre-push graph и отдельный draft PR с exact-head CI. Production merge/release/deploy не разрешены. Локальный отказ запуска WebKit остаётся открытой границей; завершение браузерной матрицы требуется через канонический CI path.


## Открытый size-гейт и отклонённые runtime-пробы

Canonical size7153 отказал: `compositor-stagger capability` 6625 B gzip при неизменном cap6600. Это общий consumer budget объединённых исходников. Изолированные собственные offline frozen installs и canonical build/size каждого исходного PR прошли: #460 exact939e — 6575 B, #461 exact4341 — 6597 B. Сжатые величины не аддитивны. Квитанции — `parent-size-isolated-receipts.json`; первые отказы pnpm при symlink node_modules сохранены отдельно и произошли до build. Были удалены только собственные symlinks, зависимости source не очищались.

Три отдельные runtime-пробы не приняты: inline timer transaction419 — 6624 B; immediate-startdf0 — 6621 B; shared numeric snapshot437 — 6627 B. Все сборки прошли, все size-гейты остались RED. Snapshot-проба прошла52 focused tests, включая семь новых public differential случаев с вложенным контроллером; идентичный suite прошёл до изменения runtime. Эти случаи и исходный diff сохранены в `snapshot-boundary-baseline.patch`/receipt; candidate command/readback — `snapshot-candidate-receipts.json`. Уменьшение per-controller allocation не выдано за достижение размерной цели.

Все три пробы отменены отдельными commits без переписывания истории. Текущий source `c0079a1f04414f5594db158e32f07f465ffa55ad`, tree `2027df6bd7d02e657b3e8185cd8296f6518d714a`, полностью совпадает с7153. Рабочий `source/dist` до следующей canonical сборки ещё принадлежит437; для RCA исходные bytes7153 извлечены из проверенного archive4773 в `size-reference-7153/package/dist`, их hashes сохранены в provenance.json. Из этого состояния draft PR ещё не публикуется: local size остаётся открытым обязательным гейтом.

## Functional native CPU clock qualification

Первый запуск на зарегистрированном Node24.19 отказал на отсутствии имени `cc` в PATH (`native-clock-final-receipt.json`), что не доказывало отсутствия compiler. Использован существующий GCC15.2.0 через собственный scratch symlink `tools/native-clock-cc/cc`. Realpath — `/home/labpics-ops/.local/toolchains/gcc15/usr/bin/x86_64-linux-gnu-gcc-15`, проверенный SHA256 `b5f1b773a7c733738352000c92a077dc5852a1a2fc6d836b1e411be1e9ec5f88`; source/compiler contract не менялся, installs и bootstrap не добавлялись.

Полный canonical fixture прошёл: actual native API/ABI, worker/stale/missing-compiler отказы, шесть killed mutants, настоящий SIGINT/SIGTERM. Raw JSON и квитанция — `native-clock-gcc-alias.log` и `native-clock-gcc-alias-receipt.json`. Фиксируются0 registered timing samples: эта проверка не свидетельствует физическую точность clock model и не закрывает PROFILE.


## Совместная проверка избыточной работы владельца

Owner mergef719 прошёл113 focused tests/build, но сохранил size6613>6600. Дополнительный replacement-argumenta68 также прошёл113 tests/build, size6614; эта форма не принята. Оба отменены отдельнымc95, чей полный tree равен7153. Диагностика удаления emitted class fields через существующий measureScenario также сохранила RED: исходный7153=6625, group-only=6622, group+cleaning=6620. Это emitted-byte counterfactual, не source build/admission; квитанции лежат в `field-emission-diagnostic/receipts.json`.

Самостоятельный RED каждого удаления не исключает их семантически обоснованную комбинацию: gzip неаддитивен. В6feea80 повторно собран merged owner hook вместе с declaration-only _plan/_springs/_cleaning. Численные состояния _run, _v0Norm и epoch не менялись. Group поля присваиваются до возврата конструктора; у own prototypes нет соответствующих setters. Cleaning читается только как truthiness-флаг, undefined/отсутствие равнозначны для этого внутреннего stripped поля. Canonical build и7 focused файлов прошли; size6607>6600 остался RED (`owner-fields-candidate-receipts.json`).

Следующий immutable5fb1bdf добавляет только удаление избыточной работы start: single-use timer wrapper не создаёт вторую create-closure, а непосредственный start использует уже проверенную _ensureFallback admission без повторного epoch guard. CAS, stale-return cleanup, timer callback и исключения сохраняют исходный порядок. Это согласованный кандидат сокращения owner setup/revocation; numeric normalization, shared scratch и replacement-argument в нём отсутствуют. Проверки на момент записи выполняются;5fb не принят и не опубликован.


## Зафиксированный итоговый кандидат76b90e6

Совместные5fb иa6 сохранили size6601>6600; shared-scratch7f увеличил его до6612. Эти отказы не округлены до PASS. Shared scratch и replacement-parameter отменены; выбран более простой5fb. В конструкторе группы массив теперь закрепляется за _springs в месте создания, вместо отдельного позднего присваивания локальной ссылки. Constructor не передаёт this наружу и не имеет соответствующего prototype setter; частично построенный объект не становится доступен callbacks.

Кандидат0a0149 прошёл canonical build,145 tests в7 targeted файлах и ПОЛНЫЙ canonical size. `compositor-stagger capability` — ровно6600 B gzip при прежнем cap6600, запас0 B. Это admission конкретных bytes; изменение source/toolchain/dependencies требует новой проверки. Другие caps не изменены и также прошли.

Итоговая ветка `codex/motion-follow-resource-qualified-20261002` создана от exact merge9e61. Один атомарный commit `76b90e6210904224bd867df032096531fb736222`, tree `c89e0cf3da87470a13df7d9b5a732085d3377601`, побайтно равен0a0149. Исходная ветка сохраняет всю историю отрицательных экспериментов. Никаких source edits после freeze не сделано. Runtime diff относительно7153 меняет только core/follow/stagger; RESOURCE fixture byte-identical7153, его oracle review сохраняет область применимости, новый package proof ещё требуется.

На exact final SHA запущен весь local pre-push graph. `qualified-prepush-receipts.json` содержит реальные результаты по мере завершения. Full pnpm test использует --maxWorkers=1 без file filtering, сохраняя фиксированный90s RESOURCE envelope при исключении межфайловой CPU конкуренции; fuzz запускается отдельно. Runtime review и second-order review запрошены через root изолированно. Draft PR/remote CI ещё не созданы; merge/release/deploy не разрешены.


## Квалификация после полного прогона 76b90e6

Полный suite: 5125 PASS / 11 FAIL, 347 PASS files / 4 FAIL. Исходный журнал `qualified-full-tests.log` сохранён. RESOURCE 38 × 10 000 PASS на tarball `6e81f47096286fba47feb1d43f4a862bd28078a93f7aa3d4e5e18d8225d6438b`; retention 75.821 s при прежних 90 s.

Первичные отказы server-profile — три timeout (stock 5 s, healthy и partial 30 s); пять dependent refusals следуют healthy prerequisite. Stock и healthy повторены на exact #460: оба RED при прежних бюджетах. CPU profile локализует busy work в fixture/carrier/hash/validation, не в Motion runtime. Полный healthy admission остаётся незакрытым.

Ошибка orchestration: после переключения ветки не был повторён build; tree equality не сохраняет mtime. Canonical rebuild и freshness выполняются отдельно.

Исторический PROFILE baseline сохранён. `a9126ba` исправляет область assertion: все прежние keys/caps обязательны, новые opt-in клетки допустимы. Четыре sabotage (изменение/удаление bespoke/scenario) дают RED. `389faa2` разделяет независимые report20/report40; 1.986 s и 3.922 s при прежних 5 s, bootstrap200 и оба полных reports сохранены. Runtime source после76b не менялся.

Эти результаты не закрывают full suite, exact-head CI, независимое review новых test-only commits, draft PR или browser WebKit. Merge/release/deploy не выполняются.

## Native Chromium observation и новый current4f6bee1

Полный Chromium389 дал173 PASS и один RESOURCE timeout90s. Позднее завершение всех10 000 циклов не принято за PASS. Отдельный parent7153 на том же host прошёл; повтор current389 остался RED. Возврат emitted _cleaning в изолированном0725ef тоже сохранил RED95.151s и увеличил размер до6602>6600. Эта runtime-форма не принята.

После SSH502 штатный Remote Desktop Commander подтвердил тот же sandbox: Linux, labpics-ops, Tailscale100.126.208.45, exact checkout и пакет. Команды не перенесены на Windows или другой Computer. CDP observer1636227 не менял тело RESOURCE-теста. Из94.393s интервала TaskDuration94.031s и ThreadTime93.456s; RecalcStyle27.665s при50 139 recalculations. В sampling profile два native getAnimations sites занимают81.058s self; layout0.003s и idle0.378s не доминируют. Это profiler evidence, отдельно от uninstrumented приёмки.

Минимальный test-only4f6bee1 возвращает фактически измеренный count из helper и использует его как maximum count retarget commit. Повторный query после native pause/currentTime удалён; сами setters и проверки после live handoff, terminal drain и host turns сохранены. Chromium PASS79.426s при прежних90s:10 000 циклов,30 000 native effects,20 host turns,20 000 сохранённых terminal owners, terminal animations/jobs0. Поздний настоящий extra native effect на retarget цикла5 001 дал RED45.416s по single-native-effect assertion. Исходные failures, CDP profile, положительный результат и mutant закреплены в native-observation-review-manifest.json.

Scope builder штатно делает npm pack. Наблюдаемый a30fa4f8d0e3a011caa181b82931f99653c9887a3646353aa700870cfa0beced отличается от ранее квалифицированного6e81 только modes восьми non-dist members:0644→0600 при новом DCR checkout. Все320 member bytes одинаковы; scope bundle у обоих086435816dcd0c31036744eb115e3850c2bea8bd5224735212cb8bebb9c197f2. CDP observer использовал6e81. Это явная payload equivalence, не равенство tar bytes. Полный record — native-observation-package-equivalence.json.

Изолированный QA4f6bee1/tree3be0e7bcabf72318a6ea7a785913af4d0999b672 — PASS, findings0. Report resource-defect-preservation.json, SHA256c9b0a1267f316f4553a6c5abbd1326f2446e58f9705193618a378bcfb1c6fc14, хранится в parent evidence. После этого интеграционная ветка переведена fast-forward на4f6bee1. Runtime после76b не менялся; полная affected Chromium/Firefox matrix ещё открыта.

## Server expectation experiment остаётся RED

Новый comparable baseline389 без V8 profiler: stock7.089s при5s и healthy69.320s при30s, оба RED. Весь command85.510s, child user91.937s и sys6.865s. Child CPU не мал относительно wall; общая идеальная изоляция из этого не выводится.

Изолированный d10b98d меняет только подготовку expected pairs: два противоположных synthetic runs дают fresh vectors полной длины. Full raw stages, orders, validators, оба hash passes и timers не меняются. Тот же command: healthy59.710s, stock6.404s, оба RED; whole74.242s, child user77.321s и sys5.803s. Наблюдаемое уменьшение healthy9.610s не закрывает30s. Кандидат не интегрирован; exact artifact/journal parity, late-run controls и review остаются открыты. Последующий timed run ждёт освобождения общей CPU полосы после parent Colors matrix.


## Полная браузерная матрица и stock guard

Exact4f6bee1: Chromium/Firefox348 из348 PASS; skipped0, unexpected0, flaky0, workers1, retries0. Полный wrapper завершился exit0 за833.395s, userCPU712.807s/sys131.439s. RESOURCE10 000 циклов: Chromium85.393s, Firefox13.659s при прежнем90s. Raw JSON, receipt и оба package manifests сохранены как qualified-browser-matrix-4f6bee1-*.

После завершения матрицы clean интеграционная ветка fast-forward на78e7ab200f473667d8863ff028c17c2e0d7debbc, tree41bf2ed317ac4c3f98c08c12ea85f20c651f5238. Изменён только stock test: every-call primitive equality проверяется через Object.is, spring через isDeepStrictEqual, а исходные Vitest assertions оформляют обнаруженное несовпадение. Все36 000 constructors, warmups/repetitions/frames/endpoints и5s timer сохранены. Baseline7.089s RED; кандидат0.705s PASS. Четыре поздних нарушения наconstructor30003 дали assertion RED; два разрешённых spring-соседа PASS.

Изолированный stock QA: PASS, SHA256bd8830af181fe800d9736834c56c7126053b37a40766c73954d3962bdff590d0. Область — замороженный plain registered spring; произвольный asymmetricMatch недостижим и общей эквивалентности equality не заявлено. Browser/runtime inputs в4f6bee1..78e7ab2 неизменны. Тяжёлая полоса передана parent для Colors; full Vitest, healthy/partial30s, mutation, WebKit/remote CI и PR/review остаются открыты.


## Подготовлен source-only construction experiment

9a5b76442cae79bb463ae982f9a525fb436d724b (parentd10, tree929c6369174a60100d1290142790cdec200f1d5b) использует компактный первый synthetic run как шаблон и создаёт независимые structuredClone всех следующих полных samples. Полные N/raw/repetitions/orders/blocks сохраняются; verifier и hash passes не меняются. Branch изолирован, tests не запускались, интеграции нет. Подготовлены bounded4-run byte/ownership witness и full native JSON parity с late encoded CPU tuple/PID, clock/coverage/order/expectation controls и first-run sentinel. Все pending scripts закреплены в server-construction-preparation.json. Исполнение ждёт освобождения общей CPU-полосы Colors.


## Construction experiment не закрывает30s

Bounded9a: aa/positive по4runs сохраняют exact native JSON bytes;20 independent order arrays на stage и31 616 раздельных mutable sample objects. Внутренний browser warmup[0]===raw[0] alias сохранён. Время3.13s, exit0.

Первый pnpm exec остановился до тестов: dependency status попытался relink symlink node_modules и дал ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY. Не включали CI/purge и не меняли общие modules. Сохранены setup-refusal log/receipt. Второй diagnostic запуск использовал exact установленный Vitest через Node и root isolated worktree, как existing check-binding-mutations harness; package/lock bytes сравнивались с source.

Timed9a healthy61.569s RED/30s; old stock8.723s RED/5s (принятый78e stock fix в этом эксперименте отсутствует). Command75.895s,userCPU82.203/sys6.102. Ранее d10 healthy59.710s, но отличались момент запуска и entrypoint зависимостей; идеальной изоляции и доказанного отсутствия любого ускорения не заявляем. Утверждение узкое: эта реализация construction не закрыла30s. Candidate не интегрирован. Full native JSON parity/faults не запускались, потому что кандидат не проходит timing. Полоса возвращена parent для Colors Trivy RCA.


## Native ESM отделил carrier overhead от полных traversals

Exact78e native diagnostic полногоN292/12 253records и обоих validators завершился68.987s; Vitest как главная причина не подтверждается. После контрфактуального удаления всей healthy construction и CPU encoding остаются наблюдаемые41.557s artifact/event hashing,chain и validators. Это не абсолютный lower bound, но дальнейшая fixture-полировка не имеет доказанного30s-route. Whole-test30s отделён от per-browser-operation30000; actual CLI использует fresh raw-byte SHA и existing verified rawDigest, unit проверяет object-carrier reserialization. Подробности и ограничения — server-admission-cost-boundary.md. Runtime/helpers не менялись; timeout/corpus не ослаблялись.


## Exact78e: локальная подготовка draft

Authority cutoff — agents-config70df60b58d085800d09fe1b29b612c0373982db1; ACTIVE/r11. SPEC/TEMPLATE/PARALLEL/r11 побайтно совпадают с a3b751b, использованным независимыми reviewers. CONTRIBUTING и локальные hooks не устанавливают отдельного local-GREEN запрета на честный draft; готовность и merge остаются закрытыми. Публикация принадлежит root.

Полный pnpm test на exact78e:5127 PASS/10 FAIL,347 PASS/4 FAIL files, skipped/todo0,1164.349s. Stock0.715s, PROFILE baseline, benchmark cases и freshness прошли. Healthy70.964s/30s, partial62.225s/30s и пять dependent refusals остались RED. Новые текущие timing RED: RESOURCE forced-GC90.477s/90s, animate-scope-package5.631s/5s, reorder-package5.461s/5s. RESOURCE tarball/probe/installed runtime побайтно равны прошлому PASS76; новый отказ им не отменяется. Причина timing drift не установлена. Поздний host/cgroup snapshot не выдаётся за event-time evidence.

Static62.928s и TS7 typecheck5.717s — PASS exact78e. Driver mutation265.650s — PASS83.72 при break80:301 mutants,249 killed,3 timeout,37 survived,12 no coverage. Broad pnpm mutation118.445s — RED на initial dry run: healthy PROFILE timeout30000ms;2376 mutants сгенерированы, campaign не выполнялся, score отсутствует. ConfigError бросает существующий DryRunExecutor после failed test result; это не обнаруженный config parse failure или OOM. Конфигурации, concurrency, limits и scope не менялись, retries не было.

Локальные проверочные процессы завершены; поздний /proc readback не нашёл процессов с cwd этого source/.stryker. HEAD78e/tree41bf2ed чисты. Sourcebundle, точный diff, локальный PR body,22-row gate map, raw receipts, historical failures и восемь scope-specific reviews входят в portable evidence packet. Публичного carrier, remote CI, нового CodeRabbit review и WebKit execution пока нет; readiness/merge/release/deploy не заявляются.
