# Traversals unit и настоящего consumer

Источник — exact78e7ab200f473667d8863ff028c17c2e0d7debbc. Только анализ исходников; новых прогонов и изменений реализации нет.

## Вывод

Существующий producer → raw bytes → CLI путь не устраняет суммарный полный JSON обход корпуса. Unit дополнительно сериализует artifact в verifier, но не сериализует journal records для записи. Настоящий pipeline заменяет первый обход fresh byte hash и добавляет второй обход записи журнала. Обе схемы делают четыре JSON encoding прохода по sample bodies и четыре SHA256 чтения; envelopes и фактические bytes различаются. У настоящего pipeline дополнительно есть запись/чтение файлов, разбор двух carriers и deep equality независимо распарсенных sample graphs. Это счёт обходов по исходникам, не измерение времени и не прогноз конкретного ускорения.

| Нынешняя непересекающаяся unit фаза | Обязанность настоящего pipeline | Что строго исчезает |
|---|---|---|
| admissionEvents с artifact hash,7.040s | writeServerArtifact создаёт bytes и hash (runner:723; contract:741) | Ничего; нужен полный artifact, а также write |
| chain,7.503s | journal payload hash (runner:95) | Ничего; дополнительно runner:96 сериализует record с digest для append |
| validateServerArtifact,9.436s | CLI вызывает тот же validator (contract:961) | Ничего: N/calibration/raw/comparison воспроизводятся из полного корпуса |
| validateServerJournal,17.578s | CLI проверяет свежий raw-byte SHA и передаёт rawDigest (957–960), затем chronology/coverage/raw correspondence и каждый record payload hash (834–942) | Только повторный JSON encoding artifact на937 заменяется свежим byte hash. Остальная journal validation остаётся; весь17.578s не исчезает |

Последний artifact re-encode не был отдельно измерен в новом native phase запуске. Нельзя объявить весь17.578s устранимым или получить точный выигрыш вычитанием старого профиля. Ранее recorded CPU profile относил6.915s к fresh artifact digest, но это другая наблюдаемая реализация и момент запуска, а не обещание consumer-path выигрыша.

## Полный список coding/hash проходов

Unit admissionHistory и оба validators:

1. Artifact object → JSON → hash для finished event.
2. Каждый journal payload → JSON → hash для chain.
3. Artifact object → JSON → свежий hash в validateServerJournal без rawDigest.
4. Каждый record без digest → JSON → свежий hash в validateServerJournal.

Настоящий producer → bytes → CLI:

1. Journal payload → JSON → hash в producer.
2. Record с digest → JSON → append; второй JSON encoding тех же sample bodies.
3. Artifact → JSON chunks → bytes → hash/write.
4. CLI заново читает raw bytes → свежий hash; JSON encoding здесь отсутствует.
5. CLI разбирает raw и journal bytes в отдельные object graphs.
6. Journal validator повторно кодирует каждый payload → JSON → hash.

Итого — четыре JSON-кодирования в обеих схемах; raw-byte hashing в CLI заменяет hash строки повторно закодированного artifact, не отменяет hash. Unit phase2 включает только hash и создание in-memory record. Подменить его уже запечатанными fixture digests означало бы вынести producer работу за deadline и изменить исходную приёмку всей истории.

## Identity и независимость

В unit events.value.value ссылается на тот же sample, что artifact.rows.samples. Поэтому isDeepStrictEqual(seen.get(key),sample) наcontract:923 и аналогичная comparator проверка используют identity fast path. Byte-carrier pipeline парсит raw и journal отдельно; исходник подтверждает отсутствие такого alias. Полная equality traversal в этом pipeline обязательна для привязки journal к raw. Необходимо также сохранить fresh raw-byte hash перед передачей rawDigest; взять digest из setup/finished без нового read не соответствует CLI contract.

Полноценная проверка пути потребителя внутри прежних30s потребовала бы сериализации/persistence journal, byte hashing, parsing и той же full-N валидации в timed body. Исходник не показывает механизма, который снимет достаточно работы для30s; новый full run без другого различителя не назначен. Это не доказательство невозможности любой оптимизации.
