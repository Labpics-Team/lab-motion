# Граница стоимости серверного admission

Состояние: основной кандидат78e7ab200f473667d8863ff028c17c2e0d7debbc, tree41bf2ed317ac4c3f98c08c12ea85f20c651f5238. Ниже диагностический результат, не прохождение Vitest30s, performance PROFILE или готовность PR.

## Наблюдение

Native ESM исполнил исходную полную fixture и оба validators наNode24.21.0. N292,4440rows,12 253journal records; final digest0b6f6e687572579069d11fdec04db88a8f4e3aa2bc7c14908b9e788dc7aac14b. Worker total68.987s; command71.293s,userCPU75.933s/sys6.017s. PeakRSS709008KiB,majorPageFault1,swappedOut0. Это данные одного диагностического запуска.

| Фаза | Наблюдаемые секунды |
|---|---:|
| Полная construction/history |41.971|
| validateServerArtifact |9.436|
| validateServerJournal |17.578|

Construction/history включает вложенные healthyAdmission20.093s (stage10.480s и expected serverCellPairs9.459s), CPU encoding7.202s, admissionEvents с artifact digest7.040s и journal chain7.503s. Вложенные значения не складываются с родителями. Только четыре непересекающиеся фазы admissionEvents,chain,validateArtifact,validateJournal дают41.557s: текущая стоимость этих фаз превышает30s даже в контрфактуале с бесплатными healthy construction и CPU encoding. Это не универсальный нижний предел: другое представление объектов, алгоритм или оборудование может менять стоимость. Доказанного такого маршрута сейчас нет.

Сопоставимый прежний uninstrumented Vitest baseline389 дал healthy69.320s. Native run не устранил задержку; гипотеза о Vitest как основной её причине не поддерживается. Perf.now wrappers собирали counts/times без промежуточного IO; source helpers проверены по pinned Git bytes. Изменённый load path и instrumentation не дают права объявить эти числа точным причинным A/B измерением overhead.

## Владелец и контракт потребителя

- `test/server-profile-contract.test.ts:1091` ограничивает whole healthy test30s и включает создание полных данных, обе hash construction и оба validators. Зависимые sabotage tests требуют framework pass, учитывающий timeout.
- `bench/profile/server-profile-registration.mjs:83` задаёт browserOperationTimeoutMs30000 для отдельной browser operation. Он не задаёт whole-N admission SLO.
- Производитель `bench/profile/server-profile-runner.mjs:723` записывает полный artifact через writeServerArtifact и журналирует finished digest. Каждый journal payload отдельно хешируется при записи.
- CLI verifier `bench/profile/server-profile-contract.mjs:957` читает raw bytes и заново проверяет внешний SHA256, разбирает raw/journal, передаёт проверенный rawDigest в validateServerJournal, затем вызывает validateServerArtifact. Это существующий byte-carrier путь.
- Unit fixture использует object-carrier путь: validateServerJournal без rawDigest заново сериализует artifact и каждую квитанцию. Переиспользовать setup bytes/digest без свежей проверки означало бы ослабить именно этот путь; такой кандидат не предложен.

## Что исключено и что остаётся

- d10b98d ограничил только expected-pair setup двумя synthetic runs при полных fresh expected vectors. Healthy59.710s RED30s; не интегрирован.
-9a5b764 добавил compact first-run template и independent structuredClone всех следующих raw. Bounded aa/positive4runs: exact bytes и disjoint mutable graphs PASS. Full healthy61.569s RED30s; не интегрирован, full parity не запускалась. Ссылочное объединение samples недопустимо: оно превратит full-N validation в WeakMap cache hits.
- Старый stock assertion overhead устранён отдельно в78e и прошёл независимый QA. Старый stock в9a намеренно отсутствующий78e fix дал8.723s; это не regression основного кандидата.

Следующая реализация должна обосновать новый существенно иной путь в текущем владельце сериализации/валидации либо конкретное различие применимой среды. Повторная fixture-полировка, увеличение timeout, уменьшение N/corpus, перенос setup за таймер или доверие старому digest из evidence не следуют. Полный pre-push/PR/remote CI остаётся открыт.

## Evidence

- server-native-phase.mjs — диагностическая программа, SHA256ee95b8143c4b57f3162045ff6ae3710226af0b852c8f9178d0cb4caf4250a5ee.
- server-native-phase-result.json и server-native-phase-receipt.json — полный readback.
- server-native-phase-source-transfer.json — exact helper bytes #460=76b=78e, одинаковые fixture bodies. Полный prefix78e отличается явным stock-only import node:util; равенство prefix не заявляется.
- server-construction-preparation.json — ограничение отрицательного construction результата и ссылки на setup refusal/bounded/timed evidence.
