# Ошибки параметров

> Diátaxis: справочник — каталог кодов и границ `MotionParamError`.

`MotionParamError.code` — стабильный машинный идентификатор причины. Ошибки
движка содержат в `message` только тот же код: входные значения не отражаются
в runtime-строку. Совместимый внешний конструктор сохраняет переданный текст и
получает `LM000`. Причина и исправление находятся в каталоге; ветвление строится
по `code`.

Коды со статусом `retired` не переиспользуются. `LM000` обозначает ошибку,
созданную внешним кодом через совместимый строковый конструктор.

| Код | Граница | Причина | Исправление | Статус |
|---|---|---|---|---|
| `LM000` | Внешний конструктор | Строка без кода каталога | Для машинной обработки использовать код из каталога | reserved |
| `LM001` | `planAuto` | Некорректный epsilon | Передать конечное число не меньше нуля | active |
| `LM002` | `autoAnimate` | Некорректная длительность | Передать положительную конечную длительность | active |
| `LM003` | behaviors snap | Некорректный список точек | Для `update(snapPoints)` передать непустой плотный список конечных чисел; конструктор сохраняет прежнюю нормализацию | active |
| `LM004` | behaviors drag | Некорректный порог расстояния | Передать положительное конечное число | active |
| `LM005` | behaviors pages | Некорректное число страниц | Передать целое число не меньше одного | active |
| `LM006` | behaviors pages | Некорректный размер страницы | Передать положительное конечное число | active |
| `LM007` | behaviors threshold | Некорректный порог | Передать положительное конечное число | active |
| `LM008` | compositor compile | Неконечная начальная скорость | Передать конечную нормализованную скорость | active |
| `LM009` | compositor numeric | Неконечная числовая граница | Исправить указанное поле | active |
| `LM010` | compositor property | Пустое имя свойства | Передать непустое имя CSS-свойства | active |
| `LM011` | compositor property | Имя конфликтует с метаданными WAAPI | Использовать CSS-имя без конфликта | active |
| `LM012` | `readCompositorSpring` | Неконечное время | Передать конечное время | active |
| `LM013` | `CompositorSpring` | Некорректная задержка | Передать конечную задержку не меньше нуля | active |
| `LM014` | compositor tolerance | Толерантность вне открытого диапазона | Передать конечное значение между нулём и единицей | active |
| `LM015` | `handoffToLive` | Неконечное состояние передачи | Передать конечные value velocity и target | active |
| `LM016` | compositor segmenter | Кривая превышает бюджет сетки | Использовать живой путь или увеличить tolerance | active |
| `LM017` | compositor stagger | Некорректное число элементов | Передать допустимое неотрицательное целое число | active |
| `LM018` | `CompositorStaggerGroup` | targets не является массивом | Передать массив целей | active |
| `LM019` | stagger retarget | Индекс вне группы | Использовать индекс существующего элемента | active |
| `LM020` | stagger handoff | Индекс вне группы | Использовать индекс существующего элемента | active |
| `LM021` | decay | Неконечное начальное значение | Передать конечное from | active |
| `LM022` | decay | Неконечная скорость | Передать конечную velocity | active |
| `LM023` | drive | Неконечное начальное значение | Передать конечное from | active |
| `LM024` | drive | Неконечная цель | Передать конечное to | active |
| `LM025` | drive | Неконечная начальная скорость | Передать конечную initialVelocity | active |
| `LM026` | driver | Неконечное начальное значение | Передать конечное from | active |
| `LM027` | driver | Неконечная цель | Передать конечное to | active |
| `LM028` | easing power | Неконечная степень | Передать конечную степень | active |
| `LM029` | cubic bezier | Неконечная контрольная точка | Передать четыре конечных числа | active |
| `LM030` | cubic bezier | Временная координата вне диапазона | Ограничить x1 и x2 диапазоном от нуля до единицы | active |
| `LM031` | easing steps | Некорректное число шагов | Передать положительное целое число | active |
| `LM032` | easing steps | Неизвестная позиция шага | Использовать start или end | active |
| `LM033` | keyframes values | Недостаточно значений | Передать минимум два значения | active |
| `LM034` | keyframes values | Неконечное значение | Исправить элемент по индексу | active |
| `LM035` | keyframes times | Длина не совпадает с values | Выровнять длины массивов | active |
| `LM036` | keyframes times | Неконечная отметка | Исправить отметку по индексу | active |
| `LM037` | keyframes times | Нарушен порядок отметок | Расположить отметки неубывающе | active |
| `LM038` | keyframes times | Первая отметка не равна нулю | Начать шкалу с нуля | active |
| `LM039` | keyframes times | Последняя отметка не равна единице | Завершить шкалу единицей | active |
| `LM040` | keyframes easing | Длина не совпадает с сегментами | Передать easing для каждого сегмента | active |
| `LM041` | keyframes duration | Некорректная длительность | Передать положительную конечную длительность | active |
| `LM042` | keyframes repeat | Некорректное число повторов | Передать целое 0…2147483647 или Infinity | active |
| `LM043` | keyframes repeat | Неизвестный тип повтора | Использовать loop reverse или mirror | active |
| `LM044` | keyframes repeat | Некорректная задержка повтора | Передать конечное значение не меньше нуля | active |
| `LM045` | MotionValue | Неконечное значение | Исправить указанную числовую границу | active |
| `LM046` | presets spec | Некорректный объект спецификации | Передать PresetSpec | active |
| `LM047` | presets duration | Некорректная длительность | Передать положительную конечную длительность | active |
| `LM048` | presets tracks | Пустой список треков | Добавить хотя бы один трек | active |
| `LM049` | presets property | Свойство не поддерживается | Выбрать поддерживаемое свойство | active |
| `LM050` | presets property | Свойство повторяется | Оставить один трек свойства | active |
| `LM051` | presets values | Недостаточно значений | Передать минимум два значения | active |
| `LM052` | presets values | Неконечное значение | Исправить элемент по индексу | active |
| `LM053` | presets times | Длина не совпадает с values | Выровнять длины массивов | active |
| `LM054` | presets times | Неконечная отметка | Исправить отметку по индексу | active |
| `LM055` | presets times | Нарушен порядок отметок | Расположить отметки неубывающе | active |
| `LM056` | presets times | Первая отметка не равна нулю | Начать шкалу с нуля | active |
| `LM057` | presets times | Последняя отметка не равна единице | Завершить шкалу единицей | active |
| `LM058` | presets easing | Длина не совпадает с сегментами | Передать easing для каждого сегмента | active |
| `LM059` | presets delay | Некорректная задержка | Передать конечное значение не меньше нуля | active |
| `LM060` | presets repeat | Некорректное число повторов | Передать целое 0…2147483647 или Infinity | active |
| `LM061` | presets repeat | Неизвестный тип повтора | Использовать loop reverse или mirror | active |
| `LM062` | presets repeat | Некорректная задержка повтора | Передать конечное значение не меньше нуля | active |
| `LM063` | presets scalar | Неконечный именованный параметр | Исправить указанное поле | active |
| `LM064` | presets duration | Некорректная именованная длительность | Передать положительную конечную длительность | active |
| `LM065` | preset pulse | Некорректная амплитуда | Передать значение больше минус единицы | active |
| `LM066` | preset blink | Некорректный минимум | Передать значение от нуля до единицы | active |
| `LM067` | preset wiggle | Некорректное число циклов | Передать целое число не меньше одного | active |
| `LM068` | preset breathe | Некорректная амплитуда | Передать значение больше минус единицы | active |
| `LM069` | preset pop | Некорректный overshoot | Передать положительное значение | active |
| `LM070` | preset drift | Оба смещения равны нулю | Задать ненулевое смещение | active |
| `LM071` | preset WAAPI | repeatDelay между повторами не представим | Использовать runPreset либо repeat 0 | active |
| `LM072` | splitText | text не является строкой | Передать строку | active |
| `LM073` | splitText | Неизвестный режим | Использовать chars или words | active |
| `LM074` | presets callback | Значение не является функцией | Передать функцию | active |
| `LM075` | runScramble | text не является строкой | Передать строку | active |
| `LM076` | runScramble | Пустой alphabet | Передать непустой алфавит | active |
| `LM077` | projection play | Отсутствует capture | Вызвать capture до изменения DOM | active |
| `LM078` | projection play | Нет исходного состояния узла | Передать first или активный полёт | active |
| `LM079` | projection node | Пустой id | Передать непустой id | active |
| `LM080` | projection node | id повторяется | Сделать id уникальным | active |
| `LM081` | projection radii | Некорректные радиусы | Передать две четвёрки углов | active |
| `LM082` | projection parent | Родитель не найден | Исправить ссылку на родителя | active |
| `LM083` | projection parent | Обнаружен цикл | Удалить циклическую ссылку | active |
| `LM084` | smart key | Ключ повторяется | Сделать ключ уникальным | active |
| `LM085` | smart key | Пустое имя атрибута | Передать непустой keyAttr | active |
| `LM086` | smart epsilon | Некорректный epsilon | Передать конечное число не меньше нуля | active |
| `LM087` | smart mutate | mutate не является функцией | Передать функцию | active |
| `LM088` | spring mass | Некорректная масса | Передать положительное конечное число | active |
| `LM089` | spring stiffness | Некорректная жёсткость | Передать положительное конечное число | active |
| `LM090` | spring damping | Некорректное демпфирование | Передать конечное число не меньше нуля | active |
| `LM091` | spring settle | Время оседания превышает бюджет | Настроить stiffness mass и damping так, чтобы пружина оседала быстрее | active |
| `LM092` | spring ergonomics | Некорректный bounce | Передать конечное значение от минус одного до одного | active |
| `LM093` | spring ergonomics | Некорректный положительный параметр | Передать положительное конечное число | active |
| `LM094` | svg morph | Некорректное число сэмплов | Передать целое число не меньше двух | active |
| `LM095` | SVG path | Ожидалось число | Исправить токен в указанной позиции | active |
| `LM096` | SVG path | Неконечное число | Заменить токен конечным числом | active |
| `LM097` | SVG path | Некорректный arc-флаг | Использовать ноль или единицу | active |
| `LM098` | SVG path | Путь пуст | Передать непустой путь | active |
| `LM099` | SVG path | Неизвестная команда | Использовать команду SVG path | active |
| `LM100` | SVG path | Первая команда не Move | Начать путь с M или m | active |
| `LM101` | SVG path | В пути нет команд | Добавить команду | active |
| `LM102` | timeline segment | Неконечный from | Исправить сегмент | active |
| `LM103` | timeline segment | Неконечный to | Исправить сегмент | active |
| `LM104` | timeline segment | Некорректная длительность | Передать положительную конечную длительность | active |
| `LM105` | timeline segment | Некорректный at | Передать конечное значение не меньше нуля | active |
| `LM106` | timeline segment | Некорректный offset | Передать конечное значение не меньше нуля | active |
| `LM107` | timeline | Пустой список сегментов | Добавить хотя бы один сегмент | active |
| `LM108` | spring token | Некорректная длительность | Передать положительное конечное число секунд | active |
| `LM109` | spring token | Некорректный bounce | Передать значение от нуля включительно до единицы | active |
| `LM110` | utils finite | Неконечный именованный параметр | Исправить указанное поле | active |
| `LM111` | utils clamp | Граница равна NaN | Передать границы без NaN | active |
| `LM112` | utils snap | Пустой список целей | Добавить хотя бы одну цель | active |
| `LM113` | utils snap | Нулевой шаг | Передать ненулевой шаг | active |
| `LM114` | utils interpolate | Длины входа и выхода различаются | Выровнять длины | active |
| `LM115` | utils interpolate | Недостаточно остановок | Передать минимум две остановки | active |
| `LM116` | utils interpolate | Вход не возрастает | Упорядочить вход строго по возрастанию | active |
| `LM117` | utils interpolate | Длина easing не совпадает | Передать easing для каждого сегмента | active |
| `LM118` | utils interpolate | Easing не является функцией | Передать функцию | active |
| `LM119` | easingToLinear | Некорректное число точек | Передать целое число не меньше двух | active |
| `LM120` | compileWaapi property | Пустое имя свойства | Передать непустое имя | active |
| `LM121` | compileWaapi property | Имя конфликтует с метаданными | Использовать CSS-имя без конфликта | active |
| `LM122` | compileWaapi values | Недостаточно значений | Передать минимум два значения | active |
| `LM123` | compileWaapi values | Неконечное значение | Передать конечные значения | active |
| `LM124` | compileWaapi times | Длина не совпадает с values | Выровнять длины массивов | active |
| `LM125` | compileWaapi times | Некорректные концы шкалы | Начать нулём и завершить единицей | active |
| `LM126` | compileWaapi times | Неконечная или убывающая отметка | Исправить отметку по индексу | active |
| `LM127` | compileWaapi duration | Некорректная длительность | Передать положительную конечную длительность | active |
| `LM128` | compileWaapi repeat | Некорректное число повторов | Передать целое 0…2147483647 или Infinity | active |
| `LM129` | compileWaapi repeat | Некорректная задержка | Передать конечное значение не меньше нуля | active |
| `LM130` | compileWaapi repeat | Неизвестный тип повтора | Использовать loop reverse или mirror | active |
| `LM131` | compileWaapi repeat | Задержка несовместима с типом | Использовать loop или живой keyframes-путь | active |
| `LM132` | compileWaapi easing | Некорректный контейнер easing | Передать функцию или массив функций | active |
| `LM133` | compileWaapi easing | Длина массива не совпадает | Передать easing для каждого сегмента | active |
| `LM134` | compileWaapi easing | Элемент не является функцией | Передать функции | active |
| `LM135` | animateWaapi target | Цель не поддерживает WAAPI | Проверить supportsWaapi или выбрать живой путь | active |
| `LM136` | animate mode | Одновременно заданы spring и tween | Выбрать один режим движения | active |
| `LM137` | animate duration | Некорректная длительность tween | Передать положительную конечную длительность | active |
| `LM138` | animate ease | Ease не является функцией | Передать функцию прогресса | active |
| `LM139` | animate schedule | Некорректная delay или stagger | Передать конечное значение не меньше нуля | active |
| `LM140` | animate property | Передан whole transform | Использовать transform-шортхенды | active |
| `LM141` | animate pair | Некорректная пара from и to | Передать массив ровно из двух значений | active |
| `LM142` | animate numeric | Некорректное числовое значение | Передать конечное число | active |
| `LM143` | animate CSS type | Неподдерживаемый тип CSS-значения | Передать строку или число | active |
| `LM144` | animate CSS syntax | CSS-значение не разобрано | Передать поддерживаемое значение или цвет | active |
| `LM145` | animate property | Свойство или кодек не поддерживается | Выбрать поддерживаемое свойство | retired |
| `LM146` | DOM targets | Некорректный контейнер целей | Передать цель или ограниченный список целей | active |
| `LM147` | DOM targets | Некорректный элемент списка целей | Проверить каждый элемент списка | active |
| `LM148` | animate adapter | Адаптер цели отсутствует | Использовать поддерживаемый вид цели | retired |
| `LM149` | DOM capability host | Селектор либо нативный DOM-host недоступен или нарушил контракт | Передать цель напрямую либо запускать с исправным browser host | active |
| `LM150` | animate impulse | Импульс не представим у числовой границы | Уменьшить значение или скорость | active |
| `LM151` | animate props | Props не является объектом-записью | Передать объект поддерживаемых свойств | active |
| `LM152` | animate native props | Props не содержит свойств | Добавить хотя бы одно свойство | retired |
| `LM153` | animate native WAAPI | Цель не поддерживает WAAPI | Использовать WAAPI-цель или полный animate | retired |
| `LM154` | animate native easing | CSS linear недоступен | Использовать WebKit-кадры или полный animate | retired |
| `LM155` | animate native host | Host вернул некорректную Animation | Исправить WAAPI или polyfill | retired |
| `LM156` | DOM facade options | Options/callback либо поле опций не соответствует контракту | Передать корректный объект опций и вызываемые callback-функции | active |
| `LM157` | animate transition | Реентрантная смена владельца | Завершить текущую host-транзакцию перед новым animate | active |
| `LM158` | splitText segmenter | Доступный grapheme segmenter не создался или нарушил контракт | Исправить `Intl.Segmenter` либо передать корректный Unicode ponyfill | active |
| `LM159` | preset WAAPI | Mirror repeat не представим через WAAPI alternate | Использовать runPreset или точный двухцикловый track | active |
| `LM160` | compileWaapi repeat | Mirror repeat не представим через WAAPI alternate | Использовать keyframes или точный двухцикловый track | active |
| `LM161` | repeat schedule | Расписание численно неразличимо либо finite repeatDelay не имеет portable WAAPI-эмита | Уменьшить расписание или использовать живой keyframes-путь | active |
| `LM162` | WAAPI artifact | Timing или значение не конечно либо разные authored stops схлопнулись после WAAPI-масштаба | Уменьшить длительность, задержку, масштаб или разнести stops | active |
| `LM163` | keyframes easing | Scalar или элемент easing не является функцией | Передать функцию для каждого сегмента | active |
| `LM164` | presets easing | Scalar или элемент easing не является функцией | Передать функцию для каждого сегмента | active |
| `LM165` | frame scheduler | requestFrame не является функцией | Передать функцию планирования кадра | active |
| `LM166` | infinite repeat sample | Время требует номер итерации выше точного binary64 integer domain | Сэмплировать до 9_007_199_254_740_991-й итерации или завершить контрол явно | active |
| `LM167` | surface input | Ширина поверхности не является положительным конечным CSS px; либо budget точности сопряжения не положителен/не конечен | Передать положительные конечные px-endpoints bounded viewport и положительный конечный coupling budget | active |
| `LM168` | surface controls | play/pause/seek вызваны на one-shot surface-переходе: движение сертифицировано парой CSS-анимаций псевдодерева без адресата управления | Использовать контракт поверхности: committed/ready/finished/cancel; stop эквивалентен cancel | active |
| `LM169` | spring easing | у пружины не существует финитной C¹-проекции на [0,1] в допуск: затухания нет (damping = 0) либо горизонт допуска недостижим при экстремальном ζ | Задать damping > 0 и умеренное ζ либо использовать tween с явной длительностью | active |
| `LM170` | reserved | Код зарезервирован параллельной spring-работой | Не использовать вне назначенного контракта | reserved |
| `LM171` | reserved | Код зарезервирован параллельной spring-работой | Не использовать вне назначенного контракта | reserved |
| `LM172` | compositor value error | Некорректный абсолютный бюджет ошибки реконструкции | Передать положительный конечный maxValueError в единицах numeric from/to | active |
| `LM173` | presence intent | `present` не является boolean | Передать `true` или `false` | active |
| `LM174` | presence group | Группа содержит больше 10 000 controls | Сократить или разбить группу до 10 000 controls | active |
| `LM175` | presence group | Группа содержит пропуск | Вернуть плотный массив controls | active |
| `LM176` | presence controls | Элемент группы не является объектом controls | Вернуть controls `{ finished, cancel }` | active |
| `LM177` | presence controls | `cancel` отсутствует или не является функцией | Вернуть вызываемый `cancel` | active |
| `LM178` | presence controls | `finished` отсутствует или не предоставляет функцию `then` | Вернуть `PromiseLike` в `finished` | active |
| `LM179` | semantic binding | Некорректный рецепт, карта портов или возвращённый ресурс | Передать функцию проекции, непустую карту функций и controls с cancel либо void | active |
| `LM180` | semantic binding goals | Неполный или изменившийся набор ролей/свойств, неконечное число/неподдерживаемый тип цели либо превышение суммарного предела 10 000 ролей и свойств | Вернуть стабильную карту абсолютных конечных чисел и строк | active |
| `LM181` | semantic binding projection | Реентрантный update во время вычисления целей | Сделать проекцию чистой; менять модель вне проекции | active |
