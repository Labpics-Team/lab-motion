/**
 * behaviors/index.ts — headless state machines типовых мобильных взаимодействий
 * (subpath ./behaviors, фаза H).
 *
 * Subpath export: import { createBottomSheet } from '@labpics/motion/behaviors'
 *
 * ЗАЧЕМ (граница ответственности): ./gestures даёт распознаватели (press/pan/
 * drag) и инерцию, ./decay — аналитическое затухание, ядро — пружинный солвер.
 * Но «bottom sheet со snap-точками», «drag-to-dismiss с порогом», «пейджер с
 * доводкой к странице», «pull-to-refresh с pending» — это ПРИКЛАДНЫЕ машины
 * состояний поверх этих примитивов. ./behaviors закрывает ровно этот разрыв:
 * готовое поведение (фаза + переходы + выбор цели), НЕ знающее про фреймворк
 * или компонентную библиотеку. DOM-примеры (docs/recipes.md) — тонкие адаптеры
 * поверх этого headless API.
 *
 * Общий контракт (BehaviorState<T>): { value, velocity, phase }, где
 * phase ∈ 'idle'|'follow'|'release'|'settle'. Каждое поведение: события ввода
 * (pointerDown/Move/Up/Cancel), текущее состояние (`state`-геттер + `subscribe`),
 * программные переходы, идемпотентные `cancel()`/`destroy()`.
 *
 * Карта ПЕРЕИСПОЛЬЗОВАНИЯ (ничего не дублировано — импорты, не копии):
 *   ../gestures createVelocityTracker — оценка скорости указателя по окну
 *     сэмплов (тот же трекер, что питает createDrag; velocity на отпускании).
 *   ../decay projectDefaultDecayRest — та же точка покоя, куда прилетел бы элемент
 *     под инерцией → выбор целевого snap/страницы по положению+скорости.
 *   ../internal/solver solveSpring — единый пружинный солвер (тот же, что ядро и
 *     smooth-pickup MotionValue): доводка value→target с наследованием velocity
 *     (v0n = velocity/range даёт C¹ на стыке follow|release).
 *   ../spring validateSpringForFrameLoop — ранний fail-fast MotionParamError В ФАБРИКЕ.
 *   ../internal/motion-defaults — общие пружины доводки и публичных токенов;
 *     роль задаёт потребитель, labui и инициализация изингов не импортируются.
 *
 * Инварианты (нарушение = провал):
 *   B1. ОДНА state machine владеет фазой и переходами; pointer/programmatic
 *       control НЕ создают параллельные loops — единый generation-токен гасит
 *       stale-кадры, в любой момент активен максимум один runner (один clock).
 *   B2. value и velocity КОНЕЧНЫ (_finite + схлопнутый −0) на каждом выходе.
 *   B3. cancel()/destroy() ИДЕМПОТЕНТНЫ; destroy → инертность (вход = no-op).
 *   B4. reduced-motion меняет ХАРАКТЕР пространственного движения (снап вместо
 *       пружинных кадров), сохраняя состояние и РЕЗУЛЬТАТ (character-switch).
 *   B5. SSR-safe: ни window, ни document на пути импорта; единственный
 *       платформенный шов — инжектируемый requestFrame (детерминизм тестов).
 *
 * ─── MUTATION PROOF (ручная проба, 2026-07-10; каждый мутант откачен) ─────────
 * 10 мутантов в РАЗНЫЕ поведения/переходы, каждый кусается (RED на зафиксированной
 * спеке; прогон test/behaviors-*.test.ts):
 *   1. Слом выбора snap по скорости (проекция игнорит velocity: landing=value) →
 *      RED (property «flick вверх → верхний snap», sheet-example «доводка по флику»).
 *   2. Потеря velocity на follow→release (v0n=0 вместо velocity/range) → RED
 *      (dismiss «возврат наследует скорость», sheet C¹-контракт).
 *   3. Параллельный loop (pointerDown НЕ инкрементит generation) → RED
 *      (interruption «pointer-down во время settle не плодит второй clock»,
 *      clock.pending()/rafCalls двойные).
 *   4. Слом идемпотентности cancel (нет guard destroyed/idle) → RED
 *      (lifecycle «двойной cancel/destroy», эмитов больше 1).
 *   5. Reduced-leak (убран reduced-ветка в runner) → RED (reduced-контракт:
 *      промежуточные value ∈ (from,target), а обязан быть мгновенный снап).
 *   6. Слом порога dismiss (>= заменён на >) на граничном значении → RED
 *      (dismiss property «ровно на пороге → dismiss»).
 *   7. Слом единого clock carousel (index из отдельного счётчика, не из position)
 *      → RED (carousel «index и position согласованы каждый кадр»).
 *   8. Rubber-band знак (overshoot*factor → overshoot/factor или знак-flip) → RED
 *      (sheet «rubber-band за крайним snap уводит в ту же сторону, меньше»).
 *   9. Pull: второй владелец позиции (pending заводит свой таймер поверх runner)
 *      → RED (pull «pending удерживается тем же runner», нет двойных кадров).
 *  10. Carousel RTL-знак (rtl не флипает направление) → RED (property «RTL
 *      зеркалит выбор страницы»).
 */

import { createVelocityTracker } from '../gestures/index.js';
import { projectDefaultDecayRest } from '../decay.js';
import { MotionParamError } from '../errors.js';
import { solveSpring } from '../internal/solver.js';
import { CONVERGENCE_THRESHOLD, FIXED_DT_S, MAX_FRAMES } from '../internal/constants.js';
import type { MatchMediaLike } from '../internal/media-query.js';
import { validateSpringForFrameLoop, type SpringParams } from '../spring.js';
import { DEFAULT_SPRING, SNAPPY_SPRING } from '../internal/motion-defaults.js';
import type { RequestFrameFn } from '../motion-value.js';

// ─── Общий контракт ──────────────────────────────────────────────────────────

/** Фаза жизненного цикла поведения (единый контракт всех машин). */
export type BehaviorPhase = 'idle' | 'follow' | 'release' | 'settle';

/**
 * Снимок состояния поведения. `value`/`velocity` в единицах поведения (обычно px
 * / px·s⁻¹); оба всегда конечны (B2). `phase` — текущая фаза машины.
 */
export interface BehaviorState<T = number> {
  readonly value: T;
  readonly velocity: T;
  readonly phase: BehaviorPhase;
}

/** Точка ввода: координаты (px) + время (СЕКУНДЫ, напр. e.timeStamp/1000). */
export interface BehaviorPoint {
  readonly x: number;
  readonly y: number;
  readonly t: number;
}

/** Ось, вдоль которой поведение читает ввод. */
export type BehaviorAxis = 'x' | 'y';

// ─── Финитность и мелкие утилиты (B2) ────────────────────────────────────────

/**
 * Страж конечности (зеркалит clampFinite ядра + схлопывает −0):
 * finite → как есть (`+0` убивает −0); NaN → 0; ±∞ → ±MAX_VALUE.
 */
function _finite(x: number): number {
  if (Number.isFinite(x)) return x + 0;
  if (Number.isNaN(x)) return 0;
  return x > 0 ? Number.MAX_VALUE : -Number.MAX_VALUE;
}

/** Разность уже нормализованных координат с защитой от overflow. */
function _sub(a: number, b: number): number {
  return _finite(a - b);
}

/** Прочитать координату точки по оси (конечную). */
function _coord(p: BehaviorPoint, axis: BehaviorAxis): number {
  return _finite(axis === 'x' ? p.x : p.y);
}

/** Прочитать предпочтение reduced-motion из инжектируемого matchMedia (B4). */
function _prefersReduced(matchMedia: MatchMediaLike | undefined): boolean {
  if (typeof matchMedia !== 'function') return false;
  try {
    return matchMedia('(prefers-reduced-motion: reduce)').matches === true;
  } catch {
    return false;
  }
}

/** Нормализовать factor сопротивления в [0,1] (дефолт при мусоре). */
function _clampFactor(raw: number | undefined, dflt: number): number {
  return Number.isFinite(raw) ? Math.min(1, Math.max(0, raw!)) : dflt;
}

const DEFAULT_RUBBER_BAND = 0.5;
/** Половина окна трекера — засев прайора скорости при перехвате (канон gestures). */
const PICKUP_SEED_DT_S = 0.05;

// ─── Единый runner (B1): один clock, доводка value→target пружиной ───────────

/**
 * Аргументы одной доводки: from/velocity (унаследованная скорость момента
 * отпускания или перехвата), target, пружина, и колбэки на кадр/финиш.
 */
interface _SettleArgs {
  readonly from: number;
  readonly velocity: number;
  readonly target: number;
  readonly spring: SpringParams;
  readonly onStep: (value: number, velocity: number) => void;
  readonly onDone: () => void;
}

/** Внутренний контракт доводки общего владельца поведения. */
interface _Runner {
  /** Запустить доводку value→target (ровно один активный цикл). */
  _settle(args: _SettleArgs): void;
  /** Погасить активный цикл (перехват/cancel) — stale-кадры инвалидируются. */
  _invalidate(reset?: boolean): number;
}

/**
 * Общий владелец состояния, подписчиков, tracker и кадровой доводки. Четыре
 * поведения задают переходы и цели, сохраняя один generation-токен: новый
 * `_settle()` или `_invalidate()` гасит запланированные кадры старой доводки.
 * reduced-motion мгновенно ставит target без кадров (B4).
 */
function _createBase<S extends BehaviorState<number>, O extends object | true>(
  initial: S,
  options: {
    readonly requestFrame?: RequestFrameFn | undefined;
    readonly matchMedia?: MatchMediaLike | undefined;
  },
  owner: O,
) {
  let requestFrame = options.requestFrame;
  const reduced = _prefersReduced(options.matchMedia);
  let gen = 0;
  let curVel = 0;

  const schedule = (cb: (ts?: number) => void): void => {
    const handle = requestFrame!(cb);
    if (handle === 0) setTimeout(() => cb(undefined), 0); // non-draining шов (конвенция repo)
  };

  const tracker = createVelocityTracker();
  const subs = new Set<(s: S) => void>();
  let state = initial;

  const emit = (next: Partial<S>): boolean => {
    const emitted = state = { ...state, ...next };
    for (const fn of subs) {
      try {
        fn(emitted);
      } catch {
        // Подписчик не имеет права срывать соседей.
      }
      if (state !== emitted) break;
    }
    return !!base.owner && state === emitted;
  };

  const base = {
    _settle(args: _SettleArgs): void {
      const my = ++gen;
      curVel = args.velocity;
      const range = args.target - args.from;

      const finishNow = (): void => {
        curVel = 0;
        args.onStep(_finite(args.target), 0);
        if (my === gen) args.onDone();
      };

      // B4: reduced-motion / вырожденный диапазон / нет кадрового шва → снап.
      if (reduced || range === 0 || !requestFrame) {
        finishNow();
        return;
      }

      // C¹-стык: нормируем унаследованную скорость на диапазон (тот же приём,
      // что smooth-pickup MotionValue и snapBack gestures) — знак «к цели» и
      // непрерывность производной на границе follow|release получаются даром.
      const v0n = curVel / range;
      let elapsed = 0;
      let lastTs: number | undefined;
      let frames = 0;

      const tick = (ts?: number): void => {
        if (my !== gen) return; // stale-кадр после перехвата/cancel
        if (Number.isFinite(ts)) {
          elapsed = lastTs === undefined ? elapsed : elapsed + Math.max(0, (ts! - lastTs) / 1000);
          lastTs = ts!;
        } else {
          elapsed += FIXED_DT_S;
        }
        frames++;

        const s = solveSpring(args.spring, elapsed, v0n);
        const val = args.from + s.value * range;
        const vel = s.velocity * range;
        const denom = Math.abs(range); // > 0 по построению (range !== 0)

        if (
          !Number.isFinite(val) ||
          !Number.isFinite(vel) ||
          (Math.abs(val - args.target) / denom < CONVERGENCE_THRESHOLD &&
            Math.abs(vel) / denom < CONVERGENCE_THRESHOLD) ||
          frames >= MAX_FRAMES
        ) {
          finishNow();
          return;
        }
        curVel = vel;
        args.onStep(val, vel);
        if (my === gen) schedule(tick);
      };

      schedule(tick);
    },
    /** Программная смена цели сохраняет samples; перехват/cancel/destroy сбрасывают. */
    _invalidate(reset?: boolean): number {
      gen++;
      if (reset) tracker.reset();
      const velocity = curVel;
      curVel = 0;
      return velocity;
    },
    tracker,
    // Только Dismiss/Pull нужны поздние getter и receiver исходных options.
    // Sheet/Pager владеют lifecycle-token: после off не удерживают constructor
    // onChange через ненужный options. Одна terminal-граница освобождает owner.
    owner: owner as O | null,
    get state(): S {
      return state;
    },
    emit,
    get _following(): boolean {
      return !!base.owner && state.phase === 'follow';
    },
    subscribe(fn: (s: S) => void): () => void {
      if (!base.owner) return () => {};
      subs.add(fn);
      // Живой Set владеет fn; сохранённый off удерживает только слабую identity.
      const reference = new WeakRef(fn);
      return () => { subs.delete(reference.deref()!); };
    },
    /**
     * Погасить активную доводку и осесть в покой на ТЕКУЩЕМ значении (phase idle,
     * velocity 0). Идемпотентна: повторный вызов на уже покоящейся машине —
     * no-op (не плодит эмитов). destroy() строится поверх неё.
     */
    cancel(reset?: Partial<S>): void {
      if (!base.owner || state.phase === 'idle') return; // уже в покое
      base._invalidate(true);
      emit({ ...reset, velocity: 0, phase: 'idle' } as Partial<S>);
    },
    destroy(): void {
      if (!base.owner) return;
      base.owner = null;
      base._invalidate(true);
      requestFrame = undefined;
      subs.clear();
    },
  };
  return base;
}

/** Поздний getter может отозвать intent; повторная проверка предшествует эффекту. */
function _invoke<O extends object>(
  base: { owner: O | null; readonly state: unknown },
  key: keyof O,
): unknown {
  const owner = base.owner;
  const state = base.state;
  const callback = owner?.[key] as (() => unknown) | undefined;
  if (base.owner && base.state === state && callback != null) {
    return Reflect.apply(callback, owner, []);
  }
}

/** Перехватить активную доводку тем же tracker/runner и сохранить C¹-prior. */
function _beginPickup(
  base: _Runner & { tracker: ReturnType<typeof createVelocityTracker> },
  p: BehaviorPoint,
  axis: BehaviorAxis,
  velocityScale = 1,
): void {
  const carry = base._invalidate(true) * velocityScale;
  if (carry !== 0) {
    const back = { x: _finite(p.x), y: _finite(p.y), t: _finite(p.t) - PICKUP_SEED_DT_S };
    back[axis === 'x' ? 'x' : 'y'] -= carry * PICKUP_SEED_DT_S;
    base.tracker.push(back);
  }
  base.tracker.push(p);
}


// ═══════════════════════════════════════════════════════════════════════════
// 1. BOTTOM SHEET
// ═══════════════════════════════════════════════════════════════════════════

/** Состояние bottom sheet: value = позиция (px) + индекс целевого snap. */
export interface SheetState extends BehaviorState<number> {
  /** Индекс ближайшего/целевого snap в отсортированном массиве. */
  readonly snapIndex: number;
}

/** Опции bottom sheet. */
export interface SheetOptions {
  /** Snap-точки (px); конструктор сохраняет legacy finite-normalization, `update` строгий. */
  readonly snapPoints: readonly number[];
  /** Стартовая позиция (px). По умолчанию — минимальная snap-точка. */
  readonly initial?: number | undefined;
  /** Ось чтения ввода. По умолчанию 'y' (вертикальный лист). */
  readonly axis?: BehaviorAxis | undefined;
  /** Пружина доводки. По умолчанию токен spring.default (./tokens). */
  readonly spring?: SpringParams | undefined;
  /** Сопротивление за крайними snap ∈ [0,1]. По умолчанию 0.5. */
  readonly rubberBand?: number | undefined;
  readonly requestFrame?: RequestFrameFn | undefined;
  readonly matchMedia?: MatchMediaLike | undefined;
  readonly onChange?: ((s: SheetState) => void) | undefined;
}

/** Контроллер bottom sheet. */
export interface SheetController {
  pointerDown(p: BehaviorPoint): void;
  pointerMove(p: BehaviorPoint): void;
  pointerUp(p: BehaviorPoint): void;
  pointerCancel(): void;
  /** Обновить snap-ограничения без смены владельца/часов. */
  update(snapPoints: readonly number[]): void;
  /** Программный переход к snap по индексу (единый clock, C¹ из текущей скорости). */
  snapTo(index: number): void;
  subscribe(fn: (s: SheetState) => void): () => void;
  cancel(): void;
  destroy(): void;
  readonly state: SheetState;
}

/**
 * Выбрать индекс snap по положению+скорости: проецируем момент через ./decay
 * (`.rest` = куда прилетел бы элемент под инерцией) и берём ближайшую snap-точку.
 * Скорость влияет монотонно (больше скорость → дальше проекция → дальний snap).
 */
function _pickSnap(snaps: readonly number[], value: number, velocity: number): number {
  const landing = projectDefaultDecayRest(value, velocity);
  let best = 0;
  let bestDist = Infinity;
  for (let i = 0; i < snaps.length; i++) {
    const d = Math.abs(snaps[i]! - landing);
    if (d < bestDist) {
      bestDist = d;
      best = i;
    }
  }
  return best;
}

/**
 * Создать headless bottom sheet: snap-точки + выбор цели по положению+скорости,
 * follow→доводка (пружина/снап) без потери velocity, rubber-band за крайними
 * snap, программный snapTo, прерывание новым pointer-down. Один clock (B1).
 *
 * @throws {MotionParamError} при пустом snapPoints или невалидной пружине.
 */
export function createBottomSheet(options: SheetOptions): SheetController {
  const readSnaps = (next: number[]): number[] => {
    if (!next.length || !next.every(Number.isFinite)) {
      throw new MotionParamError('LM003');
    }
    return next.sort(_sub);
  };
  let snaps = readSnaps([...options.snapPoints].map(_finite));
  const axis = options.axis ?? 'y';
  const springParams = options.spring ?? DEFAULT_SPRING;
  validateSpringForFrameLoop(springParams);
  const rubber = _clampFactor(options.rubberBand, DEFAULT_RUBBER_BAND);

  const start = _finite(options.initial ?? snaps[0]!);
  const startIndex = _pickSnap(snaps, start, 0);
  const base = _createBase<SheetState, true>(
    { value: start, velocity: 0, phase: 'idle', snapIndex: startIndex },
    options, true,
  );

  let grabValue = 0;
  let lastPointer = 0;

  /** Применить rubber-band за крайними snap к сырой позиции под пальцем. */
  const clampFollow = (raw: number): number => {
    const min = snaps[0]!;
    const max = snaps[snaps.length - 1]!;
    if (raw > max) {
      if (!rubber && base.state.value > max) return Math.min(base.state.value, raw);
      return _finite(max + _sub(raw, max) * rubber);
    }
    if (raw < min) {
      if (!rubber && base.state.value < min) return Math.max(base.state.value, raw);
      return _finite(min + _sub(raw, min) * rubber);
    }
    return raw;
  };

  const settleTo = (index: number, velocity: number): void => {
    base.emit({ phase: 'release', snapIndex: index }) && base._settle({
      from: base.state.value,
      velocity,
      target: snaps[index]!,
      spring: springParams,
      onStep: (v, vel) => base.emit({ value: v, velocity: vel }),
      onDone: () => base.emit({ phase: 'settle' }),
    });
  };

  const ctrl: SheetController = {
    pointerDown(p: BehaviorPoint): void {
      if (!base.owner) return;
      // Прерывание: гасим активную доводку, наследуем её скорость прайором (C¹).
      _beginPickup(base, p, axis);
      lastPointer = _coord(p, axis);
      grabValue = _sub(base.state.value, lastPointer);
      base.emit({ phase: 'follow', velocity: 0 });
    },
    pointerMove(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      lastPointer = _coord(p, axis);
      const raw = lastPointer + grabValue;
      base.emit({ value: clampFollow(raw) });
    },
    pointerUp(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const v = axis === 'x' ? base.tracker.velocity().vx : base.tracker.velocity().vy;
      settleTo(_pickSnap(snaps, base.state.value, v), v);
    },
    pointerCancel(): void {
      if (!base._following) return;
      // Детерминизм: осесть в ближайший snap без унаследованной скорости.
      settleTo(_pickSnap(snaps, base.state.value, 0), 0);
    },
    update(next: readonly number[]): void {
      if (!base.owner) return;
      const parsed = readSnaps([...next]);
      if (parsed.length === snaps.length && parsed.every((v, i) => v === snaps[i])) return;
      snaps = parsed;
      if (base._following) {
        const value = base.state.value;
        const min = snaps[0]!;
        const max = snaps[snaps.length - 1]!;
        grabValue = _sub(!rubber ? value
          : value > max ? max + (value - max) / rubber
          : value < min ? min + (value - min) / rubber : value, lastPointer);
        base.emit({ snapIndex: Math.min(base.state.snapIndex, snaps.length - 1) });
      } else settleTo(Math.min(base.state.snapIndex, snaps.length - 1), base._invalidate());
    },
    snapTo(index: number): void {
      if (!base.owner) return;
      const i = Math.max(0, Math.min(snaps.length - 1, Math.trunc(_finite(index))));
      settleTo(i, base._invalidate());
    },
    subscribe: base.subscribe,
    cancel: base.cancel,
    destroy: base.destroy,
    get state(): SheetState {
      return base.state;
    },
  };
  if (options.onChange) ctrl.subscribe(options.onChange);
  return ctrl;
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. DRAG-TO-DISMISS
// ═══════════════════════════════════════════════════════════════════════════

/** Состояние dismiss: value = смещение (px) от покоя + флаг «отпущено». */
export interface DismissState extends BehaviorState<number> {
  /** true после того, как порог достигнут и элемент уехал в dismissTarget. */
  readonly dismissed: boolean;
}

/** Опции drag-to-dismiss. */
export interface DismissOptions {
  /** Ось чтения ввода. По умолчанию 'y'. */
  readonly axis?: BehaviorAxis | undefined;
  /** Знак направления вдоль оси, которое ЗАКРЫВАЕТ (1 или −1). По умолчанию 1. */
  readonly direction?: 1 | -1 | undefined;
  /** Порог смещения (px, по модулю в направлении dismiss). Обязателен. */
  readonly distanceThreshold: number;
  /** Порог скорости (px/s) — быстрый флик закрывает раньше дистанции. По умолчанию 600. */
  readonly velocityThreshold?: number | undefined;
  /** Куда уезжает элемент при закрытии (px смещения). По умолчанию direction·(distanceThreshold·8). */
  readonly dismissTarget?: number | undefined;
  /** Пружина возврата/уезда. По умолчанию токен spring.default. */
  readonly spring?: SpringParams | undefined;
  readonly requestFrame?: RequestFrameFn | undefined;
  readonly matchMedia?: MatchMediaLike | undefined;
  readonly onChange?: ((s: DismissState) => void) | undefined;
  /** Вызывается один раз, когда элемент осел в dismissTarget. */
  readonly onDismiss?: (() => void) | undefined;
}

/** Контроллер drag-to-dismiss. */
export interface DismissController {
  pointerDown(p: BehaviorPoint): void;
  pointerMove(p: BehaviorPoint): void;
  pointerUp(p: BehaviorPoint): void;
  pointerCancel(): void;
  subscribe(fn: (s: DismissState) => void): () => void;
  cancel(): void;
  destroy(): void;
  readonly state: DismissState;
}

const DEFAULT_DISMISS_VELOCITY = 600;

/**
 * Создать headless drag-to-dismiss: порог по смещению/скорости, настраиваемое
 * направление, возврат с УНАСЛЕДОВАННОЙ скоростью при недостигнутом пороге,
 * детерминизм при pointer-cancel. Один clock (B1).
 *
 * @throws {MotionParamError} при невалидном distanceThreshold или пружине.
 */
export function createDragDismiss(options: DismissOptions): DismissController {
  const axis = options.axis ?? 'y';
  const dir: 1 | -1 = options.direction === -1 ? -1 : 1;
  const dist = _finite(options.distanceThreshold);
  if (!(dist > 0)) {
    throw new MotionParamError('LM004');
  }
  const velThresh = Number.isFinite(options.velocityThreshold)
    ? Math.abs(options.velocityThreshold as number)
    : DEFAULT_DISMISS_VELOCITY;
  const springParams = options.spring ?? DEFAULT_SPRING;
  validateSpringForFrameLoop(springParams);
  const dismissTarget = _finite(options.dismissTarget ?? dir * dist * 8);
  const base = _createBase<DismissState, DismissOptions>(
    { value: 0, velocity: 0, phase: 'idle', dismissed: false },
    options, options,
  );

  let grabPointer = 0;
  let grabValue = 0;

  const returnHome = (velocity: number): void => {
    base.emit({ phase: 'release' }) && base._settle({
      from: base.state.value,
      velocity,
      target: 0,
      spring: springParams,
      onStep: (v, vel) => base.emit({ value: v, velocity: vel }),
      onDone: () => base.emit({ phase: 'settle' }),
    });
  };

  const dismiss = (velocity: number): void => {
    base.emit({ phase: 'release' }) && base._settle({
      from: base.state.value,
      velocity,
      target: dismissTarget,
      spring: springParams,
      onStep: (v, vel) => base.emit({ value: v, velocity: vel }),
      onDone: () => {
        if (base.emit({ phase: 'settle', dismissed: true })) _invoke(base, 'onDismiss');
      },
    });
  };

  const ctrl: DismissController = {
    pointerDown(p: BehaviorPoint): void {
      if (!base.owner || base.state.dismissed) return;
      _beginPickup(base, p, axis);
      grabPointer = _coord(p, axis);
      grabValue = base.state.value;
      base.emit({ phase: 'follow', velocity: 0 });
    },
    pointerMove(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const raw = _finite(grabValue + _sub(_coord(p, axis), grabPointer));
      base.emit({ value: raw });
    },
    pointerUp(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const v = axis === 'x' ? base.tracker.velocity().vx : base.tracker.velocity().vy;
      // Порог: смещение В НАПРАВЛЕНИИ dismiss ИЛИ скорость в ту же сторону.
      const projDist = dir * base.state.value;
      const projVel = dir * v;
      if (projDist >= dist || projVel >= velThresh) dismiss(_finite(v));
      else returnHome(_finite(v));
    },
    pointerCancel(): void {
      if (!base._following) return;
      // Детерминизм: перехват указателя ВСЕГДА возвращает домой, без скорости.
      returnHome(0);
    },
    subscribe: base.subscribe,
    cancel: base.cancel,
    destroy: base.destroy,
    get state(): DismissState {
      return base.state;
    },
  };
  if (options.onChange) ctrl.subscribe(options.onChange);
  return ctrl;
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. CAROUSEL / PAGER
// ═══════════════════════════════════════════════════════════════════════════

/** Состояние карусели: value = позиция (px, страница i при i·pageSize) + индекс. */
export interface CarouselState extends BehaviorState<number> {
  /** Текущий индекс страницы (единый clock — выводится из position, B1). */
  readonly index: number;
}

/** Опции карусели/пейджера. */
export interface CarouselOptions {
  /** Число страниц (>= 1); конструктор сохраняет legacy truncation, `update` строгий. */
  readonly pageCount: number;
  /** Размер страницы (px, > 0); конструктор сохраняет legacy finite-normalization. */
  readonly pageSize: number;
  /** Стартовая страница. По умолчанию 0. */
  readonly index?: number | undefined;
  /** Ось прокрутки. По умолчанию 'x'. */
  readonly axis?: BehaviorAxis | undefined;
  /** Right-to-left: зеркалит направление выбора страницы. По умолчанию false. */
  readonly rtl?: boolean | undefined;
  /** Порог скорости (px/s) для перелистывания флик-жестом. По умолчанию 400. */
  readonly velocityThreshold?: number | undefined;
  /** Пружина доводки к странице. По умолчанию токен spring.snappy. */
  readonly spring?: SpringParams | undefined;
  readonly requestFrame?: RequestFrameFn | undefined;
  readonly matchMedia?: MatchMediaLike | undefined;
  readonly onChange?: ((s: CarouselState) => void) | undefined;
}

/** Контроллер карусели/пейджера. */
export interface CarouselController {
  pointerDown(p: BehaviorPoint): void;
  pointerMove(p: BehaviorPoint): void;
  pointerUp(p: BehaviorPoint): void;
  pointerCancel(): void;
  /** Обновить геометрию/ограничения без смены владельца/часов. */
  update(pageCount: number, pageSize: number): void;
  /** Программно перейти на страницу (единый clock). */
  goTo(index: number): void;
  next(): void;
  prev(): void;
  subscribe(fn: (s: CarouselState) => void): () => void;
  cancel(): void;
  destroy(): void;
  readonly state: CarouselState;
}

const DEFAULT_CAROUSEL_VELOCITY = 400;

function _readCarouselGeometry(count: number, size: number): void {
  if (!Number.isFinite(count) || count < 1 || count % 1 !== 0) throw new MotionParamError('LM005');
  if (!Number.isFinite(size) || size <= 0) throw new MotionParamError('LM006');
}

/**
 * Создать headless карусель/пейджер: ЕДИНЫЙ clock для позиции и индекса, inertia
 * с доводкой к странице, направление+velocity в выборе страницы, RTL и вертикаль.
 *
 * @throws {MotionParamError} если нормализованный pageCount/pageSize невалиден или пружина невалидна.
 */
export function createCarousel(options: CarouselOptions): CarouselController {
  let pageCount = Math.trunc(_finite(options.pageCount));
  let pageSize = _finite(options.pageSize);
  _readCarouselGeometry(pageCount, pageSize);
  const axis = options.axis ?? 'x';
  const velThresh = Number.isFinite(options.velocityThreshold)
    ? Math.abs(options.velocityThreshold as number)
    : DEFAULT_CAROUSEL_VELOCITY;
  const springParams = options.spring ?? SNAPPY_SPRING;
  validateSpringForFrameLoop(springParams);

  const clampIndex = (i: number): number => Math.max(0, Math.min(pageCount - 1, i));
  let targetIndex = clampIndex(Math.round(_finite(options.index ?? 0)));
  const initialValue = _finite(targetIndex * pageSize);

  const base = _createBase<CarouselState, true>(
    { value: initialValue, velocity: 0, phase: 'idle', index: clampIndex(Math.round(initialValue / pageSize)) },
    options, true,
  );

  let grabPointer = 0;
  let grabValue = 0;

  // Знак перевода pointer-смещения в position-пространство:
  // горизонталь LTR → влево = следующая (position растёт) → −d; RTL → +d;
  // вертикаль → вверх = следующая → −d.
  const posDirSign = axis === 'x' && options.rtl === true ? 1 : -1;

  const settleTo = (index: number, velocity: number): void => {
    const i = clampIndex(index);
    targetIndex = i;
    base.emit({ phase: 'release', index: clampIndex(base.state.index) }) && base._settle({
      from: base.state.value,
      velocity,
      target: i * pageSize,
      spring: springParams,
      // Единый clock: index выводится из position КАЖДЫЙ кадр (не отдельный счётчик).
      onStep: (v, vel) => base.emit({ value: v, velocity: vel, index: clampIndex(Math.round(v / pageSize)) }),
      onDone: () => base.emit({ phase: 'settle' }),
    });
  };

  const ctrl: CarouselController = {
    pointerDown(p: BehaviorPoint): void {
      if (!base.owner) return;
      _beginPickup(base, p, axis, posDirSign);
      grabPointer = _coord(p, axis);
      grabValue = base.state.value;
      base.emit({ phase: 'follow', velocity: 0 });
    },
    pointerMove(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const value = _finite(grabValue + posDirSign * _sub(_coord(p, axis), grabPointer));
      base.emit({ value, index: clampIndex(Math.round(value / pageSize)) });
    },
    pointerUp(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const vAxis = axis === 'x' ? base.tracker.velocity().vx : base.tracker.velocity().vy;
      // Скорость в position-пространстве.
      const posVel = posDirSign * vAxis;
      // Проекция момента через ./decay → куда прилетела бы позиция.
      const landing = projectDefaultDecayRest(base.state.value, posVel);
      let target = Math.round(landing / pageSize);
      // Флик перелистывает минимум на страницу; доводка — максимум ±1 от старта свайпа.
      const start = clampIndex(Math.round(grabValue / pageSize));
      if (Math.abs(posVel) >= velThresh) target = start + (posVel > 0 ? 1 : -1);
      target = Math.max(start - 1, Math.min(start + 1, target));
      settleTo(target, posVel);
    },
    pointerCancel(): void {
      if (!base._following) return;
      // Детерминизм: доводка к ближайшей странице без скорости.
      settleTo(Math.round(base.state.value / pageSize), 0);
    },
    update(count: number, size: number): void {
      if (!base.owner) return;
      _readCarouselGeometry(count, size);
      if (count === pageCount && size === pageSize) return;
      pageCount = count;
      pageSize = size;
      if (base._following) base.emit({ index: clampIndex(Math.round(base.state.value / pageSize)) });
      else settleTo(targetIndex, base._invalidate());
    },
    goTo(index: number): void {
      if (!base.owner) return;
      settleTo(Math.round(_finite(index)), base._invalidate());
    },
    next(): void {
      ctrl.goTo(base.state.index + 1);
    },
    prev(): void {
      ctrl.goTo(base.state.index - 1);
    },
    subscribe: base.subscribe,
    cancel(): void {
      targetIndex = base.state.index;
      base.cancel();
    },
    destroy: base.destroy,
    get state(): CarouselState {
      return base.state;
    },
  };
  if (options.onChange) ctrl.subscribe(options.onChange);
  return ctrl;
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. PULL-TO-REFRESH
// ═══════════════════════════════════════════════════════════════════════════

/** Состояние pull-to-refresh: value = дистанция протяжки (px, >= 0). */
export interface PullState extends BehaviorState<number> {
  /** Палец тянет прямо сейчас. */
  readonly pulling: boolean;
  /** Протяжка перешла порог активации (release запустит refresh). */
  readonly armed: boolean;
  /** Асинхронное действие в полёте (удержание на pendingPosition). */
  readonly pending: boolean;
}

/** Опции pull-to-refresh. */
export interface PullOptions {
  /** Порог активации (px протяжки). Обязателен, > 0. */
  readonly threshold: number;
  /** Ось чтения ввода. По умолчанию 'y'. */
  readonly axis?: BehaviorAxis | undefined;
  /** Знак направления протяжки вдоль оси (1 = вниз/плюс). По умолчанию 1. */
  readonly direction?: 1 | -1 | undefined;
  /** Резистентность overscroll ∈ [0,1] (0.5 = вдвое тяжелее пальца). По умолчанию 0.5. */
  readonly resistance?: number | undefined;
  /** Высота удержания при pending (px). По умолчанию = threshold. */
  readonly pendingPosition?: number | undefined;
  /** Пружина возврата/доводки. По умолчанию токен spring.default. */
  readonly spring?: SpringParams | undefined;
  /** Асинхронное действие; возврат пружиной — после его резолва. */
  readonly onRefresh?: (() => void | Promise<void>) | undefined;
  readonly requestFrame?: RequestFrameFn | undefined;
  readonly matchMedia?: MatchMediaLike | undefined;
  readonly onChange?: ((s: PullState) => void) | undefined;
}

/** Контроллер pull-to-refresh. */
export interface PullController {
  pointerDown(p: BehaviorPoint): void;
  pointerMove(p: BehaviorPoint): void;
  pointerUp(p: BehaviorPoint): void;
  pointerCancel(): void;
  subscribe(fn: (s: PullState) => void): () => void;
  cancel(): void;
  destroy(): void;
  readonly state: PullState;
}

/**
 * Создать headless pull-to-refresh: резистентный overscroll, порог активации,
 * pending БЕЗ второго владельца позиции (удержание — тот же единственный runner),
 * возврат пружиной после async-действия. Один clock (B1).
 *
 * @throws {MotionParamError} при невалидном threshold или пружине.
 */
export function createPullToRefresh(options: PullOptions): PullController {
  const threshold = _finite(options.threshold);
  if (!(threshold > 0)) {
    throw new MotionParamError('LM007');
  }
  const axis = options.axis ?? 'y';
  const dir: 1 | -1 = options.direction === -1 ? -1 : 1;
  const resistance = _clampFactor(options.resistance, DEFAULT_RUBBER_BAND);
  const springParams = options.spring ?? DEFAULT_SPRING;
  validateSpringForFrameLoop(springParams);
  const pendingPos = _finite(options.pendingPosition ?? threshold);
  const base = _createBase<PullState, PullOptions>(
    { value: 0, velocity: 0, phase: 'idle', pulling: false, armed: false, pending: false },
    options, options,
  );

  let grabPointer = 0;

  const springTo = (
    target: number,
    velocity: number,
    onDone: () => void,
  ): void => {
    base.emit({ phase: 'release' }) && base._settle({
      from: base.state.value,
      velocity,
      target,
      spring: springParams,
      onStep: (v, vel) => base.emit({ value: v, velocity: vel }),
      onDone,
    });
  };

  const returnHome = (velocity: number): void => {
    springTo(0, velocity, () =>
      base.emit({ phase: 'idle', pulling: false, armed: false, pending: false }),
    );
  };

  const runRefresh = (velocity: number): void => {
    // Доводка к pendingPosition ТЕМ ЖЕ runner'ом; на финише — pending-удержание.
    if (!base.emit({ pulling: false })) return;
    springTo(pendingPos, velocity, () => {
      if (!base.emit({ phase: 'settle', pending: true, armed: false })) return;
      const pendingState = base.state;
      const finish = (): void => {
        if (base.owner && base.state === pendingState) returnHome(0);
      };
      try {
        Promise.resolve(_invoke(base, 'onRefresh')).then(finish, finish);
      } catch {
        finish();
      }
    });
  };

  const ctrl: PullController = {
    pointerDown(p: BehaviorPoint): void {
      if (!base.owner || base.state.pending) return; // pending владеет позицией
      _beginPickup(base, p, axis, 0);
      grabPointer = _coord(p, axis);
      base.emit({ phase: 'follow', pulling: true, velocity: 0 });
    },
    pointerMove(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      // Сырая протяжка в направлении dir; обратное — 0 (это не pull).
      const rawPull = dir * _sub(_coord(p, axis), grabPointer);
      const value = rawPull > 0 ? _finite(rawPull * resistance) : 0;
      base.emit({ value, armed: value >= threshold });
    },
    pointerUp(p: BehaviorPoint): void {
      if (!base._following) return;
      base.tracker.push(p);
      const vAxis = axis === 'x' ? base.tracker.velocity().vx : base.tracker.velocity().vy;
      const pullVel = dir * vAxis * resistance;
      if (base.state.armed) runRefresh(_finite(pullVel));
      else returnHome(_finite(pullVel));
    },
    pointerCancel(): void {
      if (!base._following) return;
      // Детерминизм: перехват возвращает домой без активации refresh.
      returnHome(0);
    },
    subscribe: base.subscribe,
    cancel(): void {
      base.cancel({ value: 0, pulling: false, armed: false, pending: false });
    },
    destroy: base.destroy,
    get state(): PullState {
      return base.state;
    },
  };
  if (options.onChange) ctrl.subscribe(options.onChange);
  return ctrl;
}

// ─── Property-level state cascade ────────────────────────────────────────
export { createStateCascade } from './state-cascade.js';
export type {
  StateCascade,
  StateCascadeLayer,
  StateCascadePatch,
} from './state-cascade.js';
