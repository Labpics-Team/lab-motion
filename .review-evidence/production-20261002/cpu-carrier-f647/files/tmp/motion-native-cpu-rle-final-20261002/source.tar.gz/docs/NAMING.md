# NAMING — нейминг-канон lab-motion

> Роль: канон именования (закон + справка). Сверяется скриптом
> `scripts/check-docs-drift.mjs` с фактами ФС из `scripts/naming-inventory.mjs`:
> числа и списки ниже обязаны совпадать с реальностью, иначе прогон красный.

Канон согласован с эталоном экосистемы Labics-Team — lab-icons
(docs/NAMING.md + проверка docs-drift): те же общие принципы, репо-специфика ниже.

## Инвентарь (проверяется автоматически)

| Метрика | N |
| --- | --- |
| экспорт-субпутей package.json | 44 |
| фреймворк-биндингов | 9 |
| CSS-литералов `--lab-motion-*` в src | 0 |
| CSS-литералов вне `--lab-motion-*` в src | 0 |
| файлов вне kebab-закона | 0 |

## Общие принципы (эталон lab-icons)

1. **kebab-case** — файлы, директории, экспорт-субпути, CSS-кастом-свойства.
2. **Домен-префикс** — всё публичное несёт префикс домена: пакет
   `@labpics/motion`, CSS-контракт `--lab-motion-*` (SSOT контракта — labui).
3. **Суффиксы вариантов** — вариант отделяется суффиксом от основы
   (`bench-latency.mjs` от `bench.mjs`, `test:watch` от `test`),
   не переизобретает основу.
4. **Дока ↔ реальность** — каждое имя в доке существует в коде, инвентарь
   покрыт докой; расхождение ловит автоматическая проверка, а не ревьюер.

## Законы lab-motion

### Экспорт-субпути (публичный API)

- Субпуть = домен, kebab-case: `./svg-morph`, `./a11y`.
- Каждый субпуть разрешается в исходник: `.` → `src/index.ts`,
  `./<домен>` → `src/<домен>/index.ts` (или плоский `src/<домен>.ts`).
  Exports без кода запрещены.
- Слоистые L1-модули могут жить плоско рядом с одноимённым доменом
  (`src/spring.ts` — чистый решатель, `src/spring/` — публичный субпуть);
  `src/internal/` не экспортируется никогда.

### Фреймворк-биндинги

- Имя биндинга = каноническое имя фреймворка = имя субпутя; реестр BINDINGS
  в `scripts/naming-inventory.mjs` — SSOT (9 штук).
- Число «9 framework bindings» в description package.json сверяется скриптом проверки
  с реестром и exports.

### CSS

- Движок не эмитит CSS-кастом-свойств: в строковых литералах src их 0 (факт
  автоматической проверки). Контракт `--lab-motion-<категория>-<имя>` (категории `duration`,
  `easing`, `spring`) — SSOT в labui (docs/motion-tokens.md); `./tokens`
  зеркалирует его как typed JS-словарь, имена совпадают байт-в-байт.
- Любая будущая эмиссия обязана начинаться с `--lab-motion-`; иное — только
  через «Известные отступления».

### Файлы

- `src|test|scripts|docs`: kebab-case стема (`motion-value.ts`,
  `bench-latency.mjs`); составные расширения допустимы (`*.test.ts`).
- Докам-канонам в `docs/*.md` разрешён КАПС-стем (`NAMING.md` — как в
  эталоне lab-icons).
- Тесты: `<тема>-<аспект>.test.ts` (`solver-finiteness-fuzz.test.ts`).

## Карта субпутей

Корневой субпуть `.` — headless-ядро и реэкспорты; DOM-фасады доступны через
`./nano` и `./animate`. Домены:

| Группа | Субпути |
| --- | --- |
| Ядро анимации | `./nano` (platform-trusted WAAPI, ≤1 KB), `./animate` (основной продуктовый вход), `./frame`, `./driver`, `./compositor`, `./compositor/stagger`, `./waapi`, `./auto` |
| Значения и физика | `./value`, `./spring`, `./decay`, `./easing`, `./keyframes`, `./stagger`, `./timeline`, `./presets`, `./tokens`, `./utils` |
| Доменные эффекты | `./flip`, `./projection`, `./smart`, `./gestures`, `./behaviors`, `./behaviors/reorder`, `./scroll`, `./in-view`, `./presence`, `./svg`, `./svg-morph`, `./a11y`, `./compiler/surface` (приватный executor compiled-поверхности, ≤1 KB gz) |
| Доменные эффекты | `./bindings`, `./flip`, `./projection`, `./smart`, `./gestures`, `./behaviors`, `./scroll`, `./in-view`, `./presence`, `./svg`, `./svg-morph`, `./a11y`, `./compiler/surface` (приватный executor compiled-поверхности, ≤1 KB gz) |
| Биндинги (9) | `./react`, `./svelte`, `./vue`, `./lit`, `./solid`, `./preact`, `./angular`, `./wc`, `./qwik` |
| Build-tool (не runtime-tier) | `./compiler/vite` (Vite-адаптер lowering), `./compiler/runtime` (private executor compiled-вызовов) |

## Известные отступления

Массовых переименований не делаем — фиксируем и гасим по плану.

Сейчас отступлений нет. Последнее погашено: `docs/бенчмарк.md` (кириллический
стем) переименован в `docs/benchmark.md`; заголовок и содержимое — русские.
