import { afterEach, describe, expect, it, vi } from 'vitest';
import { createFrameRequester } from '../src/internal/frame-requester.js';

afterEach(() => {
  vi.useRealTimers();
});

describe('internal frame requester — hostile one-shot ownership', () => {
  it('does not let a late old callback consume the next normal reservation', () => {
    const callbacks: Array<(timestamp?: number) => void> = [];
    const ticks: Array<number | undefined> = [];
    let request!: () => void;
    request = createFrameRequester((callback) => {
      callbacks.push(callback);
      return callbacks.length;
    }, (timestamp) => {
      ticks.push(timestamp);
      if (ticks.length === 1) request();
    });

    request();
    callbacks[0]!(10);
    expect(callbacks).toHaveLength(2);

    callbacks[0]!(20);
    expect(ticks).toEqual([10]);

    callbacks[1]!(30);
    expect(ticks).toEqual([10, 30]);
  });

  it('accepts only the first delivery from one host request', () => {
    let deliver: ((timestamp?: number) => void) | undefined;
    const ticks: Array<number | undefined> = [];
    const request = createFrameRequester((callback) => {
      deliver = callback;
      return 1;
    }, (timestamp) => ticks.push(timestamp));

    request();
    deliver!(10);
    deliver!(20);

    expect(ticks).toEqual([10]);
  });

  it('does not invent a frame when an async host has not delivered one', () => {
    vi.useFakeTimers();
    const tick = vi.fn();
    const request = createFrameRequester(() => 1, tick);

    request();
    vi.runAllTimers();

    expect(tick).not.toHaveBeenCalled();
  });

  it('defers successful synchronous delivery from a trusted host to the trampoline', () => {
    vi.useFakeTimers();
    const tick = vi.fn();
    const request = createFrameRequester((callback) => {
      callback(10);
      return 1;
    }, tick, false);

    request();
    expect(tick).not.toHaveBeenCalled();

    vi.runAllTimers();
    expect(tick).toHaveBeenCalledTimes(1);
    expect(tick).toHaveBeenCalledWith(10);
  });

  it('does not confuse a reentrant revoked reservation with synchronous delivery', () => {
    vi.useFakeTimers();
    const tick = vi.fn();
    let hostCalls = 0;
    let request!: () => void;
    request = createFrameRequester(() => {
      hostCalls += 1;
      if (hostCalls === 1) {
        expect(() => request()).toThrow('inner host failed');
        return 1;
      }
      throw new Error('inner host failed');
    }, tick);

    request();
    vi.runAllTimers();

    expect(hostCalls).toBe(2);
    expect(tick).not.toHaveBeenCalled();
  });

  it('preserves a reentrant synchronous delivery when the inner host then throws', () => {
    vi.useFakeTimers();
    const tick = vi.fn();
    let hostCalls = 0;
    let request!: () => void;
    request = createFrameRequester((callback) => {
      hostCalls += 1;
      if (hostCalls === 1) {
        expect(() => request()).toThrow('inner host failed after delivery');
        return 1;
      }
      callback(20);
      throw new Error('inner host failed after delivery');
    }, tick);

    request();
    expect(tick).not.toHaveBeenCalled();

    vi.runAllTimers();
    expect(hostCalls).toBe(2);
    expect(tick).toHaveBeenCalledTimes(1);
    expect(tick).toHaveBeenCalledWith(20);
  });

  it('does not defer a nested callback delivered after the inner host unwinds', () => {
    vi.useFakeTimers();
    const ticks: Array<number | undefined> = [];
    let hostCalls = 0;
    let nestedDeliver: ((timestamp?: number) => void) | undefined;
    let request!: () => void;
    request = createFrameRequester((callback) => {
      hostCalls += 1;
      if (hostCalls === 1) {
        request();
        nestedDeliver!(30);
        return 1;
      }
      nestedDeliver = callback;
      return 1;
    }, (timestamp) => ticks.push(timestamp));

    request();
    expect(ticks).toEqual([30]);

    vi.runAllTimers();
    expect(hostCalls).toBe(2);
    expect(ticks).toEqual([30]);
  });

  it('coalesces handle=0 fallback requests into one pending delivery', () => {
    vi.useFakeTimers();
    const schedule = vi.fn(() => 0);
    const tick = vi.fn();
    const request = createFrameRequester(schedule, tick);

    request();
    request();
    vi.runAllTimers();

    expect(schedule).toHaveBeenCalledTimes(1);
    expect(tick).toHaveBeenCalledTimes(1);
  });

  it('does not leak a synchronous delivery when the host then throws', () => {
    vi.useFakeTimers();
    const tick = vi.fn();
    const request = createFrameRequester((callback) => {
      callback(10);
      throw new Error('host failed after delivery');
    }, tick);

    expect(request).toThrow('host failed after delivery');
    vi.runAllTimers();

    expect(tick).not.toHaveBeenCalled();
  });

  it('revokes a retained callback when the host throws before delivery', () => {
    let retained: ((timestamp?: number) => void) | undefined;
    const tick = vi.fn();
    const request = createFrameRequester((callback) => {
      retained = callback;
      throw new Error('host failed before delivery');
    }, tick);

    expect(request).toThrow('host failed before delivery');
    retained!(10);

    expect(tick).not.toHaveBeenCalled();
  });

  it('revokes the host callback after handle=0 selects the fallback owner', () => {
    vi.useFakeTimers();
    let retained: ((timestamp?: number) => void) | undefined;
    const tick = vi.fn();
    const request = createFrameRequester((callback) => {
      retained = callback;
      return 0;
    }, tick);

    request();
    vi.runAllTimers();
    retained!(10);

    expect(tick).toHaveBeenCalledTimes(1);
    expect(tick).toHaveBeenLastCalledWith(undefined);
  });
});
