/**
 * test/behaviors-api-surface-pin.test.ts — пин публичной поверхности ./behaviors.
 * Класс: Б (contract pin). Пин в ОБЕ стороны (North-инвариант): пропавший И
 * лишний runtime-экспорт = красный. Ровно 5 runtime-фабрик; типы (BehaviorState,
 * SheetController, …) стираются в рантайме и в Object.keys не попадают.
 *
 * RED PROOF (2026-07-10, заглушка src/behaviors `export {}`): «missing»-ассерт
 * первого блока падал своим сообщением (все 4 фабрики отсутствуют). Shape-блоки —
 * «createBottomSheet is not a function»: RED for the right reason.
 */

import { describe, expect, it } from 'vitest';
import * as behaviors from '../src/behaviors/index.js';
import { MotionParamError } from '../src/errors.js';
import { pt } from './behaviors-helpers.js';

const EXPECTED_EXPORTS = [
  'createBottomSheet',
  'createCarousel',
  'createDragDismiss',
  'createPullToRefresh',
  'createStateCascade',
] as const;

describe('./behaviors public API surface pin (в обе стороны)', () => {
  it('экспортирует ровно 5 контрактных runtime-фабрик — ни больше, ни меньше', () => {
    const exported = new Set(Object.keys(behaviors));
    const expected = new Set<string>(EXPECTED_EXPORTS);

    const missing = [...expected].filter((n) => !exported.has(n));
    expect(missing, `Отсутствующие экспорты: ${missing.join(', ')}`).toHaveLength(0);

    const extra = [...exported].filter((n) => !expected.has(n));
    expect(extra, `Неконтрактные новые экспорты: ${extra.join(', ')}`).toHaveLength(0);

    expect(Object.keys(behaviors).sort()).toEqual([...EXPECTED_EXPORTS]);
  });

  it('каждый экспорт — функция-фабрика', () => {
    for (const name of EXPECTED_EXPORTS) {
      expect(typeof (behaviors as Record<string, unknown>)[name]).toBe('function');
    }
  });

  it('mutable geometry остаётся у существующих sheet/pager owners', () => {
    expect(typeof behaviors.createBottomSheet({ snapPoints: [0, 100] }).update).toBe('function');
    expect(typeof behaviors.createCarousel({ pageCount: 2, pageSize: 100 }).update).toBe('function');
  });

  it('новый strict update не меняет legacy normalization конструкторов', () => {
    const sheet = behaviors.createBottomSheet({ snapPoints: [Number.NaN, Number.POSITIVE_INFINITY] });
    sheet.snapTo(1);
    expect(sheet.state.value).toBe(Number.MAX_VALUE);
    expect(() => sheet.update([0, Number.POSITIVE_INFINITY])).toThrowError(MotionParamError);

    const carousel = behaviors.createCarousel({ pageCount: 2.5, pageSize: Number.POSITIVE_INFINITY });
    carousel.goTo(2);
    expect(carousel.state.index).toBe(1);
    expect(() => carousel.update(2.5, 100)).toThrowError(MotionParamError);
  });
});

describe('./behaviors: единый контракт BehaviorState { value, velocity, phase }', () => {
  it('все четыре поведения выдают BehaviorState c общими ключами', () => {
    const sheet = behaviors.createBottomSheet({ snapPoints: [0, 100] }).state;
    const dismiss = behaviors.createDragDismiss({ distanceThreshold: 50 }).state;
    const carousel = behaviors.createCarousel({ pageCount: 3, pageSize: 200 }).state;
    const pull = behaviors.createPullToRefresh({ threshold: 60 }).state;
    for (const s of [sheet, dismiss, carousel, pull]) {
      expect(typeof s.value).toBe('number');
      expect(typeof s.velocity).toBe('number');
      expect(['idle', 'follow', 'release', 'settle']).toContain(s.phase);
    }
    // Специфичные расширения состояния.
    expect(typeof sheet.snapIndex).toBe('number');
    expect(typeof dismiss.dismissed).toBe('boolean');
    expect(typeof carousel.index).toBe('number');
    expect(typeof pull.pending).toBe('boolean');
  });
});

describe('./behaviors: cancel()/destroy() обрывают ЖИВОЙ жест во всех четырёх машинах (B3)', () => {
  // Follow-lifetime принадлежит общей state machine: после cancel/destroy
  // следующий pointerMove обязан быть инертным независимо от конкретной фабрики.
  type Point = ReturnType<typeof pt>;
  interface Draggable {
    pointerDown(p: Point): void;
    pointerMove(p: Point): void;
    cancel(): void;
    destroy(): void;
    readonly state: { readonly value: number; readonly phase: string };
  }
  const makers: ReadonlyArray<readonly [string, () => Draggable]> = [
    ['bottomSheet', () => behaviors.createBottomSheet({ snapPoints: [0, 300, 600] })],
    ['dragDismiss', () => behaviors.createDragDismiss({ distanceThreshold: 120 })],
    ['carousel', () => behaviors.createCarousel({ pageCount: 3, pageSize: 200 })],
    ['pullToRefresh', () => behaviors.createPullToRefresh({ threshold: 60 })],
  ];

  for (const [name, make] of makers) {
    it(`${name}: destroy() посреди жеста делает pointerMove инертным`, () => {
      const c = make();
      c.pointerDown(pt(0, 0, 0));
      const before = c.state.value;
      c.destroy();
      c.pointerMove(pt(0, 200, 0.1));
      expect(c.state.value).toBe(before);
    });

    it(`${name}: cancel() посреди жеста оставляет phase idle, pointerMove — no-op`, () => {
      const c = make();
      c.pointerDown(pt(0, 0, 0));
      c.pointerMove(pt(0, 80, 0.05));
      c.cancel();
      expect(c.state.phase).toBe('idle');
      const resting = c.state.value;
      c.pointerMove(pt(0, 240, 0.1));
      expect(c.state.value).toBe(resting);
      expect(c.state.phase).toBe('idle');
    });
  }
});

describe('./behaviors: fail-fast валидация параметров (MotionParamError в фабрике)', () => {
  it('пустые snapPoints → MotionParamError', () => {
    expect(() => behaviors.createBottomSheet({ snapPoints: [] })).toThrowError(MotionParamError);
  });
  it('невалидный distanceThreshold → MotionParamError', () => {
    expect(() => behaviors.createDragDismiss({ distanceThreshold: 0 })).toThrowError(
      MotionParamError,
    );
  });
  it('pageCount < 1 → MotionParamError', () => {
    expect(() => behaviors.createCarousel({ pageCount: 0, pageSize: 100 })).toThrowError(
      MotionParamError,
    );
  });
  it('threshold <= 0 → MotionParamError', () => {
    expect(() => behaviors.createPullToRefresh({ threshold: -1 })).toThrowError(MotionParamError);
  });
  it('невалидная пружина → MotionParamError В ФАБРИКЕ (даже без матчмедиа)', () => {
    expect(() =>
      behaviors.createBottomSheet({
        snapPoints: [0, 100],
        spring: { mass: -1, stiffness: 200, damping: 24 },
      }),
    ).toThrowError(MotionParamError);
  });
});