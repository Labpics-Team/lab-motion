# Журнал изменений

Здесь фиксируются заметные потребителю изменения опубликованных версий.

Формат основан на Keep a Changelog. Версионирование следует SemVer; до `1.0.0` несовместимые изменения публичного контракта выпускаются новым minor-релизом.

## [Unreleased]

### Исправлено
- `MotionValue` и подписки `./behaviors`: уничтожение освобождает внедрённый
  scheduler и callback компонента даже при сохранённых controller/off handles.
  Живые подписки сохраняют Set-дедупликацию; `stop()` остаётся возобновляемым.
- `./behaviors`: изменение snap-точек или размеров страниц сохраняет текущего
  владельца движения. Отмена и уничтожение из подписчика прекращают последующую
  доводку, планирование кадров и внешнее уведомление о закрытии.
  Переполнение координаты карусели сохраняет конечное значение и согласованный
  видимый индекс; после обновления размеров сохраняется исходная логическая цель.
- `./projection`: перехват при `clamp:false` сохраняет независимую скорость x/y
  через общий базис пружины. Повторный перехват и seek/release сохраняют
  аналитическое положение. Ограниченный режим сохраняет прежний scalar-контракт;
  публичные типы не расширены.

### Добавлено
- `CompositorSpring.handoffToCompositor(target)` завершает интерактивную live-фазу
  автономным переходом с текущей позиции и скорости. Старый MotionValue становится
  инертным после успешного native commit; неподдержанная форма продолжает live-путь.
  Исполняемые примеры sheet и pager оставляют выбор snap/page и геометрию компоненту.
- Управляемое присутствие: `createPresenceTransition` связывает одну цель видимости
  с группой анимаций, отменяет устаревший уход и освобождает исполнителей при очистке.
  Рабочий пример диалога поддерживает повторное открытие и Escape без ручного `done`.
- `createMotionBinding` связывает модель компонента с именованными визуальными
  ролями без отдельного store. Неизменённые цели не перезапускают анимации;
  повторный ввод и очистка обслуживаются одной привязкой. Рецепт не зависит от DOM. Практические примеры покрывают загрузку и независимые
  индикаторы выбранной страницы/клавиатурного фокуса.

### Изменено
- `./animate`: `createAnimateScope(root)` связывает локальные селекторы с одной
  уборкой компонента. Завершённые вызовы не накапливаются, `destroy()` отменяет
  оставшиеся и обезвреживает поздние обработчики. Добавлены исполняемые примеры
  для DOM, React StrictMode и Solid; очистка сохраняет позу, а не делает revert.
- `MotionValue.setTarget` сохраняет прошедшее время при частом перенаправлении:
  слежение за указателем больше не застывает при новой цели на каждом кадре.
  Повтор активной цели не перезапускает траекторию; явный перезапуск — через `stop()`.
- **Разделены физическая валидность и бюджеты исполнителей (#218, ADR-0002).**
  `spring()` — чистая аналитика: медленные и незатухающие пружины физически
  валидны и вычислимы на любом t; бюджет оседания (LM091) проверяют кадровые
  исполнители (`validateSpringForFrameLoop`) на своей границе. Наблюдаемые
  изменения для потребителей: `fromBounce({bounce:1})` возвращает damping=0
  (незатухающая — математический факт; кадровый исполнитель её отвергнет
  LM091 на своей границе, как и раньше); `springFromDurationBounce` больше
  не бросает LM091 на очень медленных duration; явно переданный невалидный
  `mass` в конструкторах `./spring` → LM088 вместо тихой подмены единицей.
  Публичный `validateSpringParams` сохраняет прежнюю семантику (алиас
  frame-loop-валидатора). Экспортированы `validateSpringPhysics` и
  `validateSpringForFrameLoop`.
- **Физический домен отвергает вырожденные полюса**: ζ² > MAX_VALUE → LM090
  (раньше класс закрывался бюджетным LM091; без гарда солвер молча возвращал
  0 на экстремальных параметрах).
- Точные обратные конструкторы (#230): `springFromPeak`, `springFromOscillation` —
  биекции наблюдаемых координат (пик/период/огибающая) в физические параметры.
- `springAsEasing` больше не обрывается на конце. Прежняя проекция масштабировала
  время как `ln(100)/(ω₀·slow)` и принудительно возвращала 1 при t≥1: для
  `{mass:1, stiffness:100, damping:20}` левый предел был 0.944, то есть скачок 5.6%
  и ненулевая скорость 0.212. Теперь шкала — горизонт допуска, а хвост добирается
  эрмитовой C¹-запечаткой; отклонение от настоящей пружины не превышает
  `CONVERGENCE_THRESHOLD`. Форма кривой изменилась: для ζ=1 горизонт вырос с 4.605
  до 8.262 в единицах ω₀t, поэтому в тот же отрезок укладывается больше траектории.
- Сэмплирование перестало валидировать параметры на каждом вызове: валидация
  выполняется один раз при построении.

### Добавлено
- `createStateCascade` в `./behaviors` разрешает визуальные намерения по свойствам;
  перекрытые изменения не уведомляют исполнителя. `batch` объединяет смену
  нескольких состояний в одну цель без промежуточных перезапусков.
- Каскад сохраняет порядок вложенных уведомлений и доставку при ошибках
  подписчиков. `destroy()` прекращает доставку, `layer.destroy()` освобождает
  отдельный слой; устаревшее чтение входа не перезаписывает новое состояние.
- `createBottomSheet` и `createCarousel` вычисляют точку покоя инерции без построения
  неиспользуемой модели движения. Проверки входа и порядок IEEE-операций сохранены.
- `./behaviors/reorder`: управляемая перестановка списков/сеток по stable key,
  pointer/keyboard, RTL, атомарные snapshots и отзыв устаревших предложений.
  Исполняемый компонентный рецепт использует существующий projection и cleanup.
- DOM projection принимает нативные HTMLElement в TypeScript без пользовательского
  cast: тип `getRootNode` допускает Node и структурный root; runtime не меняется.
- `animateScrollWaapi` / `animateViewWaapi` в `./waapi`: нативные scroll/view-progress шкалы через `ScrollTimeline`/`ViewTimeline`; на поддерживаемом host нет scroll-listener/rAF Lab Motion, на неподдерживаемом путь возвращает `undefined` без скрытой JS-эмуляции.
- Код `LM169`: `springAsEasing` получила пружину без затухания, у которой финитной
  проекции на [0,1] не существует.
- `compileSpringPlan` принимает `maxValueError`: абсолютный
  бюджет ошибки в единицах numeric `from/to` переводится в нормализованный допуск
  до кэша и сегментера; более строгий из `tolerance` и бюджета результата побеждает.
- Код `LM172`: `maxValueError` не является положительным конечным числом.

## [0.3.0] — 2026-08-04

### Removed

- **Breaking (pre-1.0):** публичные входы `./animate/mini` и `./animate/native`
  удалены вместе с их проверками и тестами; линейка анимации — ровно два входа:
  `./nano` (platform-trusted, ≤1 КБ) и `./animate` (полный контракт).
  Нишу native закрывает `./nano`; one-liner-сценарии mini живут в `./animate`
  с тем же сигнатурным контрактом. Опубликованный npm `0.1.0` этих subpath не
  содержал — миграция не требуется. Коды `LM145/LM148/LM152–LM155` переведены
  в `retired`.

### Added

- `./in-view`: SSR-safe нативный `IntersectionObserver`-адаптер с snapshot
  selector/Element/списка, custom root/margin/amount, one-shot по умолчанию,
  парным enter/leave cleanup и идемпотентным terminal `stop()`.
- `./nano`: platform-trusted WAAPI to-only вход с ограничением размера до 1 КБ gzip:
  spring/tween, целые `translate/scale/rotate` longhand-каналы, CSS-значения
  силами браузера, delay/stagger, reduced-motion и native `Animation` controls.
  Скрытого layout-read, rAF-fallback, C1-подхвата и hostile-host контракта нет;
  кривые выше общего compiler-ceiling отклоняются до materialization.
- `./animate/native`: узкий WAAPI-путь `springTo` для явных пар
  transform/opacity. Отдельная `Animation` на независимый CSS-канал цели
  позволяет вытеснять transform и opacity раздельно; скрытого rAF-fallback нет.
  Chromium/Firefox используют CSS `linear()`, WebKit — явные адаптивные кадры.

- `./react`: `useReducedMotion(): boolean` — реактивно отражает системное
  `prefers-reduced-motion` (фаза I, срез 2, #104): перерендеривает компонент при
  переключении предпочтения на лету. Построен на `useSyncExternalStore` —
  **hydration-safe** (серверный снапшот `false`, совпадает с SSR-разметкой;
  реальное значение читается после commit). Реактивная подписка ПЕРЕИСПОЛЬЗУЕТ
  `./a11y` `createMotionConfig` (системный `matchMedia`-'change' слушатель +
  legacy `addListener`-fallback + leak-safe `destroy()`) — без дублирования логики
  подписки. SSR/Node-safe (`false` без `matchMedia`); matchMedia-шов инжектируется
  для детерминизма тестов. Закрывает пробел «нет подписки на смену matchMedia»,
  отмеченный adversarial-ревью среза 1.
- `./react`: `useMotionStyle` — **effect-binding** хук (фаза I, #104): гонит CSS-
  свойство от пружины БЕЗ ре-рендера компонента на каждом кадре. В отличие от
  `useSpring` (*render value* — компонент рендерится на кадр, чтобы отразить
  число), `useMotionStyle` владеет `MotionValue` и пишет прямо в `element.style`
  внутри подписки `onChange`; компонент рендерится только при смене `target`.
  Возвращает стабильный ref-callback; опции зеркалят Vue-директиву `vMotion`
  (`target`/`property`/`template`/`from`/`spring`/`reducedMotionMode`/
  `requestFrame`) для паритета тонких адаптеров. Retarget сохраняет скорость (C¹),
  reduced-motion = мгновенный CHARACTER-снап без кадров, unmount гасит цикл
  (`unsub`+`destroy`). Доказано в реальном React-рантайме (jsdom + `createRoot`/
  `act`): счётчик render не растёт за 200-кадровую анимацию, а `style` реально
  анимируется (RED при подмене прямой записи на no-op).
- `./behaviors`: новый субпуть — headless state machines типовых мобильных
  взаимодействий поверх ПЕРЕИСПОЛЬЗУЕМЫХ примитивов (ничего не дублировано):
  трекер скорости `./gestures`, проекция момента `./decay` (`.rest`), пружинный
  солвер ядра (доводка value→target с наследованием velocity, C¹), темп-токены
  `./tokens` (дефолтные пружины; роль задаёт потребитель, labui НЕ импортируется).
  Общий контракт `BehaviorState { value, velocity, phase }`
  (`phase ∈ idle|follow|release|settle`); события ввода (`pointerDown`/`Move`/`Up`/
  `Cancel`), `state`-геттер + `subscribe`, программные переходы, идемпотентные
  `cancel()`/`destroy()`. Четыре поведения: **`createBottomSheet`** (snap-точки +
  выбор цели по положению+скорости, follow→доводка без потери velocity, rubber-band
  за крайними snap, `snapTo`, перехват pointer-down); **`createDragDismiss`** (порог
  по смещению/скорости, настраиваемое направление, возврат с унаследованной
  скоростью, детерминизм при pointer-cancel); **`createCarousel`** (ЕДИНЫЙ clock
  позиции+индекса, inertia с доводкой к странице, направление+velocity в выборе,
  RTL и вертикаль, `goTo`/`next`/`prev`); **`createPullToRefresh`** (резистентный
  overscroll, порог активации, `pending` без второго владельца позиции, возврат
  пружиной после async-действия). Инварианты: ОДНА state machine владеет фазой
  (единый generation-токен, ноль параллельных loops); value/velocity конечны (+0);
  reduced-motion = смена характера (мгновенный снап, состояние и результат
  сохранены); SSR-safe (инжектируемый `requestFrame`). Покрытие: example/contract/
  interruption/cancel-destroy/reduced на каждое поведение, property-тесты выбора
  snap/страницы (seeded-LCG, оракул `./decay`), fuzz финитности (≥12 000 злых
  жестов), 2 browser-conformance спеки (pointer capture/cancel на реальном движке).
  Runnable DOM-адаптер и раздел «Behaviors-путь» — в README (#92).

- `./animate/mini`: новый субпуть — лёгкий срез animate с потолком **≤ 5 KB gz**.
  Внутри движок разделяет кодеки свойств и адаптер цели; публичный набор
  фиксирован: числовой transform/opacity, CSS-переменные и DOM-цель. Mini
  не тянет расширенный набор, `./value` и compositor-компилятор (граф проверяется
  import-cost сценарием). Покрытие: transform-шортхенды, `opacity`, CSS-переменные,
  spring/tween в едином прогресс-клоке (значение канала — скаляр/строка/`[from, to]`),
  `delay`/`stagger`, контролы `{ finished, play, pause, seek, cancel,
  stop }`, C¹-подхват value+velocity при повторном запуске (dominant-канал),
  фазы кадра update→render единого `./frame` (чтение once при привязке, запись —
  в render), reduced-motion снап, SSR-safe импорт, fail-fast `MotionParamError`
  ДО записи стиля. Расширенные кодеки и адаптеры проверяются как внутренняя
  архитектура, но не экспортируются как публичный API npm-пакета. Финитность
  проверяется seeded-LCG фаззингом `codec.interpolate`. Compositor-путь в mini
  не включён из-за размерного потолка; полный WAAPI-путь находится в `./animate`.
  Таблица миграции с Motion JS / Anime.js — в README (#103).
- `./smart`: новый субпуть — Figma-подобный smart-animate поверх `./projection`
  (жанр shared-element). Диф ДВУХ снимков дерева по строке-ключу `data-motion-key`
  → `matched`/`entered`/`exited`/`skipped`, оркестрация поверх ОДНОГО
  projection-движка: matched едут FLIP'ом (continuity по строке-ключу переживает
  ПЕРЕСОЗДАНИЕ DOM-узла — перехват берёт аналитический `V(p̂)` и пересеивает
  скорость, C¹), entered — fade-in без transform, exited — ghost-протокол
  (реинсерт `absolute` на padding-box, `removeChild` до резолва `finished`,
  реинкарнация ключа), единый clock. `reduced` = смена характера (matched снап,
  фейды живые), `resolveSmartTier` (`reduced`/`projection`/`ssr`), SSR-инертность,
  fail-fast `MotionParamError` на параметрах и дубликате ключа. API: `captureSmart`,
  `smartTransition`, `resolveSmartTier`, `SMART_KEY_ATTR`. Финитность — фаззинг-тест
  ≥10 000 злых дифов (ни броска, ни NaN/∞/`-0`). Минимальный скоуп #99: нативный
  View Transitions API вырезан (отдельная фаза) (#99).
- `./animate`: tween-режим вычисляет аналитическую скорость канала —
  v = range · ease′(k) / duration (производная изинга — детерминированная
  центральная разность с фиксированным шагом) вместо нуля каждый кадр:
  перехват tween→spring вторым `animate()` наследует импульс, smooth pickup
  стал C¹ на tween-пути, как на spring-пути (#93).
- `./animate`: CSS/value-каналы (цвета, юнитные значения) наследуют скорость
  при перехвате вторым `animate()` — вместо безусловного `v0 = 0` производная
  прогресса ṗ̂ источника проецируется в прогресс-пространство новой
  интерполяции по доминантному компоненту старого спана (канон dominantV0
  WAAPI-пути): юнитные значения и коллинеарные цветовые ретаргеты — точный C¹,
  явная пара `[from, to]` по-прежнему отключает подхват; `var()`/relative/
  несовместимые виды AST — C⁰ (скорость не определена → покой) (#93).
- `./animate`: связная векторная группа каналов (`x`/`y`/`scale`, …) —
  контракт единого времени закреплён характеризационными тестами: одна группа
  = один rAF-цикл (или одна WAAPI-кривая), каждый кадр — атомарный вектор с
  одного `t`, перехват снимает когерентный вектор `(value, velocity)` всех
  каналов с одного `t̂`, группа оседает единым кадром (#93; поведение уже
  держалось конструкцией — без изменений рантайма).
- `./driver`: геттер `AnimationControls.velocity` — аналитическое чтение
  скорости live-рана (units/s) в произвольный момент, симметрично `progress`
  и по канону `MotionValue.velocity`: hidden-state скорость траектории
  (clamp-режим не влияет), в покое и после завершения — ровно 0 (#93).
- `./gestures`: второй аргумент `pointerDown(p, pickup?)` у `DragControls` —
  внешний прайор скорости захвата `{vx, vy}` (px/s) для элемента, летящего
  ЧУЖИМ аниматором (compositor/WAAPI-ран): жест наследует живой импульс,
  немедленный release продолжает движение (C¹, #93, строка матрицы
  «compositor → gesture»). Явный pickup авторитетен и замещает внутренний
  glide-прайор; вырожденные компоненты (NaN/±∞/не-число) → ровно 0. Прямой
  связки gestures→compositor нет (субпути независимы) — рецепт: снять
  скорость `readCompositorSpring` в pointerdown и передать (README, докблок).
- `./presence`: наследование импульса при прерывании (C¹, #93, строка матрицы
  «exit → enter»). Колбэки фаз получают `(done, interrupted, capture)`:
  `capture(read)` регистрирует живой снимок текущего рана (непрозрачный `S`,
  по умолчанию пара `PresenceSnapshot { value, velocity }`), при прерывании
  (enter во время exiting / симметрично exit во время entering) машина
  синхронно читает его и передаёт новой фазе — reversed continuation вместо
  телепорта/старта с нуля. Снимок читается только из живой прерываемой фазы
  (после done — не наследуется), reduced-motion его не читает (без импульса);
  регистратор прерванной фазы инертен (generation-гард). Обратная
  совместимость полная: прежние колбэки `(done) => …` работают без изменений.
- `./gestures`: опция `snapBackSpring` у `createDrag` — при касании границы
  `bounds` инерционным глайдом остаточная скорость передаётся пружинному
  snap-back (iOS-манера: короткий overshoot за границу и упругий возврат
  ровно на неё), стык decay|spring непрерывен по позиции и скорости (C¹).
  Отсутствие опции = прежнее поведение (жёсткий clamp на границе);
  невалидная пружина → `MotionParamError` синхронно из `createDrag` (#93).

### Changed

- **Breaking (pre-1.0):** `repeatType: 'mirror'` в `./keyframes` и `./presets`
  теперь означает настоящий mirror-generator: на нечётных итерациях меняется
  порядок значений, но authored time/easing продолжает идти вперёд. Раньше
  `mirror` был алиасом reverse-time; для прежней траектории замените его на
  `repeatType: 'reverse'`. WAAPI-конвертеры честно отклоняют mirror с повторами,
  потому что native `alternate` разворачивает и время, и easing. Изменение
  предназначено для следующего minor-релиза до 1.0.
- **Breaking (pre-1.0):** конечный `repeat` ограничен переносимым диапазоном
  `0…2_147_483_647`; `Infinity` остаётся публичной записью бесконечного цикла
  и однозначно кодируется как `-1` в MotionProgram V1 для Swift/Kotlin.
- **Breaking (pre-1.0):** infinite repeat имеет один переносимый горизонт:
  точные индексы `0…9_007_199_254_740_991`. Первая граница следующего индекса
  fail-closed с `LM166` в web API / `LMP_BOUNDS` в V1 reference; `+Infinity`
  в web API также даёт `LM166`. BigInt-oracle удалён, runtime больше не
  угадывает parity через modulo.
- `./animate`: WAAPI-путь строит кадры прямо из общего spring artifact без
  повторного execution-plan wrapper и per-unit formatter closure; общий
  compiler/cache/sampler остаётся единственным SSOT, а совместная стоимость
  `animate + compositor` защищена отдельным import-cost ratchet.
- Ядро: `drive` и `MotionValue` используют один поздно привязываемый default
  frame-scheduler; дублированный runtime удалён без смены rAF/fallback-семантики.
- `./compositor`: exact-key LRU вынесен в functional state без смены policy;
  общий cache сохраняет O(1) lookup, нулевые аллокации на hit и прежний порядок
  вытеснения, а одноразовая проверка ёмкости складывается при сборке.
- `CompositorStaggerGroup.handoffToLive` теперь всегда проверяет индекс: после
  `destroy()` существующий ребёнок возвращает инертный `MotionValue`, а
  отсутствующий стабильно завершает вызов с `LM020` вместо искусственного
  значения без владельца.

- До `1.0` несовместимое изменение: `compileStaggerPlan` и
  `CompositorStaggerGroup` перенесены из `./compositor` в
  `./compositor/stagger`. Новый фасад также экспортирует `compileSpringPlan` и
  `CompositorSpring`, чтобы одиночные и групповые переходы использовали один
  consumer-entry. Deprecated alias не оставлен: он вернул бы групповой граф в
  базовый compositor.

- `MotionParamError` получил добавочное поле `.code` и экспортируемый тип
  `MotionParamErrorCode`. Внутренние сообщения теперь содержат только `LMddd`,
  без отражения входных значений; причины и исправления находятся в каталоге.
  Разбор старого prose/detail-текста `message` несовместим, ветвление по `.code`
  стабильно; строковый публичный конструктор сохраняет текст с `LM000`.

- `./animate`, `./animate/mini`, framework bindings и web component используют
  один общий фазовый frame-loop. Массовый запуск больше не создаёт отдельный
  `requestAnimationFrame` и отдельный Promise на каждую группу.
- `drive` и `MotionValue` переиспользуют один буфер результата солвера на весь
  прогон; `./stagger` считает расстояния в одном массиве. Горячий кадр не
  создаёт result-объект, а каскад не держит второй буфер размера группы.
- Compositor-компилятор учитывает начальную скорость в горизонте и бюджете сетки,
  хранит exact IEEE-754 ключи в ограниченном LRU и сохраняет стартовую касательную.
- `compileSpringPlan` в WebKit выдаёт исполнимые явные кадры; `nodes` теперь
  являются свежим снимком фактически сериализованных остановок в пределах
  `tolerance`, а повторная компиляция переиспользует подготовленную кривую из кэша.

- npm-артефакт получил раздельные ESM/CJS declaration-ветки для всех экспортов,
  `typesVersions` для legacy TypeScript resolver, точный `sideEffects`-allowlist,
  честный Preact floor `10.3.1` и автоматические проверки на реальные байты tarball.
- Релиз собирает tgz один раз, после всех проверок фиксирует тег, публикует только
  опечатанный artifact через OIDC и проверяет registry integrity и SLSA provenance.

- Минимальный runtime-контракт поднят до Node.js 22: ветки 18 и 20 больше не
  получают security-исправления, а CI и package-manager работают на поддерживаемой
  LTS-линии. Это несовместимое изменение следующего minor-релиза.

- **`./gestures`: захват летящего объекта наследует скорость глайда** (#93,
  осознанный фикс дефекта C¹-контракта). `pointerDown` во время инерционного
  глайда теперь засевает velocity tracker текущей скоростью глайда (прайор в
  скользящем окне): немедленный release без движения продолжает движение,
  а не обнуляет его. Прежнее наблюдаемое поведение (press→release во время
  глайда убивал скорость) считалось дефектом; удержание пальца дольше окна
  трекера (0.1 s) по-прежнему естественно гасит скорость до нуля.

### Fixed

- `./animate`: hostile `style.setProperty`, применяющий кадр и синхронно
  запускающий `animate()` другой transform-компоненты, больше не теряет
  только что видимый канал: снимок и реестр во время host-write отдают
  применяемое поколение всей transform-поверхности (значение и скорость),
  settle-запись после реентрантного вытеснения молча уступает successor-у,
  а бросок хоста по-прежнему не публикует неприменённое поколение.
- `./animate`: неудачная реентрантная подписка `SurfaceBatch` теперь
  транзакционно откатывает все присоединённые в этой попытке поверхности,
  сохраняет исходную host-ошибку и оставляет paused controls повторяемыми.
- `./animate`: создание и завершение `finished`, ассимиляция WAAPI completion и
  отложенный release owner больше не зависят от поздней подмены `Promise` или
  `queueMicrotask`; бросающий host scheduler и ошибка `onComplete` не прячут
  controls, не оставляют Promise pending и не меняют успешный supersede на
  natural completion.
- MotionProgram V1 возвращает exact track endpoints до authored easing при
  normal и mirror, включая дорожки со сменой codec между сегментами; reference,
  web sampler и future-host conformance corpus теперь следуют одному закону.
- `./keyframes` и `./presets`: единый repeat-cursor владеет exact-boundary,
  repeatDelay и progress; вложенный `seek()`/`cancel()` из пользовательского
  easing линейризуется и не допускает позднюю публикацию внешнего сэмпла.
  Следующее virtual-time и real-time anchor коммитятся только после проверки
  infinite-horizon: `LM166` оставляет последний валидный clock и позволяет
  явно продолжить либо завершить controls без зависшего scheduler-owner.
  Синхронный injectable `requestFrame` проходит через async-trampoline, а
  `repeat: Infinity` больше не завершается искусственно после 100 000 кадров.
  Exact intermediate boundary теперь half-open и запускает следующую итерацию;
  только конечный terminal закрыт. Это единый закон MotionProgram V1 и native
  WAAPI, намеренно отличный от previous-end поведения Motion 12.42.2.
- Repeat/WAAPI-компиляция общим V1-примитивом отклоняет абсолютные расписания,
  где duration или repeatDelay не превосходят product/absolute binary64
  resolution budget, а также неконечные миллисекунды и составные scale до
  публикации адаптерных данных. Infinite WAAPI hold также fail-closed до
  пользовательских callbacks, если его масштаб схлопывает разные authored
  offsets; намеренные дубли offsets остаются допустимым скачком.
  `repeatDelay` без повторов в preset WAAPI
  канонически игнорируется. Shipped keyframe-sampler больше не содержит
  создаваемый на каждом сэмпле IIFE.
- Injectable frame scheduler получает уникального владельца каждой заявки:
  поздний повторный вызов старого callback не может украсть уже созданную
  следующую заявку; trusted native scheduler сохраняет стабильный callback.
- `./keyframes` и `./presets` отклоняют невызываемый scalar/array easing
  стабильными `LM163`/`LM164`, не подменяя ошибку линейным easing.
- `./presets`: `splitText(..., 'chars')` теперь делит текст по extended
  grapheme clusters через `Intl.Segmenter`, поэтому combining marks, emoji-ZWJ,
  flags, Hangul и Indic conjuncts не рвутся; явный exact-segmenter шов покрывает
  старые среды, а без него сохраняется прежний code-point fallback.
- `./animate`: main-thread stagger сохраняет субкадровую фазу — монотонное
  logical-time и signed local phase не дают малым задержкам (< кадра)
  схлопнуться в один кадровый bucket, overshoot не теряется.
- `./compositor`: WAAPI effect и fallback timer теперь атомарно сменяют единственного
  owner; stale callbacks и реентрантный host-cleanup не могут оживить или отменить
  новый прогон, а `destroy()` разрывает удержание target, effect и timer.
- `./auto`: exit использует единое identity-владение между сессиями; stale
  observer больше не забирает перенесённый узел, а reentrant disconnect
  детерминированно освобождает ghost, handlers, style leases и parent-ссылки.
- `./animate`: uniform/axial scale сохраняет обе оси и точные signed-zero края;
  pause/seek переносит effect-space скорость без скачка, а несовместимые оси
  продолжает независимым main-thread путём вместо ложного общего WAAPI-progress.
- `./animate`: переполнение составной delay отклоняется до host-effects, а
  завершение задержек длиннее диапазона HTML timer сверяется с WAAPI-clock без
  раннего settle, starvation и скачка terminal pose.
- Сборка: параллельная минификация ESM/CJS изолирует настройки Terser, поэтому
  повторный запуск даёт тот же CJS-артефакт, включая strict-семантику и mangling.
- `./animate/native`: host-методы вызываются без доверия к own `.call`,
  доставка завершения не зависит от глобальной `queueMicrotask`, отмена
  разрывает связь вечного host `finished` с DOM, а несходящаяся реентрантная
  компенсация завершается `LM157` вместо ложного успеха.
- `./frame`: единый identity-владелец резервирования гасит stale/двойную доставку,
  любой синхронный `requestFrame` проходит через отменяемый async-trampoline, а
  только ошибка текущего владельца демотирует clock без потери живых подписок.
  `cancelAll()` завершает teardown атомарно; off/once/rollback сразу освобождают
  callback и DOM-ссылки, массовая отписка остаётся линейной.
- WebKit получает явные ключевые кадры: пружина продолжает движение при
  блокировке главного потока. ESM-файлы `dist` используют браузерные относительные
  импорты общего frame-loop и загружаются напрямую из CDN.
- Full/mini/WAAPI одинаково сохраняют паузу при `seek`; `NaN` и `±Infinity`
  игнорируются. Медленные пружины не завершаются искусственно после 2000 кадров,
  а нулевой диапазон не теряет унаследованный импульс.

- Framework bindings при reduced motion атомарно снэпают состояние без
  отложенного stale-кадра; React-адаптер сохраняет владельца `MotionValue` при
  StrictMode replay и уничтожает его только при настоящем unmount.
- Удалён цикл `compositor ↔ stagger`; новая статическая проверка запрещает возврат
  циклических импортов.
- Headless-типы больше не требуют `lib.dom`, а npm-runtime не содержит ссылок
  на исключённые sourcemap-файлы.

- `MotionValue`: `NaN`/`±Infinity` в `opts.initialVelocity` больше не
  трактуются молча как «нет сида» — конструктор бросает `MotionParamError`
  синхронно, как для `initial`/`spring` (паритет с `drive()`; нота ревью #112).

## [0.2.0] — 2026-07-10

### Added

- Субпуть `./projection` — вложенный FLIP-движок: чистая геометрия (transform
  родителя не искажает детей и border-radius), headless-драйвер с velocity
  continuity при перехвате (`seek`/`release` под жест) и тонкий DOM-адаптер
  (page-space, composed-обход открытых shadow root'ов, граница
  batch clear→measure→start).
- `./tokens`: `springFromDurationBounce(durationS, bounce)` — каноническая
  пара восприятия (модель SwiftUI/Motion.dev) → `SpringParams` с гарантией
  оседания; ДС-пружины `spring.smooth` и `spring.expressive`.
- Воспроизводимый release-процесс с проверкой версии, полным набором проверок и npm provenance.
- Политики вклада и безопасности, шаблоны issues и pull requests.
- Регулярный mutation-прогон критического численного ядра.

### Changed

- **Словарь motion-токенов сведён с SSOT дизайн-системы labui** (minor по
  политике до 1.0). Миграция: `duration.normal` → `duration.base`; шкала
  длительностей 150/250/400/600 → **100/200/300/500** мс; изинги
  `easing.entrance`/`easing.exit` → `easing.decelerate`/`easing.accelerate`
  (официальные кривые M3), `easing.standard` → `cubic-bezier(0.2, 0, 0, 1)`,
  `easing.emphasized` → единственная кривая с overshoot
  `cubic-bezier(0.38, 1.21, 0.22, 1)`; полоса `distanceScale` → 100→300 мс.
- CI выполняется на изолированном GitHub-hosted runner с минимальными разрешениями и отменой устаревших прогонов.

## [0.1.0] — 2026-07-09

### Added

- Первая публичная версия `@labpics/motion`.
- Headless-ядро пружин, tween, `drive` и `MotionValue`.
- Модульные точки входа для timeline, gestures, scroll, presence, FLIP, SVG, WAAPI, compositor, токенов и framework bindings.
- Размерные, contract, property, fuzz, package-smoke и mutation-проверки.
