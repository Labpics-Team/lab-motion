import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

/** Один исходник прикладного примера: документация является исполняемым consumer. */
export function reorderRecipe(root) {
  const text = readFileSync(resolve(root, 'docs/recipes.md'), 'utf8');
  const section = text.split('<!-- reorder-component-recipe:start -->')[1]?.split('<!-- reorder-component-recipe:end -->')[0];
  const source = section?.match(/```typescript\r?\n([\s\S]*?)\r?\n```/)?.[1];
  if (!source) throw new Error('reorder recipe is missing');
  return source;
}
