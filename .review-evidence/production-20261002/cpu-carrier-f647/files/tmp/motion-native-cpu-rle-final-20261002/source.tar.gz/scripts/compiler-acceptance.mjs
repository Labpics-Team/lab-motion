/**
 * compiler-acceptance.mjs — приёмочный гейт компиляторного среза (#208).
 *
 * Заявление среза: build-time lowering статических вызовов —
 * (1) `animate(el, { opacity: N })` из '@labpics/motion/nano' → precomputed-
 * артефакт + hoisted-импорт приватного executor '@labpics/motion/compiler/
 * runtime'; (2) `animate(el, { width: [w0, w1] }, { layout: 'project' })`
 * из '@labpics/motion/animate' → сертифицированный НА СБОРКЕ артефакт
 * (позитивность, reciprocal-бюджет ≤0.25 px) + приватный surface-executor
 * '@labpics/motion/compiler/surface' (код executor'а ≤1 KB gz; total — решётка от
 * факта, см. SURFACE_*_MAX_GZ). Тогда в БАНДЛ ПОТРЕБИТЕЛЯ не
 * попадает ни spring-solver, ни MotionProgram V1 parser, ни compiler-ядро,
 * ни полный фасад. Бандл строго меньше.
 *
 * Гейт делает это заявление воспроизводимым фактом, а не текстом описания: один
 * и тот же fixture собирается РЕАЛЬНЫМ Vite дважды (с плагином motionCompiler()
 * и без) и сверяется по МОДУЛЬНОМУ ГРАФУ, по content-fingerprint солвера и по
 * gzip-весу. Плюс positive controls: динамические формы и onFrame обязаны
 * оставить плагин no-op'ом (иначе гейт мерил бы тавтологию, а не элиминацию).
 *
 * Заземление на dist: alias публичных субпутей → реальные dist-артефакты
 * (те же байты, что получит npm-потребитель). Плагин берётся из собранного
 * dist/compiler/vite. Сборка детерминирована, без сети.
 */

import { build } from 'vite';
import { gzipSync } from 'node:zlib';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCompilerNanoRecipe } from './compiler-doc-recipe.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const DIST = resolve(ROOT, 'dist');
const TMP = resolve(ROOT, 'scripts', '.compiler-acceptance-tmp');

/** Alias публичных субпутей на реальные dist-артефакты (байты потребителя). */
const ALIAS = {
  '@labpics/motion/nano': resolve(DIST, 'nano/index.js'),
  '@labpics/motion/compiler/runtime': resolve(DIST, 'compiler/runtime/index.js'),
  '@labpics/motion/animate': resolve(DIST, 'animate/index.js'),
  '@labpics/motion/compiler/surface': resolve(DIST, 'compiler/surface/index.js'),
};

/** dist-модуль (не entry, не bare peer) в графе — нормализованный к dist-relative id. */
function distModules(chunk) {
  // Vite сообщает id с '/', а resolve() на Windows даёт '\\': без нормализации
  // startsWith никогда не совпадёт и граф dist-модулей будет ложно пустым.
  const distSlash = DIST.replaceAll('\\', '/');
  return Object.keys(chunk.modules)
    .map((id) => id.replaceAll('\\', '/'))
    .filter((id) => id.startsWith(distSlash))
    .map((id) => id.slice(distSlash.length + 1));
}

// Плагин грузится динамически в run() ПОСЛЕ проверки существования dist:
// статический импорт из ../dist упал бы раньше дружелюбной диагностики.
let motionCompiler;

/** Один Vite-build fixture'а: возвращает entry-chunk {code, distModules}.
 * entryName — общий путь entry для байтово-сравниваемых пар (rolldown
 * вшивает путь entry в вывод: разные пути ломают no-op-сравнение). */
async function buildFixture(name, code, withPlugin, entryName = name, extension = 'js') {
  const entry = resolve(TMP, `${entryName}.${extension}`);
  writeFileSync(entry, code);
  const result = await build({
    root: ROOT,
    logLevel: 'silent',
    configFile: false,
    resolve: { alias: ALIAS },
    plugins: withPlugin ? [motionCompiler()] : [],
    build: {
      write: false,
      minify: true,
      target: 'es2022',
      lib: { entry, formats: ['es'], fileName: name },
    },
  });
  const output = Array.isArray(result) ? result[0].output : result.output;
  const chunk = output.find((o) => o.type === 'chunk' && o.isEntry) ?? output[0];
  return { code: chunk.code, modules: distModules(chunk) };
}

// TypeScript-вход (бриф, этап C): аннотации, as const, satisfies, interface.
const LOWERABLE_TS = `import { animate } from '@labpics/motion/nano';
interface Marker { readonly kind: 'fixture' }
const marker = { kind: 'fixture' } as const satisfies Marker;
export function play(el: Element): typeof marker {
  animate(el, { opacity: 0.5 });
  return marker;
}`;
// TSX-вход: плагин заявляет поддержку через дефолтную фазу Vite.
const LOWERABLE_TSX = `import { animate } from '@labpics/motion/nano';
export function Play(props: { el: Element }): unknown {
  animate(props.el, { opacity: 0.5 });
  return <div data-ok="1" />;
}`;

// Статическая opacity — единственная форма в скоупе lowering (#208 §core).
// Это буквальный runnable-рецепт документации: acceptance и browser proof
// не владеют отдельными копиями входа.
const LOWERABLE = readCompilerNanoRecipe(ROOT);
// Динамическая opacity — вне скоупа: плагин обязан отказать (positive control).
const DYNAMIC = `import { animate } from '@labpics/motion/nano';
export function play(el, v) { return animate(el, { opacity: v }); }`;
// Surface-вызов полного фасада: статические концы + явный layout:'project' —
// единственная форма, которую плагин обязан понизить в surface-executor.
const SURFACE = `import { animate } from '@labpics/motion/animate';
export function play(el) { animate(el, { width: [240, 360] }, { layout: 'project' }); }`;
// Динамические концы — вне скоупа: корректный runtime path обязан остаться.
const SURFACE_DYNAMIC = `import { animate } from '@labpics/motion/animate';
export function play(el, w) { return animate(el, { width: [240, w] }, { layout: 'project' }); }`;
// onFrame требует observer-час runtime-пути: lowering запрещён семантикой.
const SURFACE_ONFRAME = `import { animate } from '@labpics/motion/animate';
export function play(el) { return animate(el, { width: [240, 360] }, { layout: 'project', onFrame: (f) => f }); }`;

/** Fingerprint spring-солвера: замкнутая форма тянет Math.exp/cos/sin/sqrt. */
const SPRING_MATH = /Math\.(?:exp|cos|sin|sqrt)/;
const RUNTIME_MODULE = 'compiler/runtime/index.js';
const NANO_MODULE = 'nano/index.js';
const ANIMATE_MODULE = 'animate/index.js';
const SURFACE_MODULE = 'compiler/surface/index.js';
/**
 * Размерные гейты surface-lowering (хронология от факта):
 * 1. EXECUTOR ≤1 KB gzip — жёсткий гейт КОДА (спека «surface observer ≤1 KB»):
 *    dist/compiler/surface/index.js без артефактных данных. Факт 2026-08-05: 1024 B gz.
 * 2. TOTAL — решётка от факта: executor + сертифицированный артефакт (P/Q/A
 *    serialization — сам payload доказательства ≤0.25 px; физически не сжимаем
 *    ниже без отказа от сертификата). История: 2743 → 2187 (blend-A вынесена
 *    из артефакта в executor) → 2003 (микроужатия) → 2026-08-07 факт 2367,
 *    решётка 2470: вынос blend-A ОТМЕНЁН хотфиксом наблюдаемой
 *    эквивалентности — executor восстанавливал A регулярным выражением из Q
 *    и расходился с runtime до 0.738 между стопами. A снова сериализуется из
 *    SSOT компилятора; прежнее «ужатие» было оплачено семантикой и повторять
 *    его запрещено. Executor при этом похудел до 961 B gz (удалён regex).
 */
const SURFACE_EXECUTOR_MAX_GZ = 1024;
const SURFACE_COMPILED_MAX_GZ = 2470;

const failures = [];
const notes = [];
const traceRecords = [];
const TRACE = process.argv.includes('--trace');
const TRACE_SCHEMA_VERSION = 1;
const check = (ok, message) => { if (!ok) failures.push(message); };

function recordTrace(id, goal, result, refusal) {
  if (!TRACE) return;
  const owners = [
    [RUNTIME_MODULE, '@labpics/motion/compiler/runtime', 'compiled'],
    [SURFACE_MODULE, '@labpics/motion/compiler/surface', 'compiled'],
    [NANO_MODULE, '@labpics/motion/nano', 'runtime'],
    [ANIMATE_MODULE, '@labpics/motion/animate', 'runtime'],
  ].filter(([module]) => result.modules.includes(module));
  if (owners.length !== 1) {
    failures.push(`tooling trace ${id}: ожидался один owner, получено ${owners.length}`);
    return;
  }
  const [module, owner, execution] = owners[0];
  if (execution === 'runtime' && (typeof refusal !== 'string' || refusal.trim().length === 0)) {
    failures.push(`tooling trace ${id}: runtime refusal обязателен и не может быть пустым`);
    return;
  }
  traceRecords.push({
    schemaVersion: TRACE_SCHEMA_VERSION,
    id,
    goal,
    owner,
    path: `dist/${module}`,
    execution,
    refusal: execution === 'runtime' ? refusal : null,
  });
}

async function run() {
  if (!existsSync(DIST)) {
    console.error('compiler-acceptance: dist отсутствует — сначала pnpm build');
    process.exit(1);
  }
  ({ motionCompiler } = await import('../dist/compiler/vite/index.js'));
  rmSync(TMP, { recursive: true, force: true });
  mkdirSync(TMP, { recursive: true });
  try {
    const baseline = await buildFixture('lowerable-uncompiled', LOWERABLE, false);
    const compiled = await buildFixture('lowerable-compiled', LOWERABLE, true);
    const control = await buildFixture('dynamic-compiled', DYNAMIC, true);

    // ── Контроль fixture'а: без плагина путь ДЕЙСТВИТЕЛЬНО рантаймовый ─────────
    // (иначе «элиминация» ничего не значит — нечего было элиминировать).
    check(
      baseline.modules.includes(NANO_MODULE),
      `baseline не тянет ${NANO_MODULE} (fixture не исполняет рантаймовый путь): ${baseline.modules.join(', ')}`,
    );
    check(
      SPRING_MATH.test(baseline.code),
      'baseline не содержит spring-математику — fixture не доказывает наличие солвера в рантайме',
    );

    // ── (b/c) Элиминация: compiled-граф без солвера/парсера/ядра ──────────────
    check(
      compiled.modules.includes(RUNTIME_MODULE),
      `compiled не тянет executor ${RUNTIME_MODULE}: ${compiled.modules.join(', ')}`,
    );
    // Несущий структурный инвариант: единственный dist-модуль compiled-графа —
    // приватный executor. Ни nano, ни solver, ни motion-program, ни compiler/core.
    const compiledExtra = compiled.modules.filter((m) => m !== RUNTIME_MODULE);
    check(
      compiledExtra.length === 0,
      `compiled-граф несёт лишние dist-модули (ожидался только executor): ${compiledExtra.join(', ')}`,
    );
    check(
      !SPRING_MATH.test(compiled.code),
      'compiled содержит spring-математику — солвер не элиминирован',
    );
    // Артефакт на месте: precomputed linear() как литерал (не вычисление).
    check(
      /linear\(/.test(compiled.code),
      'compiled не содержит precomputed linear()-артефакт',
    );

    // ── (d) Относительный размер: compiled строго меньше uncompiled ───────────
    const baselineGz = gzipSync(baseline.code).length;
    const compiledGz = gzipSync(compiled.code).length;
    check(
      compiledGz < baselineGz,
      `compiled (${compiledGz} B gz) не меньше uncompiled (${baselineGz} B gz)`,
    );
    notes.push(
      `размер: uncompiled ${baselineGz} B gz → compiled ${compiledGz} B gz ` +
      `(−${baselineGz - compiledGz} B, −${((1 - compiledGz / baselineGz) * 100).toFixed(1)}%)`,
    );

    // ── Positive control: динамическая opacity — плагин no-op ─────────────────
    check(
      control.modules.includes(NANO_MODULE) && !control.modules.includes(RUNTIME_MODULE),
      `плагин ошибочно понизил динамический вызов (граф: ${control.modules.join(', ')})`,
    );
    notes.push(`no-op контроль: динамическая opacity сохранила рантаймовый путь (${NANO_MODULE})`);
    notes.push(`граф compiled: ${compiled.modules.join(', ') || '(только entry)'}`);
    recordTrace('nano-static', 'static opacity=0.5', compiled);
    recordTrace('nano-dynamic', 'dynamic opacity', control, 'opacity is not build-known');

    // ── Surface lowering: layout:'project' реально стирает фасад ───────────────
    const surfaceBaseline = await buildFixture('surface-uncompiled', SURFACE, false, 'surface');
    const surfaceCompiled = await buildFixture('surface-compiled', SURFACE, true, 'surface');
    // Контроль fixture'а: surface-вызов ДЕЙСТВИТЕЛЬНО тянет полный фасад из
    // dist. Без него все ассерты ниже вакуумно проходят на пустом графе.
    check(
      surfaceBaseline.modules.includes(ANIMATE_MODULE),
      `surface-fixture не тянет ${ANIMATE_MODULE} (alias не разрешился, ассерты вакуумны): ${surfaceBaseline.modules.join(', ')}`,
    );
    check(
      SPRING_MATH.test(surfaceBaseline.code),
      'surface-baseline не содержит spring-математику — fixture не доказывает рантаймовый путь',
    );
    // Erasure: compiled-граф несёт ТОЛЬКО приватный surface-executor.
    check(
      surfaceCompiled.modules.includes(SURFACE_MODULE),
      `compiled surface не тянет executor ${SURFACE_MODULE}: ${surfaceCompiled.modules.join(', ')}`,
    );
    check(
      !surfaceCompiled.modules.includes(ANIMATE_MODULE),
      `compiled surface всё ещё несёт фасад ${ANIMATE_MODULE}: ${surfaceCompiled.modules.join(', ')}`,
    );
    const surfaceExtra = surfaceCompiled.modules.filter((m) => m !== SURFACE_MODULE);
    check(
      surfaceExtra.length === 0,
      `compiled surface-граф несёт лишние dist-модули (ожидался только executor): ${surfaceExtra.join(', ')}`,
    );
    check(
      !SPRING_MATH.test(surfaceCompiled.code),
      'compiled surface содержит spring-математику — солвер не элиминирован',
    );
    // Артефакт на месте: precomputed linear()-тройка и pseudo-tree-эффекты.
    check(
      /linear\(/.test(surfaceCompiled.code),
      'compiled surface не содержит precomputed linear()-артефакт',
    );
    check(
      surfaceCompiled.code.includes('::view-transition-group('),
      'compiled surface не содержит 5 CSS-effects псевдодерева',
    );
    // Относительный размер: compiled строго меньше полного фасада.
    const surfaceBaselineGz = gzipSync(surfaceBaseline.code).length;
    const surfaceCompiledGz = gzipSync(surfaceCompiled.code).length;
    check(
      surfaceCompiledGz < surfaceBaselineGz,
      `compiled surface (${surfaceCompiledGz} B gz) не меньше uncompiled (${surfaceBaselineGz} B gz)`,
    );
    // Абсолютные гейты: (1) код executor'а ≤1 KB gz независимо от данных;
    // (2) total-решётка от факта (executor + certified-артефакт вызова).
    const executorGz = gzipSync(readFileSync(resolve(DIST, SURFACE_MODULE))).length;
    check(
      executorGz <= SURFACE_EXECUTOR_MAX_GZ,
      `surface-executor ${executorGz} B gz превышает гейт кода ${SURFACE_EXECUTOR_MAX_GZ} B gz`,
    );
    check(
      surfaceCompiledGz <= SURFACE_COMPILED_MAX_GZ,
      `compiled surface ${surfaceCompiledGz} B gz превышает решётку ${SURFACE_COMPILED_MAX_GZ} B gz`,
    );
    notes.push(
      `surface lowering: uncompiled ${surfaceBaselineGz} B gz → compiled ${surfaceCompiledGz} B gz ` +
      `(−${surfaceBaselineGz - surfaceCompiledGz} B, −${((1 - surfaceCompiledGz / surfaceBaselineGz) * 100).toFixed(1)}%; ` +
      `executor ${executorGz}/${SURFACE_EXECUTOR_MAX_GZ} B gz, total-решётка ${SURFACE_COMPILED_MAX_GZ} B gz)`,
    );
    notes.push(`граф compiled surface: ${surfaceCompiled.modules.join(', ') || '(только entry)'}`);

    // ── No-op контроли surface: динамика и onFrame остаются runtime path ────
    const surfaceDynamic = await buildFixture('surface-dynamic', SURFACE_DYNAMIC, true, 'surface-dyn');
    check(
      surfaceDynamic.modules.includes(ANIMATE_MODULE) && !surfaceDynamic.modules.includes(SURFACE_MODULE),
      `плагин ошибочно понизил динамический surface-вызов (граф: ${surfaceDynamic.modules.join(', ')})`,
    );
    const surfaceOnFrame = await buildFixture('surface-onframe', SURFACE_ONFRAME, true, 'surface-of');
    check(
      surfaceOnFrame.modules.includes(ANIMATE_MODULE) && !surfaceOnFrame.modules.includes(SURFACE_MODULE),
      `плагин ошибочно понизил surface-вызов с onFrame (граф: ${surfaceOnFrame.modules.join(', ')})`,
    );
    notes.push('surface no-op контроль: динамические концы и onFrame сохранили рантаймовый путь');
    recordTrace('surface-static', "static width [240,360], layout='project'", surfaceCompiled);
    recordTrace('surface-dynamic', "dynamic width endpoint, layout='project'", surfaceDynamic, 'endpoint is not build-known');
    recordTrace('surface-on-frame', "static width, layout='project', onFrame", surfaceOnFrame, 'onFrame requires runtime observation');

    // ── TypeScript acceptance (бриф, этап C) ────────────────────────────────
    // Плагин обязан нижать TS/TSX-вход реального Vite-приложения. На
    // enforce:'pre' transform получал сырой TypeScript, this.parse падал, а
    // catch глотал отказ как успешный no-op — lowering молча не происходил.
    const tsCompiled = await buildFixture('ts-compiled', LOWERABLE_TS, true, 'ts-fixture', 'ts');
    check(
      tsCompiled.modules.includes(RUNTIME_MODULE),
      `TS-вход не понижен: graph=${tsCompiled.modules.join(',') || '(пусто)'}`,
    );
    check(
      !tsCompiled.modules.includes(NANO_MODULE),
      'TS-вход: nano runtime остался в бандле — lowering не заменил вызов',
    );
    const tsxCompiled = await buildFixture('tsx-compiled', LOWERABLE_TSX, true, 'tsx-fixture', 'tsx');
    check(
      tsxCompiled.modules.includes(RUNTIME_MODULE),
      `TSX-вход не понижен: graph=${tsxCompiled.modules.join(',') || '(пусто)'}`,
    );
    check(
      !tsxCompiled.modules.includes(NANO_MODULE),
      'TSX-вход: nano runtime остался в бандле — lowering не заменил вызов',
    );
    // Диагностика не скрыта: сборка с плагином не давит предупреждения — сам
    // факт lowering выше доказывает, что parse failure не съел трансформацию.
    notes.push('TypeScript acceptance: TS и TSX нижатся дефолтной фазой Vite');
  } finally {
    rmSync(TMP, { recursive: true, force: true });
  }
}

run().then(() => {
  for (const note of notes) console.log(`  ${note}`);
  if (failures.length > 0) {
    console.error('compiler-acceptance: FAIL');
    for (const failure of failures) console.error(`  - ${failure}`);
    process.exit(1);
  }
  if (TRACE) {
    for (const record of traceRecords) console.log(`tooling-trace ${JSON.stringify(record)}`);
  }
  console.log('compiler-acceptance: PASS — solver/parser/compiler элиминированы из бандла потребителя');
}).catch((error) => {
  console.error('compiler-acceptance: внутренняя ошибка —', error);
  process.exit(1);
});